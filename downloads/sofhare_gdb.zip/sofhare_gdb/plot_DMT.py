from .GDB_plugin import*
from matplotlib import path
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import math
import shapely.geometry as sg
from shapely import speedups
speedups.disable()
import numpy as np

def plot_graphDMT(self):
    #lista delle variabili richiamabili
    #rappresentazione strtigrafica
    # poligoni principali del grafico per il peso specifico
    fango = sg.Polygon([(0.1, 0.5), (8.0, 0.5), (8.0, 1.2), (0.1, 1.2)])

    argillaA = sg.Polygon([(0.1, 1.2), (0.33, 1.2), (0.33, 2.8531), (0.1, 1.419)])
    argillaB = sg.Polygon([(0.1, 2.466), (0.33, 5.176), (0.33, 2.8531), (0.1, 1.419)])
    argillaC = sg.Polygon([(0.1, 2.466), (0.33, 5.176), (0.33, 9.3899), (0.1, 4.2854)])
    argillaD = sg.Polygon([(0.1, 7.4131), (0.33, 16.9765), (0.33, 9.3899), (0.1, 4.2854)])
    argillaE = sg.Polygon([(0.1, 7.4131), (0.33, 16.9765), (0.33, 200.0), (0.1, 200.0)])

    argilla_limosaA = sg.Polygon([(0.6, 1.2), (0.33, 1.2), (0.33, 2.8531), (0.6, 4.04779)])
    argilla_limosaB = sg.Polygon([(0.6, 7.5029), (0.33, 5.176), (0.33, 2.8531), (0.6, 4.04779)])
    argilla_limosaC = sg.Polygon([(0.6, 7.5029), (0.33, 5.176), (0.33, 9.3899), (0.6, 13.90738)])
    argilla_limosaD = sg.Polygon([(0.6, 25.7061), (0.33, 16.9765), (0.33, 9.3899), (0.6, 13.90738)])
    argilla_limosaE = sg.Polygon([(0.6, 25.7061), (0.33, 16.9765), (0.33, 200.0), (0.6, 200.0)])

    limo_argillosoA = sg.Polygon([(0.6, 1.2), (0.8, 1.2), (0.8, 4.7896), (0.6, 4.04779)])
    limo_argillosoB = sg.Polygon([(0.6, 7.5029), (0.8, 8.9705), (0.8, 4.7896), (0.6, 4.04779)])
    limo_argillosoC = sg.Polygon([(0.6, 7.5029), (0.8, 8.9705), (0.8, 16.8008), (0.6, 13.90738)])
    limo_argillosoD = sg.Polygon([(0.6, 25.7061), (0.8, 31.3866), (0.8, 16.8008), (0.6, 13.90738)])
    limo_argillosoE = sg.Polygon([(0.6, 25.7061), (0.8, 31.3866), (0.8, 200.0), (0.6, 200.0)])

    limoA = sg.Polygon([(1.2, 1.2), (0.8, 1.2), (0.8, 4.7896), (1.2, 6.0718)])
    limoB = sg.Polygon([(1.2, 11.53908), (0.8, 8.9705), (0.8, 4.7896), (1.2, 6.0718)])
    limoC = sg.Polygon([(1.2, 21.929), (0.8, 16.8008), (0.8, 8.9705), (1.2, 11.53908)])
    limoD = sg.Polygon([(1.2, 41.5864), (0.8, 31.3866), (0.8, 16.8008), (1.2, 21.929)])
    limoE = sg.Polygon([(1.2, 41.5864), (0.8, 31.3866), (0.8, 200.0), (1.2, 200.0)])

    limo_sabbiosoA = sg.Polygon([(1.2, 1.2), (1.8, 1.2), (1.8, 7.69722), (1.2, 6.0718)])
    limo_sabbiosoB = sg.Polygon([(1.2, 11.53908), (1.8, 14.84308), (1.8, 7.69722), (1.2, 6.0718)])
    limo_sabbiosoC = sg.Polygon([(1.2, 21.929), (1.8, 28.6229), (1.8, 14.84308), (1.2, 11.53908)])
    limo_sabbiosoD = sg.Polygon([(1.2, 41.5864), (1.8, 55.10095), (1.8, 28.6229), (1.2, 21.929)])
    limo_sabbiosoE = sg.Polygon([(1.2, 41.5864), (1.8, 55.10095), (1.8, 200.0), (1.2, 200.0)])

    sabbia_limosaA = sg.Polygon([(3.3, 1.2), (1.8, 1.2), (1.8, 7.69722), (3.3, 10.9731)])
    sabbia_limosaB = sg.Polygon([(3.3, 21.62704), (1.8, 14.84308), (1.8, 7.69722), (3.3, 10.9731)])
    sabbia_limosaC = sg.Polygon([(3.3, 42.6249), (1.8, 28.6229), (1.8, 14.84308), (3.3, 21.62704)])
    sabbia_limosaD = sg.Polygon([(3.3, 83.9167), (3.3, 42.6249), (1.8, 28.6229), (1.8, 55.10095)])
    sabbia_limosaE = sg.Polygon([(3.3, 83.9167), (1.8, 55.10095), (1.8, 200.0), (3.3, 200.0)])

    sabbiaA = sg.Polygon([(3.3, 1.2), (8.0, 1.2), (8.0, 18.4207), (3.3, 10.9731)])
    sabbiaB = sg.Polygon([(3.3, 21.62704), (8.0, 37.48166), (8.0, 18.4207), (3.3, 10.9731)])
    sabbiaC = sg.Polygon([(3.3, 42.6249), (8.0, 76.2658), (8.0, 37.48166), (3.3, 21.62704)])
    sabbiaD = sg.Polygon([(3.3, 83.9167), (8.0, 155.14738), (8.0, 76.2658), (3.3, 42.6249)])
    sabbiaE = sg.Polygon([(3.3, 83.9167), (8.0, 155.14738), (8.0, 200.0), (3.3, 200.0)])

    # rappresentazione grafica poligoni
    fangox, fangoy = fango.exterior.xy

    argillaAx, argillaAy = argillaA.exterior.xy
    argillaBx, argillaBy = argillaB.exterior.xy
    argillaCx, argillaCy = argillaC.exterior.xy
    argillaDx, argillaDy = argillaD.exterior.xy
    argillaEx, argillaEy = argillaE.exterior.xy

    argilla_limosaAx, argilla_limosaAy = argilla_limosaA.exterior.xy
    argilla_limosaBx, argilla_limosaBy = argilla_limosaB.exterior.xy
    argilla_limosaCx, argilla_limosaCy = argilla_limosaC.exterior.xy
    argilla_limosaDx, argilla_limosaDy = argilla_limosaD.exterior.xy
    argilla_limosaEx, argilla_limosaEy = argilla_limosaE.exterior.xy

    limo_argillosoAx, limo_argillosoAy = limo_argillosoA.exterior.xy
    limo_argillosoBx, limo_argillosoBy = limo_argillosoB.exterior.xy
    limo_argillosoCx, limo_argillosoCy = limo_argillosoC.exterior.xy
    limo_argillosoDx, limo_argillosoDy = limo_argillosoD.exterior.xy
    limo_argillosoEx, limo_argillosoEy = limo_argillosoE.exterior.xy

    limoAx, limoAy = limoA.exterior.xy
    limoBx, limoBy = limoB.exterior.xy
    limoCx, limoCy = limoC.exterior.xy
    limoDx, limoDy = limoD.exterior.xy
    limoEx, limoEy = limoE.exterior.xy

    limo_sabbiosoAx, limo_sabbiosoAy = limo_sabbiosoA.exterior.xy
    limo_sabbiosoBx, limo_sabbiosoBy = limo_sabbiosoB.exterior.xy
    limo_sabbiosoCx, limo_sabbiosoCy = limo_sabbiosoC.exterior.xy
    limo_sabbiosoDx, limo_sabbiosoDy = limo_sabbiosoD.exterior.xy
    limo_sabbiosoEx, limo_sabbiosoEy = limo_sabbiosoE.exterior.xy

    sabbia_limosaAx, sabbia_limosaAy = sabbia_limosaA.exterior.xy
    sabbia_limosaBx, sabbia_limosaBy = sabbia_limosaB.exterior.xy
    sabbia_limosaCx, sabbia_limosaCy = sabbia_limosaC.exterior.xy
    sabbia_limosaDx, sabbia_limosaDy = sabbia_limosaD.exterior.xy
    sabbia_limosaEx, sabbia_limosaEy = sabbia_limosaE.exterior.xy

    sabbiaAx, sabbiaAy = sabbiaA.exterior.xy
    sabbiaBx, sabbiaBy = sabbiaB.exterior.xy
    sabbiaCx, sabbiaCy = sabbiaC.exterior.xy
    sabbiaDx, sabbiaDy = sabbiaD.exterior.xy
    sabbiaEx, sabbiaEy = sabbiaE.exterior.xy

    # creazione del grafico
    self.figLTDMT = plt.figure()
    ax1 = self.figLTDMT.add_subplot(1, 1, 1)

    plt.fill_between(fangox, fangoy, facecolor='#8c614c', alpha=0.7)

    plt.fill_between(argillaAx, argillaAy, facecolor='saddlebrown', alpha=0.6)
    plt.fill_between(argillaBx, argillaBy, facecolor='saddlebrown', alpha=0.7)
    plt.fill_between(argillaCx, argillaCy, facecolor='saddlebrown', alpha=0.8)
    plt.fill_between(argillaDx, argillaDy, facecolor='saddlebrown', alpha=0.9)
    plt.fill_between(argillaEx, argillaEy, facecolor='saddlebrown', alpha=1.0)

    plt.fill_between(argilla_limosaAx, argilla_limosaAy, facecolor='peru', alpha=0.6)
    plt.fill_between(argilla_limosaBx, argilla_limosaBy, facecolor='peru', alpha=0.7)
    plt.fill_between(argilla_limosaCx, argilla_limosaCy, facecolor='peru', alpha=0.8)
    plt.fill_between(argilla_limosaDx, argilla_limosaDy, facecolor='peru', alpha=0.9)
    plt.fill_between(argilla_limosaEx, argilla_limosaEy, facecolor='peru', alpha=1.0)

    plt.fill_between(limo_argillosoAx, limo_argillosoAy, facecolor='darkkhaki', alpha=0.6)
    plt.fill_between(limo_argillosoBx, limo_argillosoBy, facecolor='darkkhaki', alpha=0.7)
    plt.fill_between(limo_argillosoCx, limo_argillosoCy, facecolor='darkkhaki', alpha=0.8)
    plt.fill_between(limo_argillosoDx, limo_argillosoDy, facecolor='darkkhaki', alpha=0.9)
    plt.fill_between(limo_argillosoEx, limo_argillosoEy, facecolor='darkkhaki', alpha=1.0)

    plt.fill_between(limoAx, limoAy, facecolor='#8f9c06', alpha=0.6)
    plt.fill_between(limoBx, limoBy, facecolor='#8f9c06', alpha=0.7)
    plt.fill_between(limoCx, limoCy, facecolor='#8f9c06', alpha=0.8)
    plt.fill_between(limoDx, limoDy, facecolor='#8f9c06', alpha=0.9)
    plt.fill_between(limoEx, limoEy, facecolor='#8f9c06', alpha=1.0)

    plt.fill_between(limo_sabbiosoAx, limo_sabbiosoAy, facecolor='yellowgreen', alpha=0.6)
    plt.fill_between(limo_sabbiosoBx, limo_sabbiosoBy, facecolor='yellowgreen', alpha=0.7)
    plt.fill_between(limo_sabbiosoCx, limo_sabbiosoCy, facecolor='yellowgreen', alpha=0.8)
    plt.fill_between(limo_sabbiosoDx, limo_sabbiosoDy, facecolor='yellowgreen', alpha=0.9)
    plt.fill_between(limo_sabbiosoEx, limo_sabbiosoEy, facecolor='yellowgreen', alpha=1.0)

    plt.fill_between(sabbia_limosaAx, sabbia_limosaAy, facecolor='#baae09', alpha=0.6)
    plt.fill_between(sabbia_limosaBx, sabbia_limosaBy, facecolor='#baae09', alpha=0.7)
    plt.fill_between(sabbia_limosaCx, sabbia_limosaCy, facecolor='#baae09', alpha=0.8)
    plt.fill_between(sabbia_limosaDx, sabbia_limosaDy, facecolor='#baae09', alpha=0.9)
    plt.fill_between(sabbia_limosaEx, sabbia_limosaEy, facecolor='#baae09', alpha=1.0)

    plt.fill_between(sabbiaAx, sabbiaAy, facecolor='gold', alpha=0.6)
    plt.fill_between(sabbiaBx, sabbiaBy, facecolor='gold', alpha=0.7)
    plt.fill_between(sabbiaCx, sabbiaCy, facecolor='gold', alpha=0.8)
    plt.fill_between(sabbiaDx, sabbiaDy, facecolor='gold', alpha=0.9)
    plt.fill_between(sabbiaEx, sabbiaEy, facecolor='gold', alpha=1.0)

    plt.plot(fangox, fangoy, argillaAx, argillaAy, argillaBx, argillaBy, argillaCx, argillaCy, \
             argillaDx, argillaDy, argillaEx, argillaEy, argilla_limosaAx, argilla_limosaAy, \
             argilla_limosaBx, argilla_limosaBy, argilla_limosaCx, argilla_limosaCy, argilla_limosaDx, \
             argilla_limosaDy, argilla_limosaEx, argilla_limosaEy, limo_argillosoAx, limo_argillosoAy, \
             limo_argillosoBx, limo_argillosoBy, limo_argillosoCx, limo_argillosoCy, \
             limo_argillosoDx, limo_argillosoDy, limo_argillosoEx, limo_argillosoEy, \
             limoAx, limoAy, limoBx, limoBy, limoCx, limoCy, limoDx, limoDy, limoEx, limoEy, \
             limo_sabbiosoAx, limo_sabbiosoAy, limo_sabbiosoBx, limo_sabbiosoBy, \
             limo_sabbiosoCx, limo_sabbiosoCy, limo_sabbiosoDx, limo_sabbiosoDy, \
             limo_sabbiosoEx, limo_sabbiosoEy, sabbia_limosaAx, sabbia_limosaAy, \
             sabbia_limosaBx, sabbia_limosaBy, sabbia_limosaCx, \
             sabbia_limosaCy, sabbia_limosaDx, sabbia_limosaDy, \
             sabbia_limosaEx, sabbia_limosaEy, sabbiaAx, sabbiaAy, \
             sabbiaBx, sabbiaBy, sabbiaCx, sabbiaCy, \
             sabbiaDx, sabbiaDy, sabbiaEx, sabbiaEy, \
             color='white', linewidth=0.5, \
             linestyle='solid', alpha=0.2)

    ax1.annotate('TORBA', xy=(0.9, 0.75), xycoords='data', annotation_clip=False, size=7, rotation=0, ha='center')
    ax1.annotate('ARGILLA', xy=(0.18, 1.3), xycoords='data', annotation_clip=False, size=7, rotation=90, ha='center')
    ax1.annotate('ARGILLA\nLIMOSA', xy=(0.44, 1.3), xycoords='data', annotation_clip=False, size=7, rotation=90,
                 ha='center')
    ax1.annotate('LIMO\nARGILLOSO', xy=(0.65, 1.3), xycoords='data', annotation_clip=False, size=7, rotation=90,
                 ha='left')
    ax1.annotate('LIMO', xy=(0.98, 1.3), xycoords='data', annotation_clip=False, size=7, rotation=90, ha='center')
    ax1.annotate('LIMO\nSABBIOSO', xy=(1.47, 1.3), xycoords='data', annotation_clip=False, size=7, rotation=90,
                 ha='center')
    ax1.annotate('SABBIA LIMOSA', xy=(2.44, 1.3), xycoords='data', annotation_clip=False, size=7, rotation=90,
                 ha='center')
    ax1.annotate('SABBIA', xy=(5, 1.3), xycoords='data', annotation_clip=False, size=7, rotation=90, ha='center')

    # rappresentazione grafica punti
    Idx = np.array(self.varId)
    Edy = np.array(self.varEd)
    markercolors = np.array(self.varZ)
    plt.scatter(Idx, Edy, s=16.0, alpha=1.0, c=markercolors, cmap='Blues',edgecolors='black')

    plt.xscale('log')
    plt.xlabel('Indice di materiale Id')

    plt.yscale('log')
    plt.ylabel('Modulo dilatometrico Ed (MPa)')

    cbar = plt.colorbar()
    cbar.ax.invert_yaxis()
    cbar.set_label('Profondità (m)')

    plt.axis([0.1, 8.0, 0.5, 200.0])
    plt.title('Statigrafia DMT')

    #grafico1 = plt.gcf()
    #grafico1.savefig(r'C:\Users\umber\Desktop\script_DMT\DMT-OutputGrafico.png', dpi=300)
    self.sceneLitDMT = QtWidgets.QGraphicsScene()
    canvas = FigureCanvas(self.figLTDMT)
    canvas.setGeometry(0, 0, 600, 600)
    self.sceneLitDMT.addWidget(canvas)
    self.dlg16.Lito.setScene(self.sceneLitDMT)

    self.figBaseDMT, (aID, aED, aOCR, aK0) = plt.subplots(1, 4)
    self.figBaseDMT.tight_layout()
    # # array assex
    scaleX = np.array([5, 10, 20, 50, 100, 200, 250])
    # # Id
    aID.set_title('Indice di Materiale', fontsize=11)
    aID.set_xlabel('Id', fontsize=9.5)
    aID.set_ylabel('Prof (m)', fontsize=9.5)
    aID.invert_yaxis()
    aID.set_ylim([self.varZ.max(), 0])
    aID.set_yticks(np.arange(0, self.varZ.max(), 1))
    aID.set_xscale('log')
    # Set the x-axis limit
    aID.set_xlim([0.1, 10])
    self.fspulID = np.ma.masked_where(self.varId == 0, self.varId)
    aID.set_xlim([self.fspulID.min() - 10, self.fspulID.max()])
    aID.plot(self.fspulID, self.varZ, 'k-', markersize=7)
    aID.grid(which='both',linestyle='--')
    # # ED
    aED.set_title('Modulo dilatometrico', fontsize=11)
    aED.set_xlabel('Ed (MPa)', fontsize=9.5)
    aED.set_ylabel('Prof (m)', fontsize=9.5)
    aED.invert_yaxis()
    aED.set_ylim([self.varZ.max(), 0])
    aED.set_yticks(np.arange(0, self.varZ.max(), 1))
    idx1 = (np.abs(scaleX-self.varEd.max()/5)).argmin()
    if self.varEd.max()/scaleX[idx1]<2:
        fatt1=scaleX[idx1-1]
    if self.varEd.max()/scaleX[idx1]>8:
        fatt1=scaleX[idx1+1]
    if self.varEd.max()/scaleX[idx1]<8 or self.varEd.max()/scaleX[idx1]>2:
        fatt1=scaleX[idx1]
    aED.set_xticks(np.arange(0, self.varEd.max(), fatt1))
    #
    self.fspulEd = np.ma.masked_where(self.varEd == 0, self.varEd)
    aED.set_xlim([self.fspulEd.min() - 10, self.fspulEd.max()])
    aED.plot(self.fspulEd, self.varZ, 'k-', markersize=7)
    aED.grid(linestyle='--')
    # # OCR
    aOCR.set_title('OCR', fontsize=11)
    aOCR.set_xlabel('OCR', fontsize=9.5)
    aOCR.set_ylabel('Prof (m)', fontsize=9.5)
    aOCR.invert_yaxis()
    aOCR.set_ylim([self.varZ.max(), 0])
    aOCR.set_yticks(np.arange(0, self.varZ.max(), 1))
    idx1 = (np.abs(scaleX - self.varOCR.max() / 5)).argmin()
    if self.varOCR.max() / scaleX[idx1] < 2:
        fatt1 = scaleX[idx1 - 1]
    if self.varOCR.max() / scaleX[idx1] > 8:
        fatt1 = scaleX[idx1 + 1]
    if self.varOCR.max() / scaleX[idx1] < 8 or self.varOCR.max() / scaleX[idx1] > 2:
        fatt1 = scaleX[idx1]
    aOCR.set_xticks(np.arange(0, self.varOCR.max(), fatt1))
    #
    self.fspulOCR = np.ma.masked_where(self.varOCR == 0, self.varOCR)
    aOCR.set_xlim([self.fspulOCR.min() - 10, self.fspulOCR.max()])
    aOCR.plot(self.fspulOCR, self.varZ, 'ko', markersize=1,linestyle='-')
    aOCR.grid(linestyle='--')
    # # Ko
    aK0.set_title('Spinta orr. in sito', fontsize=11)
    aK0.set_xlabel('K0', fontsize=9.5)
    aK0.set_ylabel('Prof (m)', fontsize=9.5)
    aK0.invert_yaxis()
    aK0.set_ylim([self.varZ.max(), 0])
    aK0.set_yticks(np.arange(0, self.varZ.max(), 1))
    idx1 = (np.abs(scaleX - self.varKo.max() / 5)).argmin()
    if self.varKo.max()<5:
        fatt1=1
        aK0.set_xticks(np.arange(0, 5, fatt1))
        aK0.set_xlim([0, 5])
    else:
        if self.varKo.max() / scaleX[idx1] < 2:
            fatt1 = scaleX[idx1 - 1]
        if self.varKo.max() / scaleX[idx1] > 8:
            fatt1 = scaleX[idx1 + 1]
        if self.varKo.max() / scaleX[idx1] < 8 or self.varKo.max() / scaleX[idx1] > 2:
            fatt1 = scaleX[idx1]
        aK0.set_xticks(np.arange(0, self.varKo.max(), fatt1))
    #
    self.fspulko = np.ma.masked_where(self.varKo == 0, self.varKo)
    aK0.set_xlim([self.fspulko.min() - 10, self.fspulko.max()])
    aK0.plot(self.fspulko, self.varZ, 'ko', markersize=1,linestyle='-')
    aK0.grid(linestyle='--')

    #
    self.sceneBP1 = QtWidgets.QGraphicsScene()
    canvas = FigureCanvas(self.figBaseDMT)
    canvas.setGeometry(0, 0, 1450, 620)
    self.sceneBP1.addWidget(canvas)
    self.dlg16.BasePLOT.setScene(self.sceneBP1)


    self.figBase2DMT, (aKD, aM, aCU,aPHI) = plt.subplots(1, 4)
    self.figBase2DMT.tight_layout()
    # # array assex
    scaleX = np.array([5, 10, 20, 50, 100, 200, 250])
    # # Kd
    aKD.set_title('Indice di spinta orizzontale', fontsize=11)
    aKD.set_xlabel('Kd', fontsize=9.5)
    aKD.set_ylabel('Prof (m)', fontsize=9.5)
    aKD.invert_yaxis()
    aKD.set_ylim([self.varZ.max(), 0])
    aKD.set_yticks(np.arange(0, self.varZ.max(), 1))
    idx1 = (np.abs(scaleX - self.varKd.max() / 5)).argmin()
    if self.varKd.max() / scaleX[idx1] < 2:
        fatt1 = scaleX[idx1 - 1]
    if self.varKd.max() / scaleX[idx1] > 8:
        fatt1 = scaleX[idx1 + 1]
    if self.varKd.max() / scaleX[idx1] < 8 or self.varKd.max() / scaleX[idx1] > 2:
        fatt1 = scaleX[idx1]
    aKD.set_xticks(np.arange(0, self.varKd.max(), fatt1))
    #
    self.fspulkd = np.ma.masked_where(self.varKd == 0, self.varKd)
    aKD.set_xlim([self.fspulkd.min() - 10, self.fspulkd.max()])
    aKD.plot(self.fspulkd, self.varZ, 'k-', markersize=7)
    if self.dlg16.NOFalda.isChecked()==False:
        aKD.plot(np.mean(self.varKd),(float(self.HfaldaDMT)-0.22),'cv', markersize=8)
    aKD.grid(linestyle='--')
    # # M
    aM.set_title('Modulo Edometrico', fontsize=11)
    aM.set_xlabel('M (MPa)', fontsize=9.5)
    aM.set_ylabel('Prof (m)', fontsize=9.5)
    aM.invert_yaxis()
    aM.set_ylim([self.varZ.max(), 0])
    aM.set_yticks(np.arange(0, self.varZ.max(), 1))
    idx1 = (np.abs(scaleX - self.varM.max() / 5)).argmin()
    if self.varM.max() / scaleX[idx1] < 2:
        fatt1 = scaleX[idx1 - 1]
    if self.varM.max() / scaleX[idx1] > 8:
        fatt1 = scaleX[idx1 + 1]
    if self.varM.max() / scaleX[idx1] < 8 or self.varM.max() / scaleX[idx1] > 2:
        fatt1 = scaleX[idx1]
    aM.set_xticks(np.arange(0, self.varM.max(), fatt1))
    #
    self.fspulM = np.ma.masked_where(self.varM == 0, self.varM)
    aM.set_xlim([self.fspulM .min() - 10, self.fspulM .max()])
    aM.plot(self.fspulM, self.varZ, 'k-', markersize=7)
    if self.dlg16.NOFalda.isChecked()==False:
        aM.plot(np.mean(self.varM),(float(self.HfaldaDMT)-0.22),'cv', markersize=8)
    aM.grid(linestyle='--')
    # # CU
    aCU.set_title('Resistenza al taglio non drenata', fontsize=11)
    aCU.set_xlabel('Cu (kPa)', fontsize=9.5)
    aCU.set_ylabel('Prof (m)', fontsize=9.5)
    aCU.invert_yaxis()
    aCU.set_ylim([self.varZ.max(), 0])
    aCU.set_yticks(np.arange(0, self.varZ.max(), 1))
    idx1 = (np.abs(scaleX - self.varCu.max() / 5)).argmin()
    if self.varCu.max() / scaleX[idx1] < 2:
        fatt1 = scaleX[idx1 - 1]
    if self.varCu.max() / scaleX[idx1] > 8:
        fatt1 = scaleX[idx1 + 1]
    if self.varCu.max() / scaleX[idx1] < 8 or self.varCu.max() / scaleX[idx1] > 2:
        fatt1 = scaleX[idx1]
    aCU.set_xticks(np.arange(0, self.varCu.max(), fatt1))
    #
    self.fspulCu = np.ma.masked_where(self.varCu == 0, self.varCu)
    aCU.set_xlim([self.fspulCu.min() - 10, self.fspulCu.max()])
    aCU.plot(self.fspulCu, self.varZ, 'ko', markersize=1,linestyle='-')
    aCU.grid(linestyle='--')

    # # CU
    aPHI.set_title('Angolo di attrito', fontsize=11)
    aPHI.set_xlabel('φ (°)', fontsize=9.5)
    aPHI.set_ylabel('Prof (m)', fontsize=9.5)
    aPHI.invert_yaxis()
    aPHI.set_ylim([self.varZ.max(), 0])
    aPHI.set_yticks(np.arange(0, self.varZ.max(), 1))
    idx1 = (np.abs(scaleX - self.varPhi.max() / 5)).argmin()
    if self.varPhi.max() / scaleX[idx1] < 2:
        fatt1 = scaleX[idx1 - 1]
    if self.varPhi.max() / scaleX[idx1] > 8:
        fatt1 = scaleX[idx1 + 1]
    if self.varPhi.max() / scaleX[idx1] < 8 or self.varPhi.max() / scaleX[idx1] > 2:
        fatt1 = scaleX[idx1]
    aPHI.set_xticks(np.arange(0, self.varPhi.max(), fatt1))
    #
    self.fspulPHI = np.ma.masked_where(self.varPhi == 0, self.varPhi)
    aPHI.set_xlim([self.fspulPHI.min() - 10, self.fspulPHI.max()])
    aPHI.plot(self.fspulPHI, self.varZ, 'ko', markersize=1,linestyle='-')
    aPHI.grid(linestyle='--')

    #
    self.sceneBP2 = QtWidgets.QGraphicsScene()
    canvas = FigureCanvas(self.figBase2DMT)
    canvas.setGeometry(0, 0, 1450, 620)
    self.sceneBP2.addWidget(canvas)
    self.dlg16.BasePLOT2.setScene(self.sceneBP2)

    if len(self.varZvs)>0:
        self.figBase3DMT, (aVS, aG0) = plt.subplots(1, 2)
        self.figBase3DMT.tight_layout()
        # # array assex
        scaleX = np.array([5, 10, 20, 50, 100, 200, 250])
        # # Vs
        aVS.set_title('Velocità onde di taglio', fontsize=11)
        aVS.set_xlabel('Vs', fontsize=9.5)
        aVS.set_ylabel('Prof (m/s)', fontsize=9.5)
        aVS.invert_yaxis()
        aVS.set_ylim([self.varZvs.max(), 0])
        aVS.set_yticks(np.arange(0, self.varZvs.max(), 1))
        idx1 = (np.abs(scaleX - self.varVs.max() / 5)).argmin()
        if self.varVs.max() / scaleX[idx1] < 2:
            fatt1 = scaleX[idx1 - 1]
        if self.varVs.max() / scaleX[idx1] > 8:
            fatt1 = scaleX[idx1 + 1]
        if self.varVs.max() / scaleX[idx1] < 8 or self.varVs.max() / scaleX[idx1] > 2:
            fatt1 = scaleX[idx1]
        aVS.set_xticks(np.arange(0, self.varVs.max(), fatt1))
        #
        newVs=[]
        newZvs=[]
        for v in range(0,len(self.varVs)):
            if self.varVs[v]!=0:
                if v==0:
                    newVs=np.append(newVs,self.varVs[v])
                    newVs = np.append(newVs, self.varVs[v])
                    newZvs = np.append(newZvs,0)
                    newZvs = np.append(newZvs, self.varZvs[v])
                else:
                    newVs = np.append(newVs, self.varVs[v])
                    newVs = np.append(newVs, self.varVs[v])
                    newZvs = np.append(newZvs, self.varZvs[v-1])
                    newZvs = np.append(newZvs, self.varZvs[v])

        #self.fspulVs = np.ma.masked_where(self.varVs == 0, self.varVs)
        aVS.plot(newVs,newZvs, 'k-', markersize=7)
        aVS.grid(linestyle='--')

        # # G0
        aG0.set_title('Modulo di taglio massimo', fontsize=11)
        aG0.set_xlabel('G0 (MPa)', fontsize=9.5)
        aG0.set_ylabel('Prof (m)', fontsize=9.5)
        aG0.invert_yaxis()
        aG0.set_ylim([self.varZvs.max(), 0])
        aG0.set_yticks(np.arange(0, self.varZvs.max(), 1))
        idx1 = (np.abs(scaleX - self.varG0.max() / 5)).argmin()
        if self.varG0.max() / scaleX[idx1] < 2:
            fatt1 = scaleX[idx1 - 1]
        if self.varG0.max() / scaleX[idx1] > 8:
            fatt1 = scaleX[idx1 + 1]
        if self.varG0.max() / scaleX[idx1] < 8 or self.varG0.max() / scaleX[idx1] > 2:
            fatt1 = scaleX[idx1]
        aG0.set_xticks(np.arange(0, self.varG0.max(), fatt1))
        #
        newG0 = []
        newZvs2 = []
        for v in range(0,len(self.varVs)):
            if self.varVs[v]!=0:
                    newG0 = np.append(newG0, self.varG0[v])
                    newZvs2 = np.append(newZvs2, self.varZvs[v])
        self.fspulG = np.ma.masked_where(newG0 == 0, newG0)
        aG0.plot(self.fspulG, newZvs2, 'k-', markersize=7)
        aG0.grid(linestyle='--')

        #
        self.sceneBP3 = QtWidgets.QGraphicsScene()
        canvas = FigureCanvas(self.figBase3DMT)
        canvas.setGeometry(0, 0,725, 620)
        self.sceneBP3.addWidget(canvas)
        self.dlg16.Seis.setScene(self.sceneBP3)

