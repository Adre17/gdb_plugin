#-*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'setup.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

#* Released under the GNU General Public License

##CPT_Office-V1.1_ evaluating liquefaction potential from CPTE and CPTU 
##Copyright(C) 2017 Umberto Grechi

##_CPT_Office-V1.1_ is free software; you can redistribute it and/or
##modify it under the terms of the GNU General Public License
##as published by the Free Software Foundation; either version 3
##of the License, or (at your option) any later version.

##_CPT_Office-V1.1_ is distributed in the hope that it will be useful,
##but WITHOUT ANY WARRANTY; without even the implied warranty of
##MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##GNU General Public License for more details.

##You should have received a copy of the GNU General Public License
##along with this program.  If not, see <http://www.gnu.org/licenses/>

from shapely.geometry import Point
from shapely.geometry.polygon import Polygon
from matplotlib import path
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
import shapely.geometry as sg
import numpy as np
import matplotlib.patches as mpatches
#per plot nellaQgraphic view
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from shapely import speedups
speedups.disable()

from .GDB_plugin import*
from .Elab_data import*

# solo per CPTM
def value_Strat_schmertmann(self):
    #sabbie calcaree o marne
    self.Lito1S=sg.Polygon([(0.27,1),(0.27,1000),(0.01,1000),(0.01,1),(0.27,1)])
    #sabbia addensata o cementata
    self.Lito2S=sg.Polygon([(0.27,100),(0.27,1000),(2.1 ,1000),(2.1 ,100),(0.27,100)])
    #sabbia
    self.Lito3S=sg.Polygon([(0.27,20),(0.27,100),(2.1,100),(2.1,20),(0.27,20)])
    #sabbia sciolta
    self.Lito4S=sg.Polygon([(0.27,1),(0.27,20),(2.1,20),(2.1,1),(0.27,1)])
    #sabbie argillose e limi
    self.Lito5S=sg.Polygon([(2.1,100),(2.1,1),(2.5,8.43375),(2.910902,15.08537768),(3,18.357),(3.5,48.81175),(4,99.798),(4.002,100),(2.1,100)])
    #limi e sabbie
    self.Lito6S=sg.Polygon([(4.002,100),(4.5,171.31575),(5,263.365),(5.5,375.94575),(6,509.058),(6.5,662.70175),(7,836.877),(7.4225,1000),(2.1,1000),(2.1,100),(4.002,100)])
    #argille sabbiose e limose
    self.Lito7S=sg.Polygon([(2.910902,1),(3,1.168),(3.37,6.039328518),(3.5,7.7876875),(3.81,12.11668475),(4,14.926),(4.5,23.1435625),(5,33.001),(5.5,45.0589375),(6,59.878),
                              (6.5,78.0188125),(7,100.042),(7.5,126.5081875),(8,157.978),(8.5,195.0120625),(9,238.171),(9.5,288.0154375),(10,345.106),(10.5,410.0033125),
                                (11,483.268),(11.5,565.4606875),(12,657.142),(12.5,758.8725625),(13,871.213),(13.5,994.7239375),(13.524,1000),(7.4225,1000),(7,836.877),
                                 (6.5,662.70175),(6,509.058),(5.5,375.94575),(5,263.365),(4.5,171.31575),(4,99.798),(3.5,48.81175),(3,18.357),(2.910902,15.08537768),
                                  (2.5,8.43375),(2.1,1),(2.910902,1)])
    #argilla inorganica da compatta a molto compatta
    self.Lito8S=sg.Polygon([(3.81,12.11668475),(4,14.926),(4.5,23.1435625),(5,33.001),(5.5,45.0589375),(6,59.878),(6.5,78.0188125),(7,100.042),(7.5,126.5081875),(8,157.978),
                             (8.5,195.0120625),(9,238.171),(9.5,288.0154375),(10,345.106),(10.5,410.0033125),(11,483.268),(11.5,565.4606875),(12,657.142),(12.5,758.8725625),
                              (13,871.213),(13.5,994.7239375),(13.524,1000),(100,1000),(100,16.7488625),(8.5,16.7488625),(8,16.7078),(7.5,16.1279375),(7,14.9495),
                               (6.5,13.1127125),(6,10.5578),(5.73,8.858507445),(3.81,12.11668475)])
    #argilla inorganica media consistenza
    self.Lito9S=sg.Polygon([(3.37,6.039328518),(3.5,7.7876875),(3.81,12.11668475),(5.73,8.858507445),(5.23,5.0807745),(3.37,6.039328518)])
    #argilla inorganica bassa consistenza
    self.Lito10S=sg.Polygon([(2.910902,1),(3,1.168),(3.37,6.039328518),(5.23,5.0807745),(5,3.0545),(5,1),(2.910902,1)])
    #argille organiche e terreni misti
    self.Lito11S=sg.Polygon([(5,1),(5,3.0545),(5.23,5.0807745),(5.5,7.2249875),(5.73,8.858507445),(6,10.5578),(6.5,13.1127125),(7,14.9495),(7.5,16.1279375),(8,16.7078),
                              (8.5,16.7488625),(100,16.7488625),(100,1),(5,1)])

def value_SBT_1990(self):
#creo liminti grafico SBT robertson 1990 9 zone
    self.Lito1=sg.Polygon([(0.1,1),(0.09912758, 10.097546),(0.11765574, 10.18022),(0.14718539, 10.015544),
      (0.17571964, 9.7054388),(0.21537356, 9.3285577),(0.24899722, 8.8315534),(0.2859149, 8.4294844),
      (0.29553785, 8.2931282),(0.32386156, 7.9710899),(0.36223065, 7.6081947),(0.41311185, 6.9717042),
      (0.47436205, 6.5010697),(0.52695787, 5.9571997),(0.57802288, 5.5485835),(0.64211231, 5.0489846),
      (0.69955247, 4.669911),(0.77711673, 4.1806893),(0.86328107, 3.6864679),(0.95899906, 3.250671),(1.0591248, 2.820025),
      (1.152746, 2.4693355),(1.2400697, 2.1422001),(1.341824, 1.8584033),(1.4322716, 1.6140828),(1.5303051, 1.388879),
      (1.6019581, 1.2147465),(1.6671985, 1.1053698),(1.6999806, 1.0140768),(0.1, 1.0)])

    self.Lito2=sg.Polygon([(1.6999806, 1.0),(1.6671985, 1.1053698),(1.8269793, 1.1689364),(2.0295492, 1.2246923),
      (2.2855209, 1.3042045),(2.5888556, 1.4002505),(2.9153684, 1.5156785),(3.3248794, 1.6521286),
      (3.7698264, 1.8454596),(4.3541224, 2.1075477),(4.9368063, 2.3900932),(5.4841844, 2.7327103),
      (6.0097769, 3.0990675),(6.6372368, 3.5723261),(7.230971, 4.1467378),(7.8701514, 4.7799862),
      (8.4663372, 5.509938),(9.0988227, 6.3959078),(9.5899906, 7.1944618),(10.03902, 7.8512893),
      (10.0, 1.0223795),(1.6999806, 1.0)])

    self.Lito3=sg.Polygon([(1.6671985, 1.1053698),(1.6019581, 1.2147465),(1.5303051, 1.388879),(1.4322716, 1.6140828),
      (1.341824, 1.8584033),(1.2400697, 2.1422001),(1.152746, 2.449282),(1.0591248, 2.820025),(0.95899906, 3.250671),
      (0.86328107, 3.6864679),(0.77711673, 4.1806893),(0.69955247, 4.669911),(0.74235751, 4.8191224),(0.81350347, 5.0489846),
      (0.90988227, 5.3767862),(1.0246389, 5.8200151),(1.152746, 6.2486205),(1.2818063, 6.7087898),(1.4322716, 7.2533666),
      (1.6019581, 7.9155718),(1.8040011, 8.7598321),(2.0574024, 9.7849023),(2.2855209, 11.187557),(2.5389325, 12.584367),
      (2.8040137, 14.056982),(3.0727443, 16.072033),(3.4134409, 18.354547),(3.7698264, 21.656177),(4.1593693, 25.37374),
      (4.6205476, 30.64366),(4.9996882, 35.862242),(5.4099393, 43.971403),(5.8197572, 53.165803),(6.1698533, 63.686476),
      (7.1330777, 58.83637),(8.5159393, 56.617553),(9.4693758, 55.701702),(10.0, 56.157761),(10.0, 7.8512893),(9.5899906, 7.1944618),
      (9.0988227, 6.3959078),(8.4663372, 5.509938),(7.8701514, 4.7799862),(7.230971, 4.1467378),(6.6372368, 3.5723261),
      (6.0097769, 3.0990675),(5.4841844, 2.7327103),(4.9368063, 2.3900932),(4.3541224, 2.1075477),(3.7698264, 1.8454596),
      (3.3248794, 1.6521286),(2.9153684, 1.5156785),(2.5888556, 1.4002505),(2.2855209, 1.3042045),(2.0295492, 1.2246923),
      (1.8269793, 1.1689364),(1.6671985, 1.1053698)])

    self.Lito4=sg.Polygon([(0.69955247, 4.669911),(0.64211231, 5.0489846),(0.57802288, 5.5485835),(0.52695787, 5.9571997),(0.47436205, 6.5010697),
      (0.41311185, 6.9717042),(0.36223065, 7.6081947),(0.32386156, 7.9710899),(0.29553785, 8.2931282),(0.31761628, 8.6281772),(0.35043613, 9.0397234),
      (0.394634, 9.4819385),(0.45891644, 10.335557),(0.53418976, 11.096702),(0.62120461, 11.9139),(0.71330777, 12.880995),(0.83030738, 14.172073),
      (0.95899906, 15.683641),(1.06533, 17.115498),(1.199692, 18.963083),(1.3869854, 21.15747),(1.6019581, 24.388428),(1.8520524, 28.541751),
      (2.1266477, 32.633177),(2.3925353, 38.190571),(2.6759879, 43.665145),(2.9726933, 51.101271),(3.2166187, 60.787059),(3.4839497, 71.637981),
      (3.693532, 85.914028),(3.8929143, 102.91506),(4.1311185, 91.491932),(4.4138777, 83.253926),(4.7760599, 75.757676),(5.2033024, 69.419899),
      (5.6687639, 65.721365),(6.1698533, 63.686476),(5.8197572, 53.165803),(5.4099393, 43.971403),(4.9996882, 35.862242),(4.6205476, 30.64366),
      (4.1593693, 25.37374),(3.7698264, 21.656177),(3.4134409, 18.354547),(3.0727443, 16.072033),(2.8040137, 14.056982),(2.5389325, 12.584367),
      (2.2855209, 11.187557),(2.0574024, 9.7849023),(1.8040011, 8.7598321),(1.6019581, 7.9155718),(1.4322716, 7.2533666),(1.2818063, 6.7087898),
      (1.152746, 6.2486205),(1.0246389, 5.8200151),(0.90988227, 5.3767862),(0.81350347, 5.0489846),(0.74235751, 4.8191224),(0.69955247, 4.669911)])

    self.Lito5=sg.Polygon([(0.29553785, 8.2931282),(0.2859149, 8.4294844),(0.24899722, 8.8315534),(0.21537356, 9.3285577),(0.17571964, 9.7054388),
      (0.14618569, 10.015544),(0.11765574, 10.18022),(0.1, 10.097546),(0.1, 27.210631),(0.10937061, 27.210631),(0.12893161, 27.210631),
      (0.15407701, 27.884481),(0.17917481, 28.309962),(0.20978571, 29.214513),(0.24586555, 30.147966),(0.28397294, 31.622777),(0.3260763, 32.862059),
      (0.38439525, 35.282131),(0.43541224, 37.572797),(0.50338787, 40.670066),(0.56302612, 43.665145),(0.67677448, 48.378712),(0.80876511, 54.418983),
      (0.92777328, 61.213406),(1.0376901, 67.821273),(1.1685661, 75.757676),(1.2893161, 83.935569),(1.4519278, 96.64073),(1.6239432, 112.31082),
      (1.7795784, 128.26094),(1.965378, 147.84768),(2.168464, 171.62082),(2.362444, 202.4921),(2.5216879, 233.41468),(2.7127127, 202.4921),
      (2.9153684, 174.44263),(3.1331637, 153.82084),(3.3476167, 132.3591),(3.5977035, 114.95811),(3.8929143, 102.91506),(3.693532, 85.914028),
      (3.4839497, 71.637981),(3.2166187, 60.787059),(2.9726933, 51.101271),(2.6759879, 43.665145),(2.3925353, 38.190571),(2.1266477, 32.633177),
      (1.8520524, 28.541751),(1.6019581, 24.388428),(1.3869854, 21.15747),(1.199692, 18.963083),(1.06533, 17.115498),(0.95899906, 15.683641),
      (0.83030738, 14.172073),(0.71330777, 12.880995),(0.62120461, 11.9139),(0.53418976, 11.096702),(0.45891644, 10.335557),(0.394634, 9.4819385),
      (0.35043613, 9.0397234),(0.31761628, 8.6281772),(0.29553785, 8.2931282)])

    self.Lito6=sg.Polygon([(0.1, 27.210631),(0.1, 156.16795),(0.11382477, 160.03532),(0.12981331, 165.14872),(0.15007949, 171.62082),(0.1711606, 175.87088),
      (0.19387706, 184.25955),(0.21982237, 194.85579),(0.24730601, 202.4921),(0.2859149, 217.4043),(0.32386156, 233.41468),(0.37187903, 254.42801),
      (0.43541224, 281.89302),(0.49705669, 314.87996),(0.55216882, 348.87064),(0.6050875, 386.08054),(0.67677448, 445.0389),(0.7230971, 500.60375),
      (0.78243107, 572.36471),(0.85242346, 659.77054),(0.92236935, 759.6387),(0.97216021, 868.53202),(1.0107673, 1000),(1.3869854, 1000),(1.4618569, 835.77824),
      (1.5497971, 708.35824),(1.6785997, 595.4887),(1.7917481, 504.70245),(1.9256023, 431.25944),(2.0574024, 374.12657),(2.1982237, 319.68463),(2.3463981, 277.65634),
      (2.5216879, 233.41468),(2.362444, 202.4921),(2.168464, 171.62082),(1.965378, 147.84768),(1.7795784, 128.26094),(1.6239432, 112.31082),(1.4519278, 96.64073),
      (1.2893161, 83.935569),(1.1685661, 75.757676),(1.0376901, 67.821273),(0.92777328, 61.213406),(0.80876511, 54.418983),(0.67677448, 48.378712),(0.56302612, 43.665145),
      (0.50338787, 40.670066),(0.43541224, 37.572797),(0.38439525, 35.282131),(0.3260763, 32.862059),(0.28397294, 31.622777),(0.24586555, 30.147966),(0.20978571, 29.214513),
      (0.17917481, 28.309962),(0.15407701, 27.884481),(0.12893161, 27.210631),(0.10937061, 27.210631),(0.1, 27.210631)])

    self.Lito7=sg.Polygon([(0.1, 156.16795),(0.11382477, 160.03532),(0.12981331, 165.14872),(0.15007949, 171.62082),(0.1711606, 175.87088),(0.19387706, 184.25955),
      (0.21982237, 194.85579),(0.24730601, 202.4921),(0.2859149, 217.4043),(0.32386156, 233.41468),(0.37187903, 254.42801),(0.43541224, 281.89302),(0.49705669, 314.87996),
      (0.55216882, 348.87064),(0.6050875, 386.08054),(0.67677448, 445.0389),(0.7230971, 500.60375),(0.78243107, 572.36471),(0.85242346, 659.77054),(0.92236935, 759.6387),
      (0.97216021, 868.53202),(1.0107673, 1000),(0.1, 1000),(0.1, 156.16795)])

    self.Lito8=sg.Polygon([(1.3869854, 1000),(1.4704216, 835.77824),(1.5497971, 708.35824),(1.6785997, 595.4887),(1.7917481, 504.70245),(1.9256023, 431.25944),
      (2.0574024, 374.12657),(2.1982237, 319.68463),(2.5216879, 233.41468),(2.7127127, 202.4921),(2.9153684, 174.44263),(3.1331637, 153.82084),
      (3.3476167, 132.3591),(3.5977035, 114.95811),(3.8929143, 102.91506),(4.0239369, 118.63122),(4.241155, 147.84768),(4.3838982, 188.60277),
      (4.5006678, 231.51911),(4.5891644, 275.40148),(4.7114014, 348.87064),(4.7760599, 437.83991),(4.8368943, 546.307),(4.8699716, 675.3221),
      (4.9368063, 790.32871),(4.9368063, 1000),(1.3869854, 1000)])

    self.Lito9=sg.Polygon([(4.9368063, 1000),(4.9368063, 790.32871),(4.8699716, 675.3221),(4.8368943, 546.307),(4.7760599, 437.83991),(4.7114014, 348.87064),
      (4.5891644, 275.40148),(4.5006678, 231.51911),(4.3838982, 188.60277),(4.241155, 147.84768),(4.0239369, 118.63122),(3.8929143, 102.91506),
      (4.1311185, 91.491932),(4.4138777, 83.253926),(4.7760599, 75.757676),(5.2033024, 69.419899),(5.6687639, 65.721365),(6.1698533, 63.686476),
      (7.1330777, 58.83637),(8.5159393, 56.617553),(9.4693758, 55.701702),(10.0, 56.157761),(10.0, 1000),(4.9368063, 1000)])

    #creo liminti grafico SBT robertson 1986 12 zone per litologia
def value_SBT_1986(self):
    self.Lit1G=sg.Polygon([(0.0, 1.0), (0.0, 9.32164517783654), (0.7628418425804216, 8.20603694524892), (1.077016992433161, 7.780922107940794),
                           (1.52983454650639, 5.565222960629264), (1.841163775185746, 4.4199001572965715), (1.910683668632025, 3.9744453507172017),
                           (2.2164144274303186, 2.4910502064799735), (2.338950822235999, 1.2325918334050954),(0.0, 1.0)])

    self.Lit2G=sg.Polygon([(0.0, 1.0), (2.338950822235999, 1.2325918334050954), (4.061373585527016, 1.474565070259574), (8.0, 4.664249656829872), (8.0, 1.0),(0.0, 1.0)])

    self.Lit3G=sg.Polygon([(5.0895121536897925, 56.20069089252233), (4.817860415373678, 35.14682975259893), (3.817608268248106, 13.434068881880968),
                           (2.856306176592975, 6.6185691248685545), (1.910683668632025, 3.9744453507172017), (2.2164144274303186, 2.4910502064799735),
                           (2.338950822235999, 1.2325918334050954), (4.061373585527016, 1.474565070259574), (8.0, 4.664249656829872), (8.0, 56.20069089252233),
                           (5.0895121536897925, 56.20069089252233)])

    self.Lit4G=sg.Polygon([(1.52983454650639, 5.565222960629264), (2.8165345660589427, 11.675842948623945), (3.543930837712131, 21.49971468690978),
                           (4.3602109430586005, 49.85896255042825), (4.535213455617467, 68.74423210279109), (4.814178321729266, 56.20069089252233),
                           (5.0895121536897925, 56.20069089252233), (4.817860415373678, 35.14682975259893), (3.817608268248106, 13.434068881880968),
                           (2.856306176592975, 6.6185691248685545), (1.910683668632025, 3.9744453507172017),(1.52983454650639, 5.565222960629264)])

    self.Lit5G=sg.Polygon([(3.856811566766386, 112.20453330443499), (3.3650907876466096, 50.501636586578535), (2.9066027179950598, 30.1661307322457),
                           (2.1315395526317236, 15.891022854606806), (0.7628418425804216, 8.20603694524892), (1.077016992433161, 7.780922107940794),
                           (1.52983454650639, 5.565222960629264), (2.8165345660589427, 11.675842948623945), (3.543930837712131, 21.49971468690978),
                           (4.3602109430586005, 49.85896255042825), (4.535213455617467, 68.74423210279109),(3.856811566766386, 112.20453330443499)])

    self.Lit6G=sg.Polygon([(0.0, 15.043703935856918), (0.9616231526559985, 20.43610808049925), (2.0055022398090827, 41.7669556710361), (2.87199010953746, 115.96070977362841),
                           (3.166837399346941, 191.77585114677433), (3.856811566766386, 112.20453330443499), (3.3650907876466096, 50.501636586578535),
                           (2.9066027179950598, 30.1661307322457), (2.1315395526317236, 15.891022854606806), (0.7628418425804216, 8.20603694524892),
                           (0.0, 9.32164517783654),(0.0, 15.043703935856918)])

    self.Lit7G=sg.Polygon([(0.0, 29.414080037770216), (0.8454904218605512, 48.627609676133474), (1.783306927965998, 116.5400814746164), (2.1404512710530117, 191.16088964175188),
                           (2.428246812609181, 340.39223454131434), (3.166837399346941, 191.77585114677433), (2.87199010953746, 115.96070977362841),
                           (2.438746174673272, 69.59400710332046), (2.0055022398090827, 41.7669556710361), (0.9616231526559985, 20.43610808049925), (0.0, 15.043703935856918),
                           (0.0, 29.414080037770216)])

    self.Lit8G=sg.Polygon([(0.0, 68.46158509944512), (0.6256702024231144, 93.41425083644695), (1.387832188337382, 199.47543019439317), (1.750240212639613, 460.8417596739697),
                   (1.750240212639613, 1000.0), (1.9848977808419, 518.9220405716896), (2.428246812609181, 340.39223454131434), (2.1404512710530117, 191.16088964175188),
                   (1.783306927965998, 116.5400814746164), (0.8454904218605512, 48.627609676133474), (0.0, 29.414080037770216),(0.0, 68.46158509944512)])

    self.Lit9G=sg.Polygon([(1.293071763096075, 1000.0), (1.153226143115157, 470.425631987483), (0.8868057690602404, 317.44698624414724),
                           (0.5361965443437475, 221.39035306550585), (0.0, 171.9918466972986), (0.0, 68.46158509944512), (0.6256702024231144, 93.41425083644695),
                           (1.387832188337382, 199.47543019439317), (1.750240212639613, 460.8417596739697), (1.750240212639613, 1000.0),(1.293071763096075, 1000.0)])

    self.Lit10G=sg.Polygon([(0.0, 1000.0), (1.293071763096075, 1000.0), (1.153226143115157, 470.425631987483), (0.8868057690602404, 317.44698624414724),
                            (0.5361965443437475, 221.39035306550585), (0.0, 171.9918466972986),(0.0, 1000.0)])

    self.Lit11G=sg.Polygon([(3.856811566766386, 112.20453330443499), (4.457212610357701, 413.33078382897315), (4.634603827782409, 1000.0), (8.0, 1000.0),
                            (8.0, 56.20069089252233), (4.814178321729266, 56.20069089252233),(3.856811566766386, 112.20453330443499)])

    self.Lit12G=sg.Polygon([(1.750240212639613, 1000.0), (4.634603827782409, 1000.0), (4.457212610357701, 413.33078382897315), (3.856811566766386, 112.20453330443499),
                            (3.166837399346941, 191.77585114677433), (2.428246812609181, 340.39223454131434), (1.9848977808419, 518.9220405716896),(1.750240212639613, 1000.0)])

def Lito_Begemann(self):
    self.Strati0B=[]
    self.HS0B=[]
    self.Strati1B=[]
    self.HS1B=[]
    self.Strati2B=[]
    self.HS2B=[]
    self.Strati3B=[]
    self.HS3B=[]
    self.Strati4B=[]
    self.HS4B=[]
    self.Strati5B=[]
    self.HS5B=[]
    self.Strati6B=[]
    self.HS6B=[]
    self.TipoT=[]
    self.TipoNB=[]
    
    for j in range(0,len(self.H)):
            if self.Rf[j]<=1.6 and self.Rf[j]!=0:
                #da sabbia grossolana con ghiaia fino a sabbia fine
                self.Strati1B=np.append(self.Strati1B,6)
                self.HS1B=np.append(self.HS1B,self.H[j])
                self.TipoT=np.append(self.TipoT,'I')
                self.TipoNB=np.append(self.TipoNB,6)
            if self.Rf[j]>1.6 and self.Rf[j]<=2.2:
                #sabbia limosa
                self.Strati2B=np.append(self.Strati2B,5)
                self.HS2B=np.append(self.HS2B,self.H[j])
                self.TipoT=np.append(self.TipoT,'CI')
                self.TipoNB=np.append(self.TipoNB,5)
            if self.Rf[j]>2.2 and self.Rf[j]<=3.2:
                #limo sabbioso argilloso
                self.Strati3B=np.append(self.Strati3B,4)
                self.HS3B=np.append(self.HS3B,self.H[j])
                self.TipoT=np.append(self.TipoT,'CI')
                self.TipoNB=np.append(self.TipoNB,4)
            if self.Rf[j]>3.2 and self.Rf[j]<=4.1:
                # miscela di argilla e limo
                self.Strati4B=np.append(self.Strati4B,3)
                self.HS4B=np.append(self.HS4B,self.H[j])
                self.TipoT=np.append(self.TipoT,'C')
                self.TipoNB=np.append(self.TipoNB,3)
            if self.Rf[j]>4.1 and self.Rf[j]<=7:
                # argilla
                self.Strati5B=np.append(self.Strati5B,2)
                self.HS5B=np.append(self.HS5B,self.H[j])
                self.TipoT=np.append(self.TipoT,'C')
                self.TipoNB=np.append(self.TipoNB,2)
            if self.Rf[j]>7:
                # terreno organico
                self.Strati6B=np.append(self.Strati6B,1)
                self.HS6B=np.append(self.HS6B,self.H[j])
                self.TipoT=np.append(self.TipoT,'C')
                self.TipoNB=np.append(self.TipoNB,1)
            if self.Rf[j]<=0:
                #non valutabile
                self.Strati0B=np.append(self.Strati0B,0)
                self.HS0B=np.append(self.HS0B,self.H[j])
                self.TipoT=np.append(self.TipoT,'CI')
                self.TipoNB=np.append(self.TipoNB,0)
    
def Lito_schmertmann(self):
    #controlla se i punti sono nei poligoni x schmertmann
    #Variabili litologia e profondità
    self.Strati0S=[]
    self.HS0S=[]
    self.Strati1S=[]
    self.HS1S=[]
    self.Strati2S=[]
    self.HS2S=[]
    self.Strati3S=[]
    self.HS3S=[]
    self.Strati4S=[]
    self.HS4S=[]
    self.Strati5S=[]
    self.HS5S=[]
    self.Strati6S=[]
    self.HS6S=[]
    self.Strati7S=[]
    self.HS7S=[]
    self.Strati8S=[]
    self.HS8S=[]
    self.Strati9S=[]
    self.HS9S=[]
    self.Strati10S=[]
    self.HS10S=[]
    self.Strati11S=[]
    self.HS11S=[]
    self.LitoT2S=[]
    self.TipoT=[]
    self.TipoN=[]

    Punti=self.pointSBT
    
    for j in range(0,len(self.H)):
            ckContains=0
            if self.Lito1S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati1S=np.append(self.Strati1S,11)
                self.TipoN=np.append(self.TipoN,11)
                self.HS1S=np.append(self.HS1S,self.H[j])
                self.TipoT=np.append(self.TipoT,'I')
                ckContains=1
            if self.Lito2S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati2S=np.append(self.Strati2S,10)
                self.TipoN=np.append(self.TipoN,10)
                self.HS2S=np.append(self.HS2S,self.H[j])
                self.TipoT=np.append(self.TipoT,'I')
                ckContains=1
            if self.Lito3S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati3S=np.append(self.Strati3S,8)
                self.TipoN=np.append(self.TipoN,8)
                self.HS3S=np.append(self.HS3S,self.H[j])
                self.TipoT=np.append(self.TipoT,'I')
                ckContains=1
            if self.Lito4S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati4S=np.append(self.Strati4S,7)
                self.TipoN=np.append(self.TipoN,7)
                self.HS4S=np.append(self.HS4S,self.H[j])
                self.TipoT=np.append(self.TipoT,'I')
                ckContains=1
            if self.Lito5S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati5S=np.append(self.Strati5S,6)
                self.TipoN=np.append(self.TipoN,6)
                self.HS5S=np.append(self.HS5S,self.H[j])
                self.TipoT=np.append(self.TipoT,'CI')
                ckContains=1
            if self.Lito6S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati6S=np.append(self.Strati6S,5)
                self.TipoN=np.append(self.TipoN,5)
                self.HS6S=np.append(self.HS6S,self.H[j])
                self.TipoT=np.append(self.TipoT,'CI')
                ckContains=1
            if self.Lito7S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati7S=np.append(self.Strati7S,4)
                self.TipoN=np.append(self.TipoN,4)
                self.HS7S=np.append(self.HS7S,self.H[j])
                self.TipoT=np.append(self.TipoT,'C')
                ckContains=1
            if self.Lito8S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati8S=np.append(self.Strati8S,9)
                self.TipoN=np.append(self.TipoN,9)
                self.HS8S=np.append(self.HS8S,self.H[j])
                self.TipoT=np.append(self.TipoT,'C')
                ckContains=1
            if self.Lito9S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati9S=np.append(self.Strati9S,3)
                self.TipoN=np.append(self.TipoN,3)
                self.HS9S=np.append(self.HS9S,self.H[j])
                self.TipoT=np.append(self.TipoT,'C')
                ckContains=1
            if self.Lito10S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati10S=np.append(self.Strati10S,1)
                self.TipoN=np.append(self.TipoN,1)
                self.HS10S=np.append(self.HS10S,self.H[j])
                self.TipoT=np.append(self.TipoT,'C')
                ckContains=1
            if self.Lito11S.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati11S=np.append(self.Strati11S,2)
                self.TipoN=np.append(self.TipoN,2)
                self.HS11S=np.append(self.HS11S,self.H[j])
                self.TipoT=np.append(self.TipoT,'C')
                ckContains=1
            if ckContains==0:
                self.Strati0S=np.append(self.Strati0S,0)
                self.TipoN=np.append(self.TipoN,0)
                self.HS0S=np.append(self.HS0S,self.H[j])
                self.TipoT=np.append(self.TipoT,'CI')

def SBT_Index_Limit(self):
    #liimti aree indici
    #lito 1,8 e 9 non rappresentabili
    self.A7=sg.Polygon([(1,0),(1,self.H.max()),(1.31,self.H.max()),(1.31,0)])
    self.A6=sg.Polygon([(1.31,0),(1.31,self.H.max()),(2.05,self.H.max()),(2.05,0)])
    self.A5=sg.Polygon([(2.05,0),(2.05,self.H.max()),(2.6,self.H.max()),(2.6,0)])
    self.A4=sg.Polygon([(2.6,0),(2.6,self.H.max()),(2.95,self.H.max()),(2.95,0)])
    self.A3=sg.Polygon([(2.95,0),(2.95,self.H.max()),(3.6,self.H.max()),(3.6,0)])
    self.A2=sg.Polygon([(3.6,0),(3.6,self.H.max()),(4,self.H.max()),(4,0)])

def SBTgamma(self):
    #controlla se i punti sono nei poligoni x grafico robertson 1986
    self.Gamma=[]
    for j in range(0,len(self.pointSBT)):
        if self.Rf[j]>8:
            self.Gamma=np.append(self.Gamma,17.5)
        elif self.pointSBT[j].all()==0:
            self.Gamma=np.append(self.Gamma,17.0)
        elif self.Lit1G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,17.5)
        elif self.Lit2G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,12.5)
        elif self.Lit3G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,17.5)
        elif self.Lit4G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,18.0)
        elif self.Lit5G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,18.0)
        elif self.Lit6G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,18.0)
        elif self.Lit7G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,18.5)
        elif self.Lit8G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,19.0)
        elif self.Lit9G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,19.5)
        elif self.Lit10G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,20)
        elif self.Lit11G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,20.5)
        elif self.Lit12G.contains(sg.Point(self.pointSBT[j]))==True:
            self.Gamma=np.append(self.Gamma,19.0)
        else:
            self.Gamma=np.append(self.Gamma,17.0)

def SBT_Lito_1986(self):
    self.Strati0_12=[]
    self.HS0_12=[]
    self.Strati1_12=[]
    self.HS1_12=[]
    self.Strati2_12=[]
    self.HS2_12=[]
    self.Strati3_12=[]
    self.HS3_12=[]
    self.Strati4_12=[]
    self.HS4_12=[]
    self.Strati5_12=[]
    self.HS5_12=[]
    self.Strati6_12=[]
    self.HS6_12=[]
    self.Strati7_12=[]
    self.HS7_12=[]
    self.Strati8_12=[]
    self.HS8_12=[]
    self.Strati9_12=[]
    self.HS9_12=[]
    self.Strati10_12=[]
    self.HS10_12=[]
    self.Strati11_12=[]
    self.HS11_12=[]
    self.Strati12_12=[]
    self.HS12_12=[]
    self.LitoT1=[]

    
    Punti=self.pointSBT        
    
    #controlla se i punti sono nei poligoni x grafico robertson 1986
    for j in range(0,len(self.pointSBT)):
        ckContains=0
        if self.Lit1G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati1_12=np.append(self.Strati1_12,1)
            self.HS1_12=np.append(self.HS1_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,1)
            ckContains=1
        if self.Lit2G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati2_12=np.append(self.Strati2_12,2)
            self.HS2_12=np.append(self.HS2_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,2)
            ckContains=1
        if self.Lit3G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati3_12=np.append(self.Strati3_12,3)
            self.HS3_12=np.append(self.HS3_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,3)
            ckContains=1
        if self.Lit4G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati4_12=np.append(self.Strati4_12,4)
            self.HS4_12=np.append(self.HS4_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,4)
            ckContains=1
        if self.Lit5G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati5_12=np.append(self.Strati5_12,5)
            self.HS5_12=np.append(self.HS5_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,5)
            ckContains=1
        if self.Lit6G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati6_12=np.append(self.Strati6_12,6)
            self.HS6_12=np.append(self.HS6_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,6)
            ckContains=1
        if self.Lit7G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati7_12=np.append(self.Strati7_12,7)
            self.HS7_12=np.append(self.HS7_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,7)
            ckContains=1
        if self.Lit8G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati8_12=np.append(self.Strati8_12,8)
            self.HS8_12=np.append(self.HS8_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,8)
            ckContains=1
        if self.Lit9G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati9_12=np.append(self.Strati9_12,9)
            self.HS9_12=np.append(self.HS9_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,9)
            ckContains=1
        if self.Lit10G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati10_12=np.append(self.Strati10_12,10)
            self.HS10_12=np.append(self.HS10_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,10)
            ckContains=1
        if self.Lit11G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati11_12=np.append(self.Strati11_12,11)
            self.HS11_12=np.append(self.HS11_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,11)
            ckContains=1
        if self.Lit12G.contains(sg.Point(Punti[j]))==True and ckContains==0:
            self.Strati12_12=np.append(self.Strati12_12,12)
            self.HS12_12=np.append(self.HS12_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,12)
            ckContains=1
        if ckContains==0:
            self.Strati0_12=np.append(self.Strati0_12,0)
            self.HS0_12=np.append(self.HS0_12,self.H[j])
            self.LitoT1=np.append(self.LitoT1,0)

def SBT_Lito_1990(self):
    #controlla se i punti sono nei poligoni x grafico robertson 1990
    #Variabili litologia e profondità
    self.Strati0=[]
    self.HS0=[]
    self.Strati1=[]
    self.HS1=[]
    self.Strati2=[]
    self.HS2=[]
    self.Strati3=[]
    self.HS3=[]
    self.Strati4=[]
    self.HS4=[]
    self.Strati5=[]
    self.HS5=[]
    self.Strati6=[]
    self.HS6=[]
    self.Strati7=[]
    self.HS7=[]
    self.Strati8=[]
    self.HS8=[]
    self.Strati9=[]
    self.HS9=[]
    self.LitoT2=[]
    #permeabilità SBT
    self.Ksbt=[]
    #scelto metodo litologia
    if self.ChoseLito==0:
       Punti=self.pointSBTn        
    if self.ChoseLito==1:
       Punti=self.pointSBT 
    
    for j in range(0,len(self.H)):
        
        #else:
            ckContains=0
            if self.Lito1.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati1=np.append(self.Strati1,1)
                self.HS1=np.append(self.HS1,self.H[j])
                self.LitoT2=np.append(self.LitoT2,1)
                self.Ksbt=np.append(self.Ksbt,1*10**-8)
                ckContains=1
            if self.Lito2.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati2=np.append(self.Strati2,2)
                self.HS2=np.append(self.HS2,self.H[j])
                self.LitoT2=np.append(self.LitoT2,2)
                self.Ksbt=np.append(self.Ksbt,1*10**-7)
                ckContains=1
            if self.Lito3.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati3=np.append(self.Strati3,3)
                self.HS3=np.append(self.HS3,self.H[j])
                self.LitoT2=np.append(self.LitoT2,3)
                self.Ksbt=np.append(self.Ksbt,3*10**-10)
                ckContains=1
            if self.Lito4.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati4=np.append(self.Strati4,4)
                self.HS4=np.append(self.HS4,self.H[j])
                self.LitoT2=np.append(self.LitoT2,4)
                self.Ksbt=np.append(self.Ksbt,1*10**-8)
                ckContains=1
            if self.Lito5.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati5=np.append(self.Strati5,5)
                self.HS5=np.append(self.HS5,self.H[j])
                self.LitoT2=np.append(self.LitoT2,5)
                self.Ksbt=np.append(self.Ksbt,1*10**-6)
                ckContains=1
            if self.Lito6.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati6=np.append(self.Strati6,6)
                self.HS6=np.append(self.HS6,self.H[j])
                self.LitoT2=np.append(self.LitoT2,6)
                self.Ksbt=np.append(self.Ksbt,1*10**-4)
                ckContains=1
            if self.Lito7.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati7=np.append(self.Strati7,7)
                self.HS7=np.append(self.HS7,self.H[j])
                self.LitoT2=np.append(self.LitoT2,7)
                self.Ksbt=np.append(self.Ksbt,1*10**-2)
                ckContains=1
            if self.Lito8.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati8=np.append(self.Strati8,8)
                self.HS8=np.append(self.HS8,self.H[j])
                self.LitoT2=np.append(self.LitoT2,8)
                self.Ksbt=np.append(self.Ksbt,1*10**-6)
                ckContains=1
            if self.Lito9.contains(sg.Point(Punti[j]))==True and ckContains==0:
                self.Strati9=np.append(self.Strati9,9)
                self.HS9=np.append(self.HS9,self.H[j])
                self.LitoT2=np.append(self.LitoT2,9)
                self.Ksbt=np.append(self.Ksbt,3*10**-9)
                ckContains=1
            if ckContains==0:
                self.Strati0=np.append(self.Strati0,0)
                self.HS0=np.append(self.HS0,self.H[j])
                self.LitoT2=np.append(self.LitoT2,0)
                self.Ksbt=np.append(self.Ksbt,0)
     
def plot_SBT(self):
##    #punti limiti SBT 1986
##    x1, y1 = self.Lit1G.exterior.xy
##    x2, y2 = self.Lit2G.exterior.xy
##    x3, y3 = self.Lit3G.exterior.xy
##    x4, y4 = self.Lit4G.exterior.xy
##    x5, y5 = self.Lit5G.exterior.xy
##    x6, y6 = self.Lit6G.exterior.xy
##    x7, y7 = self.Lit7G.exterior.xy
##    x8, y8 = self.Lit8G.exterior.xy
##    x9, y9 = self.Lit9G.exterior.xy
##    x10, y10 = self.Lit10G.exterior.xy
##    x11, y11 = self.Lit11G.exterior.xy
##    x12, y12 = self.Lit12G.exterior.xy
    #punti limiti SBT 1990
    xL1, yL1 = self.Lito1.exterior.xy
    xL2, yL2 = self.Lito2.exterior.xy
    xL3, yL3 = self.Lito3.exterior.xy
    xL4, yL4 = self.Lito4.exterior.xy
    xL5, yL5 = self.Lito5.exterior.xy
    xL6, yL6 = self.Lito6.exterior.xy
    xL7, yL7 = self.Lito7.exterior.xy
    xL8, yL8 = self.Lito8.exterior.xy
    xL9, yL9 = self.Lito9.exterior.xy
    
    self.figSBT, (axs,axk) = plt.subplots(1,2,figsize=(9,14))
    #aspetto grafico SBT 1990
    axs.set_title('SBT',fontsize=10.5)
    axs.set_xlabel('Rf (%)',fontsize=9.5)
    axs.set_ylabel('qc/Pa',fontsize=9.5)
    axs.text(0.2, 450,'7', fontsize=11)
    axs.text(0.4, 75,'6', fontsize=11)
    axs.text(0.85, 23,'5', fontsize=11)
    axs.text(1.5, 12,'4', fontsize=11)
    axs.text(3, 4,'3', fontsize=11)
    axs.text(5, 1.3,'2', fontsize=11)
    axs.text(0.3, 2,'1', fontsize=11)
    axs.text(3, 450,'8', fontsize=11)
    axs.text(6.5, 450,'9', fontsize=11)
    axs.fill_between(xL1, yL1,facecolor='darkblue')
    axs.fill_between(xL2, yL2,facecolor='saddlebrown')
    axs.fill_between(xL3, yL3,facecolor='darkolivegreen')
    axs.fill_between(xL4, yL4,facecolor='forestgreen')
    axs.fill_between(xL5, yL5,facecolor='goldenrod')
    axs.fill_between(xL6, yL6,facecolor='darkgoldenrod')
    axs.fill_between(xL7, yL7,facecolor='gold')
    axs.fill_between(xL8, yL8,facecolor='darkgrey')
    axs.fill_between(xL9, yL9,facecolor='powderblue')
    try:
        self.XSBTPLT=np.ma.masked_where((self.XSBT<0.1) | (self.XSBT>8),self.XSBT)
        self.YSBTPLT=np.ma.masked_where((self.YSBT<1) | (self.YSBT>1000),self.YSBT)
    except RuntimeWarning:
        pass
    axs.loglog(self.XSBTPLT,self.YSBTPLT,'r.',xL1, yL1,'k', xL2, yL2,'k',
           xL3,yL3,'k',xL4, yL4,'k',xL5, yL5,'k',
           xL6,yL6,'k',xL7, yL7,'k',xL8, yL8,'k',xL9, yL9,'k')
    axs.plot(self.XSBTPLT,self.YSBTPLT,'r.', markersize=9,markeredgecolor='k')
##    #aspetto grafico SBT1986
##    axk.semilogy(self.XSBT,self.YSBT,'r.',x1, y1,'k', x2, y2,'k',
##           x3,y3,'k',x4, y4,'k',x5, y5,'k',
##           x6,y6,'k',x7, y7,'k',x8, y8,'k',x9, y9,'k',x10, y10,'k',x11, y11,'k',
##            x12, y12,'k')
##    #plot punti

    #aspetto grafico SBT 1990 normalizzato
    axk.set_title('SBTn',fontsize=10.5)
    axk.set_xlabel('Rf (%)',fontsize=9.5)
    axk.set_ylabel('Qtn',fontsize=9.5)
    axk.text(0.2, 450,'7', fontsize=11)
    axk.text(0.4, 75,'6', fontsize=11)
    axk.text(0.85, 23,'5', fontsize=11)
    axk.text(1.5, 12,'4', fontsize=11)
    axk.text(3, 4,'3', fontsize=11)
    axk.text(5, 1.3,'2', fontsize=11)
    axk.text(0.3, 2,'1', fontsize=11)
    axk.text(3, 450,'8', fontsize=11)
    axk.text(6.5, 450,'9', fontsize=11)
    axk.fill_between(xL1, yL1,facecolor='darkblue')
    axk.fill_between(xL2, yL2,facecolor='saddlebrown')
    axk.fill_between(xL3, yL3,facecolor='darkolivegreen')
    axk.fill_between(xL4, yL4,facecolor='forestgreen')
    axk.fill_between(xL5, yL5,facecolor='goldenrod')
    axk.fill_between(xL6, yL6,facecolor='darkgoldenrod')
    axk.fill_between(xL7, yL7,facecolor='gold')
    axk.fill_between(xL8, yL8,facecolor='darkgrey')
    axk.fill_between(xL9, yL9,facecolor='powderblue')
    try:
        self.XSBTNPLT=np.ma.masked_where((self.XSBT<0.1) | (self.XSBT>8),self.XSBT)
        self.YSBTNPLT=np.ma.masked_where((self.YSBTN<1) | (self.YSBTN>1000),self.YSBTN)
    except RuntimeWarning:
        pass
    axk.loglog(self.XSBTNPLT,self.YSBTNPLT,'r.',xL1, yL1,'k', xL2, yL2,'k',
           xL3,yL3,'k',xL4, yL4,'k',xL5, yL5,'k',
           xL6,yL6,'k',xL7, yL7,'k',xL8, yL8,'k',xL9, yL9,'k')
    axk.plot(self.XSBTNPLT,self.YSBTNPLT,'r.', markersize=9,markeredgecolor='k')

    self.F_path=self.Folder+"/"+self.nomeP+"_SBT.png"
    self.figSBT.set_size_inches((11.5, 5.5), forward=False)
    self.figSBT.savefig(self.F_path,dpi=250)
    #carica in main
    self.scene1 = QtWidgets.QGraphicsScene()
    canvas = FigureCanvas(self.figSBT)
    
    canvas.setGeometry(0, 0, 950, 450)
    self.scene1.addWidget(canvas)
    self.dlg8.Grafici.setScene(self.scene1)
    self.Kscene=1
    
def plot_Base(self):
    self.figBase, (aQC,aFS,aU,aRf) = plt.subplots(1,4)
    self.figBase.tight_layout()
    #plot qc e fs u
    #array assex
    scaleX=np.array([5,10,20,50,100,200,250])
    #Qc
    aQC.set_title('qc',fontsize=11)
    aQC.set_xlabel('qc (MPa)',fontsize=9.5)
    aQC.set_ylabel('Prof (m)',fontsize=9.5)
    aQC.invert_yaxis()
    aQC.set_ylim([self.H.max(),0])
    aQC.set_yticks(np.arange(0, self.H.max(), 1))
    #passo Qc
##    idx = (np.abs(scaleX-self.Qc.max()/10)).argmin()
##    if self.Qc.max()/scaleX[idx]<2:
##        fatt=scaleX[idx-1]
##    if self.Qc.max()/scaleX[idx]>8:
##        fatt=scaleX[idx+1]
##    if self.Qc.max()/scaleX[idx]<8 or self.Qc.max()/scaleX[idx]>2:  
##        fatt=scaleX[idx]
##    aQC.set_xticks(np.arange(0, self.Qc.max(),scaleX[fatt]))
    aQC.plot(self.Qc,self.H,'k-', markersize=7)
    aQC.grid(linestyle='--')
    #fs
    aFS.set_title('fs',fontsize=11)
    aFS.set_xlabel('fs (kPa)',fontsize=9.5)
    aFS.set_ylabel('Prof (m)',fontsize=9.5)
    aFS.invert_yaxis()
    aFS.set_ylim([self.H.max(),0])
    aFS.set_yticks(np.arange(0, self.H.max(), 1))
##    idx1 = (np.abs(scaleX-self.fs.max()/5)).argmin()
##    if self.Qc.max()/scaleX[idx1]<2:
##        fatt1=scaleX[idx1-1]
##    if self.Qc.max()/scaleX[idx1]>8:
##        fatt1=scaleX[idx1+1]
##    if self.Qc.max()/scaleX[idx1]<8 or self.Qc.max()/scaleX[idx1]>2:  
##        fatt1=scaleX[idx1]
##    aFS.set_xticks(np.arange(0, self.fs.max(), fatt1))

    self.fspul = np.ma.masked_where(self.fs == 0, self.fs)
    aFS.plot(self.fspul,self.H,'k-', markersize=7)
    aFS.grid(linestyle='--')
    #u
    #non plottare se la falda non è presente
    aU.set_title('u',fontsize=11)
    aU.set_xlabel('Pressione (kPa)',fontsize=9.5)
    aU.set_ylabel('Prof (m)',fontsize=9.5)
    aU.invert_yaxis()
    aU.set_ylim([self.H.max(),0])
    aU.set_yticks(np.arange(0, self.H.max(), 1))
##    idx0 = (np.abs(scaleX-self.fs.max()/5)).argmin()
##    if self.Qc.max()/scaleX[idx0]<2:
##        fatt0=scaleX[idx0-1]
##    if self.Qc.max()/scaleX[idx0]>8:
##        fatt0=scaleX[idx0+1]
##    if self.Qc.max()/scaleX[idx0]<8 or self.Qc.max()/scaleX[idx0]>2:  
##        fatt1=scaleX[idx0]
##    aU.set_xticks(np.arange(0, self.u2.max(), idx0))
    self.PU=np.ma.masked_where(self.u2==0,self.u2)
    aU.plot(self.PU,self.H,'k-', markersize=7)
    if self.dlg8.NOFalda.isChecked()==False:
        aU.plot(self.PresU,self.Huu,'c-', markersize=7)
        aU.plot(np.mean(self.u2),(float(self.Hfalda)-0.22),'cv', markersize=8)
    aU.grid(linestyle='--')
    #Rf
    if self.ChoseLito==0:
        titF='Rf'
        labF='Rf(%)'
        assX=self.Rf
    if self.ChoseLito==1 or self.ChoseLito==2:
        titF='Fr'
        labF='Fr(%)'
        assX=self.Fr
    aRf.set_title(titF,fontsize=11)
    aRf.set_xlabel(labF,fontsize=9.5)
    aRf.set_ylabel('Prof (m)',fontsize=9.5)
    aRf.invert_yaxis()
    aRf.set_ylim([self.H.max(),0])
    aRf.set_yticks(np.arange(0, self.H.max(), 1))
    if assX.max()>10:
        for scl in range(0,len(scaleX)):
            if np.abs(assX.max()/scaleX[scl])<=10:
                idx2=scl
                break
        aRf.set_xticks(np.arange(0, assX.max(), scaleX[idx2]))
    else:
       aRf.set_xticks(np.arange(0, assX.max(), 1)) 
    aRf.plot(assX,self.H,'k-', markersize=7)
    aRf.grid(linestyle='--')

    self.F1_path=self.Folder+"/"+self.nomeP+"_dati.png"
    self.figBase.set_size_inches((14, 9), forward=False)
    self.figBase.savefig(self.F1_path,dpi=200)
    
    self.scene2 = QtWidgets.QGraphicsScene()
    canvas = FigureCanvas(self.figBase)
    
    canvas.setGeometry(0, 0, 1450, 620)
    self.scene2.addWidget(canvas)
    self.dlg8.BasePLOT.setScene(self.scene2)

def plot_Lito(self):
    self.figLito, (INDX, LT) = plt.subplots(1,2)
    self.figLito.tight_layout()
    self.figSoloStrat = plt.figure()
    #*self.figSoloStrat.set_size_inches(1.5, 5)
    ST= self.figSoloStrat.add_subplot(111)
    #self.figSoloStrat, (ST) = plt.subplots(1,1)
    #self.figSoloStrat.tight_layout()
    #plot litologia
    LT.set_title('Litologia',fontsize=12)
    LT.set_xlabel('SBT',fontsize=11)
    LT.set_ylabel('Prof (m)',fontsize=11)
    LT.invert_yaxis()
    LT.set_yticks(np.arange(0, self.H.max(), 1))
    LT.set_xticks(np.arange(0, 11, 1))
    LT.set_xlim([0,21])
    LT.set_ylim([self.H.max(),-0.5])
    #solo per grafico stratigrafia
    ST.set_title('Litologia',fontsize=9)
    ST.set_ylabel('Prof (m)',fontsize=8)
    ST.invert_yaxis()
    ST.set_yticks(np.arange(0, self.H.max(), 1))
    ST.set_xticks(np.arange(0, 11, 1))
    for label in (ST.get_xticklabels() + ST.get_yticklabels()):
        label.set_fontsize(7)
    ST.set_xlim([0,15])
    ST.set_ylim([self.H.max(),-0.5])
    if self.ElabStrat==0:
       scalebar=self.H[1]-self.H[2]
    if self.ElabStrat==1:
       self.scalebar=[]
       self.Hmed=[]
       for T in range(len(self.NameS)):
            self.scalebar=np.append(self.scalebar,float(self.letto[T])-float(self.tetto[T]))
            self.Hmed=np.append(self.Hmed,((float(self.letto[T])-float(self.tetto[T]))/2)+float(self.tetto[T])) 
    if self.ChoseLito==0 or self.ChoseLito==1:
        if self.ElabStrat==1:
            dict_plt={'sensitive fine-grained':'darkblue','clay-organic soil':'saddlebrown','clay to silty clay':'darkolivegreen','clayey silt & silty clay':'forestgreen',
                      'silty sand to sandy silt':'goldenrod','clean sands to silty sands':'darkgoldenrod',
                       'dense sand to gravelly sand':'gold','stiff sand to clayey sand':'darkgrey','stiff fine-grained':'powderblue','out of correlation':'lightgray'}
            colorplt=['darkblue','saddlebrown','darkolivegreen','forestgreen','goldenrod','darkgoldenrod','gold','darkgrey','powderblue']
            for PLT in range(len(self.NameS)):
                if self.LTCPTF[PLT]==0:
                   numC=np.uint32(self.LTCPTF[PLT])-1 
                   LT.barh(self.Hmed[PLT],1.5,self.scalebar[PLT],align='center',color='lightgray')
                   ST.barh(self.Hmed[PLT],1.5,self.scalebar[PLT],align='center',color='lightgray')
                else:
                   numC=np.uint32(self.LTCPTF[PLT])-1
                   LT.barh(self.Hmed[PLT],self.LTCPTF[PLT],self.scalebar[PLT],align='center',color=colorplt[numC])
                   ST.barh(self.Hmed[PLT],self.LTCPTF[PLT],self.scalebar[PLT],align='center',color=colorplt[numC])
            patchList = []
            for key in dict_plt:
                data_key = mpatches.Patch(color=dict_plt[key], label=key)
                patchList.append(data_key)
            LT.legend(handles=patchList,loc=1,fontsize=7)
            ST.legend(handles=patchList,loc=1,fontsize=4.5) #,handles=patchList,bbox_to_anchor=(0.5, 1.1)
                            
        else:
            #verifica le litologie non esistenti e mette valori dummy per plot legenda
            if len(self.Strati1)==0:
                self.Strati1=np.append(self.Strati1,-1)
                self.HS1=np.append(self.HS1,-1)
            if len(self.Strati2)==0:
                self.Strati2=np.append(self.Strati2,-1)
                self.HS2=np.append(self.HS2,-1)
            if len(self.Strati3)==0:
                self.Strati3=np.append(self.Strati3,-1)
                self.HS3=np.append(self.HS3,-1)
            if len(self.Strati4)==0:
                self.Strati4=np.append(self.Strati4,-1)
                self.HS4=np.append(self.HS4,-1)
            if len(self.Strati5)==0:
                self.Strati5=np.append(self.Strati5,-1)
                self.HS5=np.append(self.HS5,-1)
            if len(self.Strati6)==0:
                self.Strati6=np.append(self.Strati6,-1)
                self.HS6=np.append(self.HS6,-1)
            if len(self.Strati7)==0:
                self.Strati7=np.append(self.Strati7,-1)
                self.HS7=np.append(self.HS7,-1)
            if len(self.Strati8)==0:
                self.Strati8=np.append(self.Strati8,-1)
                self.HS8=np.append(self.HS8,-1)
            if len(self.Strati9)==0:
                self.Strati9=np.append(self.Strati9,-1)
                self.HS9=np.append(self.HS9,-1)
            # crea grafico
            L1=LT.barh(self.HS1,self.Strati1,scalebar,align='center',color='darkblue')
            L2=LT.barh(self.HS2,self.Strati2,scalebar,align='center',color='saddlebrown')
            L3=LT.barh(self.HS3,self.Strati3,scalebar,align='center',color='darkolivegreen')
            L4=LT.barh(self.HS4,self.Strati4,scalebar,align='center',color='forestgreen')
            L5=LT.barh(self.HS5,self.Strati5,scalebar,align='center',color='goldenrod')
            L6=LT.barh(self.HS6,self.Strati6,scalebar,align='center',color='darkgoldenrod')
            L7=LT.barh(self.HS7,self.Strati7,scalebar,align='center',color='gold')
            L8=LT.barh(self.HS8,self.Strati8,scalebar,align='center',color='darkgrey')
            L9=LT.barh(self.HS9,self.Strati9,scalebar,align='center',color='powderblue')
            LT.legend([L1,L2,L3,L4,L5,L6,L7,L8,L9],['sensitive fine-grained','clay-organic soil','clay to silty clay','clayey silt & silty clay','silty sand to sandy silt',
                                                  'clean sands to silty sands','dense sand to gravelly sand','stiff sand to clayey sand','stiff fine-grained'],loc=1,fontsize=7)

    if self.ChoseLito==2:
        if self.ElabStrat==1:
            dict_plt={'sensitive fine-grained':'darkblue','organic material':'saddlebrown','clay':'darkolivegreen','silty clay to clay':'forestgreen','clayey silt to silty clay':'limegreen',
                        'sandy silt to clayey silt':'goldenrod','silty sand to sandy silt':'palegoldenrod','sand to silty sand':'darkgoldenrod','sand':'gold',
                         'gravelly sand to sand':'darkkhaki','very stiff fine grained':'powderblue','sand to clayey sand':'darkgrey','out of correlation':'lightgray'}
            
            colorplt=['darkblue','saddlebrown','darkolivegreen','forestgreen','limegreen','goldenrod','palegoldenrod','darkgoldenrod','gold','darkkhaki','powderblue','darkgrey']
            for PLT in range(len(self.NameS)):
                if self.LTCPTF[PLT]==0:
                   numC=np.uint32(self.LTCPTF[PLT])-1 
                   LT.barh(self.Hmed[PLT],1.5,self.scalebar[PLT],align='center',color='lightgray')
                   ST.barh(self.Hmed[PLT],1.5,self.scalebar[PLT],align='center',color='lightgray')
                else:
                   numC=np.uint32(self.LTCPTF[PLT])-1
                   LT.barh(self.Hmed[PLT],self.LTCPTF[PLT],self.scalebar[PLT],align='center',color=colorplt[numC])
                   ST.barh(self.Hmed[PLT],self.LTCPTF[PLT],self.scalebar[PLT],align='center',color=colorplt[numC])
            patchList = []
            for key in dict_plt:
                data_key = mpatches.Patch(color=dict_plt[key], label=key)
                patchList.append(data_key)
            LT.legend(handles=patchList,loc=1,fontsize=7)
            ST.legend(handles=patchList,loc=1,fontsize=4.5) #,handles=patchList,bbox_to_anchor=(0.5, 1.1)
                            
        else:
            #verifica le litologie non esistenti e mette valori dummy per plot legenda
            if len(self.Strati1_12)==0:
                self.Strati1_12=np.append(self.Strati1_12,-1)
                self.HS1_12=np.append(self.HS1_12,-1)
            if len(self.Strati2_12)==0:
                self.Strati2_12=np.append(self.Strati2_12,-1)
                self.HS2_12=np.append(self.HS2_12,-1)
            if len(self.Strati3_12)==0:
                self.Strati3_12=np.append(self.Strati3_12,-1)
                self.HS3_12=np.append(self.HS3_12,-1)
            if len(self.Strati4_12)==0:
                self.Strati4_12=np.append(self.Strati4_12,-1)
                self.HS4_12=np.append(self.HS4_12,-1)
            if len(self.Strati5_12)==0:
                self.Strati5_12=np.append(self.Strati5_12,-1)
                self.HS5_12=np.append(self.HS5_12,-1)
            if len(self.Strati6_12)==0:
                self.Strati6_12=np.append(self.Strati6_12,-1)
                self.HS6_12=np.append(self.HS6_12,-1)
            if len(self.Strati7_12)==0:
                self.Strati7_12=np.append(self.Strati7_12,-1)
                self.HS7_12=np.append(self.HS7_12,-1)
            if len(self.Strati8_12)==0:
                self.Strati8_12=np.append(self.Strati8_12,-1)
                self.HS8_12=np.append(self.HS8_12,-1)
            if len(self.Strati9_12)==0:
                self.Strati9_12=np.append(self.Strati9_12,-1)
                self.HS9_12=np.append(self.HS9_12,-1)
            if len(self.Strati10_12)==0:
                self.Strati10_12=np.append(self.Strati10_12,-1)
                self.HS10_12=np.append(self.HS10_12,-1)
            if len(self.Strati11_12)==0:
                self.Strati11_12=np.append(self.Strati11_12,-1)
                self.HS11_12=np.append(self.HS11_12,-1)
            if len(self.Strati12_12)==0:
                self.Strati12_12=np.append(self.Strati12_12,-1)
                self.HS12_12=np.append(self.HS12_12,-1)    
            # crea grafico
            L1=LT.barh(self.HS1_12,self.Strati1_12,scalebar,align='center',color='darkblue')
            L2=LT.barh(self.HS2_12,self.Strati2_12,scalebar,align='center',color='saddlebrown')
            L3=LT.barh(self.HS3_12,self.Strati3_12,scalebar,align='center',color='darkolivegreen')
            L4=LT.barh(self.HS4_12,self.Strati4_12,scalebar,align='center',color='forestgreen')
            L5=LT.barh(self.HS5_12,self.Strati5_12,scalebar,align='center',color='limegreen')
            L6=LT.barh(self.HS6_12,self.Strati6_12,scalebar,align='center',color='goldenrod')    
            L7=LT.barh(self.HS7_12,self.Strati7_12,scalebar,align='center',color='palegoldenrod')
            L8=LT.barh(self.HS8_12,self.Strati8_12,scalebar,align='center',color='darkgoldenrod')
            L9=LT.barh(self.HS9_12,self.Strati9_12,scalebar,align='center',color='gold')
            L10=LT.barh(self.HS10_12,self.Strati10_12,scalebar,align='center',color='darkkhaki')
            L11=LT.barh(self.HS11_12,self.Strati11_12,scalebar,align='center',color='powderblue')
            L12=LT.barh(self.HS12_12,self.Strati12_12,scalebar,align='center',color='darkgrey')
            LT.legend([L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12],['sensitive fine-grained','organic material','clay','silty clay to clay','clayey silt to silty clay',
                                                                 'sandy silt to clayey silt','silty sand to sandy silt','sand to silty sand','sand','gravelly sand to sand',
                                                                  'very stiff fine grained','sand to clayey sand'],loc=1,fontsize=7)


    #richiama i limiti area
    SBT_Index_Limit(self)
    #converte in coord
    xA2, yA2 = self.A2.exterior.xy
    xA3, yA3 = self.A3.exterior.xy
    xA4, yA4 = self.A4.exterior.xy
    xA5, yA5 = self.A5.exterior.xy
    xA6, yA6 = self.A6.exterior.xy
    xA7, yA7 = self.A7.exterior.xy
    #grafico SBTn Index
    INDX.fill_between(xA2, yA2,facecolor='saddlebrown')
    INDX.fill_between(xA3, yA3,facecolor='darkolivegreen')
    INDX.fill_between(xA4, yA4,facecolor='forestgreen')
    INDX.fill_between(xA5, yA5,facecolor='goldenrod')
    INDX.fill_between(xA6, yA6,facecolor='darkgoldenrod')
    INDX.fill_between(xA7, yA7,facecolor='gold')
    if self.ChoseLito==1 or self.ChoseLito==2:
        tit='SBT index'
        IC_Graf=self.IC_SBT
        lab='IC'
    if self.ChoseLito==0:
        tit='SBTn index'
        lab='ICn'
        IC_Graf=self.IC 
    INDX.set_title(tit,fontsize=12)
    INDX.set_xlabel(lab,fontsize=11)
    INDX.set_ylabel('Prof (m)',fontsize=11)
    INDX.set_xlim([1,4])
    INDX.set_ylim([self.H.max(),-0.5])
    INDX.set_yticks(np.arange(0, self.H.max(), 1))
    INDX.set_xticks(np.arange(1, 4, 1))
    #INDX.set_aspect(0.4)
    
    INDX.plot(IC_Graf,self.H,'b-', xA2, yA2,'k',
           xA3,yA3,'k',xA4, yA4,'k',xA5, yA5,'k',
           xA6,yA6,'k',xA7, yA7,'k')

    if self.ElabStrat==0:
       self.F2_path=self.Folder+"/"+self.nomeP+"_Litologia.png"
       self.figLito.set_size_inches((10, 10), forward=False)
       self.figLito.savefig(self.F2_path,dpi=250)
    
       self.scene3 = QtWidgets.QGraphicsScene()
       canvas = FigureCanvas(self.figLito)
    
       canvas.setGeometry(0, 0, 750, 620)
       self.scene3.addWidget(canvas)
       self.dlg8.LitoGraph.setScene(self.scene3)
       
    if self.ElabStrat==1:
       self.KsceneLito=1 
       self.sceneLito = QtWidgets.QGraphicsScene()
       canvas = FigureCanvas(self.figSoloStrat)
       
       canvas.setGeometry(0, 0, 320, 410)
       self.sceneLito.addWidget(canvas)
       self.dlg14.Lito.setScene(self.sceneLito)

       self.F2_path=self.Folder+"/"+self.nomeP+"_Litologia-mod.png"
       self.figLito.set_size_inches((10, 10), forward=False)
       self.figLito.savefig(self.F2_path,dpi=250)

#da finire inserire i grafici desiderati
def plot_Parametri(self):
    self.figPar, (kPer,kOCR,kDR,kES,kGo) = plt.subplots(1,5,figsize=(15,5.5))
    plt.tight_layout()
    #plot permeabilità,OCR
    scaleX=np.array([5,10,20,50,100,200,250])
    #Permeabilità
    kPer.set_title('Permeabilità',fontsize=11)
    if self.ChosePerm==1:
        layX='Ksbt (m/s)'
    if self.ChosePerm==0:
        layX='K (m/s)'
    kPer.set_xlabel(layX,fontsize=9.5)
    kPer.set_ylabel('Prof (m)',fontsize=9.5)
    kPer.invert_yaxis()
    self.KsbtPLT=np.ma.masked_where(self.Ksbt==0,self.Ksbt)
    kPer.set_ylim([self.H.max(),0])
    kPer.set_yticks(np.arange(0, self.H.max(), 1))
    kPer.set_xticks(np.arange(1*10**-9,1*10**-2,1*10**-3))
    kPer.semilogx(self.KsbtPLT,self.H,'k-', markersize=7)
    kPer.grid(linestyle='--')
    #OCR
    kOCR.set_title('OCR',fontsize=11)
    kOCR.set_xlabel('OCR',fontsize=9.5)
    kOCR.set_ylabel('Prof (m)',fontsize=9.5)
    kOCR.invert_yaxis()
    self.OCRPLT=np.ma.masked_where(self.OCR==0,self.OCR)
    kOCR.set_ylim([self.H.max(),0])
    kOCR.set_yticks(np.arange(0,self.H.max(), 1))
    idx3 = (np.abs(scaleX-self.OCR.max()/10)).argmin()
    kOCR.set_xticks(np.arange(0,self.OCR.max(),scaleX[idx3]))
    kOCR.plot(self.OCRPLT,self.H,'k-', markersize=7)
    kOCR.grid(linestyle='--')
    #DR
    kDR.set_title('Densità relativa',fontsize=11)
    kDR.set_xlabel('DR (%)',fontsize=9.5)
    kDR.set_ylabel('Prof (m)',fontsize=9.5)
    kDR.invert_yaxis()
    kDR.set_ylim([self.H.max(),0])
    kDR.set_yticks(np.arange(0, self.H.max(), 1))

    if self.DR.max()>10:
        for sclDr in range(0, len(scaleX)):
            if np.abs(self.DR.max() / scaleX[sclDr]) <= 10:
                idx4=sclDr
                break
        kDR.set_xticks(np.arange(0, self.DR.max(), scaleX[idx4]))
    else:
        kDR.set_xticks(np.arange(0, self.DR.max(), 1))
    self.DRPLT=np.ma.masked_where(self.DR==0,self.DR)
    kDR.plot(self.DRPLT,self.H,'k-', markersize=7)
    kDR.grid(linestyle='--')
    #modulo young
    kES.set_title('Modulo di Young',fontsize=11)
    kES.set_xlabel('Es (MPa)',fontsize=9.5)
    kES.set_ylabel('Prof (m)',fontsize=9.5)
    kES.invert_yaxis()
    self.EsPLT=np.ma.masked_where(self.Es==0,self.Es)
    kES.set_ylim([self.H.max(),0])
    kES.set_yticks(np.arange(0, self.H.max(), 1))
    idx5 = (np.abs(scaleX-self.Es.max()/5)).argmin()
    kES.set_xticks(np.arange(0,self.Es.max(),scaleX[idx5]))
    kES.plot(self.EsPLT,self.H,'k-', markersize=7)
    kES.grid(linestyle='--')
    #G0
    kGo.set_title('G0',fontsize=11)
    kGo.set_xlabel('G0 (MPa)',fontsize=9.5)
    kGo.set_ylabel('Prof (m)',fontsize=9.5)
    kGo.invert_yaxis()
    self.GOPLT=np.ma.masked_where(self.G0==0,self.G0)
    kGo.set_ylim([self.H.max(),0])
    kGo.set_yticks(np.arange(0, self.H.max(), 1))
    #idx6 = (np.abs(scaleX-self.Es.max()/10)).argmin()
    #kGo.set_xticks(np.arange(0,self.G0.max(),scaleX[idx6]))
    kGo.plot(self.GOPLT,self.H,'k-', markersize=7)
    kGo.grid(linestyle='--')

    self.F3_path=self.Folder+"/"+self.nomeP+"_ParametriA.png"
    self.figPar.set_size_inches((16, 10), forward=False)
    self.figPar.savefig(self.F3_path,dpi=200)
    
    self.scene4 = QtWidgets.QGraphicsScene()
    canvas = FigureCanvas(self.figPar)
    
    canvas.setGeometry(0, 0, 1500, 900)
    self.scene4.addWidget(canvas)
    self.dlg8.PLOT_Param.setScene(self.scene4)

def plot_Parametri_2(self):
    self.figPar2, (kKo,kcu,kM,kphi,kphieff) = plt.subplots(1,5,figsize=(15,5.5))
    self.figPar2.tight_layout()
    scaleX=np.array([5,10,20,50,100,200,250])  
    #K0
    kKo.set_title('K0',fontsize=11)
    kKo.set_xlabel('K0',fontsize=9.5)
    kKo.set_ylabel('Prof (m)',fontsize=9.5)
    kKo.invert_yaxis()
    self.KOPLT=np.ma.masked_where(self.KO==0,self.KO)
    kKo.set_ylim([self.H.max(),0])
    kKo.set_yticks(np.arange(0, self.H.max(), 1))
    #idx7 = (np.abs(scaleX-self.KO.max()/10)).argmin()
    #kKo.set_xticks(np.arange(0,self.KO.max(),5))
    kKo.plot(self.KOPLT,self.H,'k-', markersize=7)
    kKo.grid(linestyle='--')
    #cu-curem
    kcu.set_title('Resistenza al taglio',fontsize=11)
    kcu.set_xlabel('cu (kPa)',fontsize=9.5)
    kcu.set_ylabel('Prof (m)',fontsize=9.5)
    kcu.invert_yaxis()
    self.cuPLT=np.ma.masked_where(self.cu==0,self.cu)
    self.cuRPLT=np.ma.masked_where(self.cuRem==0,self.cuRem)
    kcu.set_ylim([self.H.max(),0])
    kcu.set_yticks(np.arange(0, self.H.max(), 1))
    idx8 = (np.abs(scaleX-self.cu.max()/5)).argmin()
    kcu.set_xticks(np.arange(0,self.cu.max(),scaleX[idx8]))
    cu1=kcu.plot(self.cuPLT,self.H,'k-', markersize=7,label='cu peak')
    cu2=kcu.plot(self.cuRPLT,self.H,'r-', markersize=7,label='cu remolded')
    kcu.grid(linestyle='--')
    kcu.legend(fontsize=7.5)
    #M
    kM.set_title('M',fontsize=11)
    kM.set_xlabel('M (MPa)',fontsize=9.5)
    kM.set_ylabel('Prof (m)',fontsize=9.5)
    kM.invert_yaxis()
    self.MPLT=np.ma.masked_where(self.M==0,self.M)
    kM.set_ylim([self.H.max(),0])
    kM.set_yticks(np.arange(0, self.H.max(), 1))

    idx9 = (np.abs(scaleX-self.M.max()/5)).argmin()
    kM.set_xticks(np.arange(0,self.M.max(),scaleX[idx9]))

    if self.M.max() > 10:
        for sclM in range(0, len(scaleX)):
            if np.abs(self.M.max() / scaleX[sclM]) <= 10:
                idx9 = sclM
                break
        kM.set_xticks(np.arange(0,self.M.max(),scaleX[idx9]))
    else:
        kM.set_xticks(np.arange(0,self.M.max(),scaleX[0]))
    kM.plot(self.MPLT,self.H,'k-', markersize=7)
    kM.grid(linestyle='--')
    #phi
    kphi.set_title('Angolo attrito',fontsize=11)
    kphi.set_xlabel('phi (°)',fontsize=9.5)
    kphi.set_ylabel('Prof (m)',fontsize=9.5)
    kphi.invert_yaxis()
    self.phiPLT=np.ma.masked_where(self.phi==0,self.phi)
    kphi.set_ylim([self.H.max(),0])
    kphi.set_yticks(np.arange(0, self.H.max(), 1))
    #idx10 = (np.abs(scaleX-self.phi.max()/10)).argmin()
    #kphi.set_xticks(np.arange(0,self.phi.max(),5))
    kphi.plot(self.phiPLT,self.H,'k-', markersize=7)
    kphi.grid(linestyle='--')
    #phieff
    kphieff.set_title('Angolo attrito efficace',fontsize=11)
    kphieff.set_xlabel('phi (°)',fontsize=9.5)
    kphieff.set_ylabel('Prof (m)',fontsize=9.5)
    kphieff.invert_yaxis()
    self.phieffPLT=np.ma.masked_where(self.effPhi==0,self.effPhi)
    kphieff.set_ylim([self.H.max(),0])
    kphieff.set_yticks(np.arange(0, self.H.max(), 1))
    #idx11 = (np.abs(scaleX-self.effPhi.max()/10)).argmin()
    #kphieff.set_xticks(np.arange(0,self.effPhi.max(),5))
    kphieff.plot(self.phieffPLT,self.H,'k-', markersize=7)
    kphieff.grid(linestyle='--')
    
    self.F4_path=self.Folder+"/"+self.nomeP+"_ParametriB.png"
    self.figPar2.set_size_inches((16, 10), forward=False)
    self.figPar2.savefig(self.F4_path,dpi=200)
    
    self.scene5 = QtWidgets.QGraphicsScene()
    canvas = FigureCanvas(self.figPar2)
    
    canvas.setGeometry(0, 0, 1500, 900)
    self.scene5.addWidget(canvas)
    self.dlg8.PLOT_value2.setScene(self.scene5)

def plot_CPTm(self):
    self.figBase, (aQC,aFS,aRf) = plt.subplots(1,3)
    self.figBase.tight_layout()
    #plot qc e fs e rf
    scaleX=np.array([5,10,20,50,100,200,250])
    #array assex
    #Qc
    aQC.set_title('qc',fontsize=11)
    aQC.set_xlabel('qc (MPa)',fontsize=9.5)
    aQC.set_ylabel('Prof (m)',fontsize=9.5)
    aQC.invert_yaxis()
    aQC.set_ylim([self.H.max(),0])
    aQC.set_yticks(np.arange(0, self.H.max(), 1))
    aQC.plot(self.Qc,self.H,'k-', markersize=7)
    aQC.grid(linestyle='--')
    if self.dlg8.NOFalda.isChecked()==False:
        aQC.plot(np.mean(self.Qc),float(self.Hfalda)-0.06,'cv', markersize=8)
    #fs
    aFS.set_title('fs',fontsize=11)
    aFS.set_xlabel('fs (kPa)',fontsize=9.5)
    aFS.set_ylabel('Prof (m)',fontsize=9.5)
    aFS.invert_yaxis()
    aFS.set_ylim([self.H.max(),0])
    aFS.set_yticks(np.arange(0, self.H.max(), 1))
    self.fspul = np.ma.masked_where(self.fs == 0, self.fs)
    aFS.plot(self.fspul,self.H,'k-', markersize=7)
    aFS.grid(linestyle='--')
    if self.dlg8.NOFalda.isChecked()==False:
        aFS.plot(np.mean(self.fs),float(self.Hfalda)-0.06,'cv', markersize=8)
    #Rf  
    aRf.set_title('Rf',fontsize=11)
    aRf.set_xlabel('Rf(%)',fontsize=9.5)
    aRf.set_ylabel('Prof (m)',fontsize=9.5)
    aRf.invert_yaxis()
    aRf.set_ylim([self.H.max(),0])
    if self.Rf.max()>10:
        for scl in range(0, len(scaleX)):
            if np.abs(self.Rf.max() / scaleX[scl]) <= 10:
                idx2 = scl
                break
        aRf.set_xticks(np.arange(0, self.Rf.max(), scaleX[idx2]))
    else:
        aRf.set_xticks(np.arange(0, self.Rf.max(), 1))
    aRf.set_yticks(np.arange(0, self.H.max(), 1))
    aRf.plot(self.Rf,self.H,'k-', markersize=7)
    aRf.grid(linestyle='--')
    #salva immagine e disegna canvas
    self.F1_path=self.Folder+"/"+self.nomeP+"_dati.png"
    self.figBase.set_size_inches((14, 9), forward=False)
    self.figBase.savefig(self.F1_path,dpi=200)
    
    self.scene2 = QtWidgets.QGraphicsScene()
    canvas = FigureCanvas(self.figBase)
    
    canvas.setGeometry(0, 0, 1450, 620)
    self.scene2.addWidget(canvas)
    self.dlg8.BasePLOT.setScene(self.scene2)

    #plot grafico 2
    self.figPar, (kcu,kM,kphi) = plt.subplots(1,3)
    self.figPar.tight_layout()
    scaleX=np.array([5,10,20,50,100,200,250])  
    #cu
    kcu.set_title('Resistenza al taglio',fontsize=11)
    kcu.set_xlabel('cu (kPa)',fontsize=9.5)
    kcu.set_ylabel('Prof (m)',fontsize=9.5)
    kcu.invert_yaxis()
    self.cuPLT1=np.ma.masked_where(self.cu==0,self.cu)
    self.cuPLT=np.ma.masked_where(self.cuPLT1>950,self.cuPLT1)
    kcu.set_ylim([self.H.max(),0])
    kcu.set_yticks(np.arange(0, self.H.max(), 1))
    if self.cu.max()>800:   
        self.cuscala=800
        self.passo=100
    else:
        self.cuscala=self.cu.max()
        self.passo=50
    #idx8 = (np.abs(scaleX-self.cuscala/5)).argmin()
    #kcu.set_xticks(np.arange(0,self.cuscala,scaleX[idx8]))
    kcu.set_xlim([0,self.cuscala])    
    kcu.set_xticks(np.arange(0,self.cuscala,self.passo))
    cu1=kcu.plot(self.cuPLT,self.H,'k-', markersize=7)
    kcu.grid(linestyle='--')
    #M
    kM.set_title('M',fontsize=11)
    kM.set_xlabel('M (MPa)',fontsize=9.5)
    kM.set_ylabel('Prof (m)',fontsize=9.5)
    kM.invert_yaxis()
    self.MPLT=np.ma.masked_where(self.M==0,self.M)
    kM.set_ylim([self.H.max(),0])
    kM.set_yticks(np.arange(0, self.H.max(), 1))
    if self.M.max()>10:
        for sclM in range(0, len(scaleX)):
            if np.abs(self.M.max() / scaleX[sclM]) <= 10:
                idx9 = sclM
                break
        kM.set_xticks(np.arange(0,self.M.max(),scaleX[idx9]))
    else:
        kM.set_xticks(np.arange(0,self.M.max(),scaleX[0]))
    kM.plot(self.MPLT,self.H,'k-', markersize=7)
    kM.grid(linestyle='--')
    #phi
    kphi.set_title('Angolo attrito',fontsize=11)
    kphi.set_xlabel('phi (°)',fontsize=9.5)
    kphi.set_ylabel('Prof (m)',fontsize=9.5)
    kphi.invert_yaxis()
    self.phiPLT=np.ma.masked_where(self.effPhi==0,self.effPhi)
    kphi.set_ylim([self.H.max(),0])
    kphi.set_yticks(np.arange(0, self.H.max(), 1))
    kphi.plot(self.phiPLT,self.H,'k-', markersize=7)
    kphi.grid(linestyle='--')
 
    self.F3_path=self.Folder+"/"+self.nomeP+"_ParametriA.png"
    self.figPar.set_size_inches((14, 9), forward=False)
    self.figPar.savefig(self.F3_path,dpi=200)
    
    self.scene4 = QtWidgets.QGraphicsScene()
    canvas = FigureCanvas(self.figPar)
    
    canvas.setGeometry(0, 0, 1450, 620)
    self.scene4.addWidget(canvas)
    self.dlg8.PLOT_Param.setScene(self.scene4)

def plot_CPTm_Lito(self):
    #litologia
    self.figLito, (LT) = plt.subplots(1,1)
    self.figLito.tight_layout()
    #plot litologia
    LT.set_title('Litologia',fontsize=12)
    LT.set_ylabel('Prof (m)',fontsize=11)
    LT.invert_yaxis()
    LT.set_yticks(np.arange(0, self.H.max(), 1))
    LT.set_xticks(np.arange(0, 12, 1))
    LT.set_xlim([0,21])
    LT.set_ylim([self.H.max(),-0.5])
    scalebar=self.H[1]-self.H[2]
    #plot solo stratigr
    self.figSoloStrat = plt.figure()
    ST= self.figSoloStrat.add_subplot(111)
    ST.set_title('Litologia',fontsize=9)
    ST.set_ylabel('Prof (m)',fontsize=8)
    ST.invert_yaxis()
    ST.set_yticks(np.arange(0, self.H.max(), 1))
    ST.set_xticks(np.arange(0, 11, 1))
    for label in (ST.get_xticklabels() + ST.get_yticklabels()):
        label.set_fontsize(7)
    ST.set_xlim([0,15])
    ST.set_ylim([self.H.max(),-0.5])
    if self.ElabStrat==0:
       scalebar=self.H[1]-self.H[2]
    if self.ElabStrat==1:
       self.scalebar=[]
       self.Hmed=[]
       for T in range(len(self.NameS)):
            self.scalebar=np.append(self.scalebar,float(self.letto[T])-float(self.tetto[T]))
            self.Hmed=np.append(self.Hmed,((float(self.letto[T])-float(self.tetto[T]))/2)+float(self.tetto[T])) 
    if self.ChoseLTM==0:
        if self.ElabStrat==1:
            dict_plt={'sabbie calcaree o marne':'darkgrey','sabbia addensata o cementata':'gold','sabbia':'orange','sabbia sciolta':'darkgoldenrod',
                        'sabbie argillose e limi':'goldenrod','limi e sabbie':'forestgreen','argille sabbiose e limose':'darkolivegreen',
                         'argilla inorganica molto compatta':'powderblue','argilla inorganica a media consistenza':'chocolate',
                          'argilla inorganica a bassa consistenza':'darkblue','argille organiche e terreni misti':'saddlebrown','out of correlation':'lightgray'}
            colorplt=['darkgrey','gold','orange','darkgoldenrod','goldenrod','forestgreen','darkolivegreen','powderblue','chocolate','darkblue','saddlebrown']
            for PLT in range(len(self.NameS)):
                if self.LTCPTF[PLT]==0:
                   numC=np.uint32(self.LTCPTF[PLT])-1 
                   LT.barh(self.Hmed[PLT],1.5,self.scalebar[PLT],align='center',color='lightgray')
                   ST.barh(self.Hmed[PLT],1.5,self.scalebar[PLT],align='center',color='lightgray')
                else:
                   if self.LTCPTF[PLT]==1:
                      numC=9
                   if self.LTCPTF[PLT]==2:
                      numC=10
                   if self.LTCPTF[PLT]==3:
                      numC=8
                   if self.LTCPTF[PLT]==4:
                      numC=6
                   if self.LTCPTF[PLT]==5:
                      numC=5
                   if self.LTCPTF[PLT]==6:
                      numC=4
                   if self.LTCPTF[PLT]==7:
                      numC=3
                   if self.LTCPTF[PLT]==8:
                      numC=2
                   if self.LTCPTF[PLT]==9:
                      numC=7
                   if self.LTCPTF[PLT]==10:
                      numC=1
                   if self.LTCPTF[PLT]==11:
                      numC=0   
                   LT.barh(self.Hmed[PLT],self.LTCPTF[PLT],self.scalebar[PLT],align='center',color=colorplt[numC])
                   ST.barh(self.Hmed[PLT],self.LTCPTF[PLT],self.scalebar[PLT],align='center',color=colorplt[numC])
            patchList = []
            for key in dict_plt:
                data_key = mpatches.Patch(color=dict_plt[key], label=key)
                patchList.append(data_key)
            LT.legend(handles=patchList,loc=1,fontsize=7)
            ST.legend(handles=patchList,loc=1,fontsize=4.5) 
        else:
            #verifica le litologie non esistenti e mette valori dummy per plot legenda
            if len(self.Strati1S)==0:
                self.Strati1S=np.append(self.Strati1S,-1)
                self.HS1S=np.append(self.HS1S,-1)
            if len(self.Strati2S)==0:
                self.Strati2S=np.append(self.Strati2S,-1)
                self.HS2S=np.append(self.HS2S,-1)
            if len(self.Strati3S)==0:
                self.Strati3S=np.append(self.Strati3S,-1)
                self.HS3S=np.append(self.HS3S,-1)
            if len(self.Strati4S)==0:
                self.Strati4S=np.append(self.Strati4S,-1)
                self.HS4S=np.append(self.HS4S,-1)
            if len(self.Strati5S)==0:
                self.Strati5S=np.append(self.Strati5S,-1)
                self.HS5S=np.append(self.HS5S,-1)
            if len(self.Strati6S)==0:
                self.Strati6S=np.append(self.Strati6S,-1)
                self.HS6S=np.append(self.HS6S,-1)
            if len(self.Strati7S)==0:
                self.Strati7S=np.append(self.Strati7S,-1)
                self.HS7S=np.append(self.HS7S,-1)
            if len(self.Strati8S)==0:
                self.Strati8S=np.append(self.Strati8S,-1)
                self.HS8S=np.append(self.HS8S,-1)
            if len(self.Strati9S)==0:
                self.Strati9S=np.append(self.Strati9S,-1)
                self.HS9S=np.append(self.HS9S,-1)
            if len(self.Strati10S)==0:
                self.Strati10S=np.append(self.Strati10S,-1)
                self.HS10S=np.append(self.HS10S,-1)
            if len(self.Strati11S)==0:
                self.Strati11S=np.append(self.Strati11S,-1)
                self.HS11S=np.append(self.HS11S,-1)
            # crea grafico
            L1=LT.barh(self.HS1S,self.Strati1S,scalebar,align='center',color='darkgrey')
            L2=LT.barh(self.HS2S,self.Strati2S,scalebar,align='center',color='gold')
            L3=LT.barh(self.HS3S,self.Strati3S,scalebar,align='center',color='orange')
            L4=LT.barh(self.HS4S,self.Strati4S,scalebar,align='center',color='darkgoldenrod')
            L5=LT.barh(self.HS5S,self.Strati5S,scalebar,align='center',color='goldenrod')
            L6=LT.barh(self.HS6S,self.Strati6S,scalebar,align='center',color='forestgreen')
            L7=LT.barh(self.HS7S,self.Strati7S,scalebar,align='center',color='darkolivegreen')
            L8=LT.barh(self.HS8S,self.Strati8S,scalebar,align='center',color='powderblue')
            L9=LT.barh(self.HS9S,self.Strati9S,scalebar,align='center',color='chocolate')
            L10=LT.barh(self.HS10S,self.Strati10S,scalebar,align='center',color='darkblue')
            L11=LT.barh(self.HS11S,self.Strati11S,scalebar,align='center',color='saddlebrown')
            LT.legend([L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11],['sabbie calcaree o marne','sabbia addensata o cementata','sabbia','sabbia sciolta',
                                                             'sabbie argillose e limi','limi e sabbie','argille sabbiose e limose','argilla inorganica molto compatta',
                                                              'argilla inorganica a media consistenza','argilla inorganica a bassa consistenza','argille organiche e terreni misti'],loc=1,fontsize=7)

    if self.ChoseLTM==1:
         if self.ElabStrat==1:
            dict_plt={'sabbia con ghiaia':'darkgrey','sabbia limosa':'darkgoldenrod','limo sabbioso argilloso':'forestgreen','miscela di argilla e limo':'darkolivegreen',
                        'argilla':'chocolate','terreno organico':'saddlebrown','out of correlation':'lightgray'}
            colorplt=['darkgrey','darkgoldenrod','forestgreen','darkolivegreen','chocolate','saddlebrown']
            for PLT in range(len(self.NameS)):
                if self.LTCPTF[PLT]==0:
                   numC=np.uint32(self.LTCPTF[PLT])-1 
                   LT.barh(self.Hmed[PLT],1.5,self.scalebar[PLT],align='center',color='lightgray')
                   ST.barh(self.Hmed[PLT],1.5,self.scalebar[PLT],align='center',color='lightgray')
                else:
                   numC=np.uint32(self.LTCPTF[PLT])-1
                   LT.barh(self.Hmed[PLT],self.LTCPTF[PLT],self.scalebar[PLT],align='center',color=colorplt[numC])
                   ST.barh(self.Hmed[PLT],self.LTCPTF[PLT],self.scalebar[PLT],align='center',color=colorplt[numC])
            patchList = []
            for key in dict_plt:
                data_key = mpatches.Patch(color=dict_plt[key], label=key)
                patchList.append(data_key)
            LT.legend(handles=patchList,loc=1,fontsize=7)
            ST.legend(handles=patchList,loc=1,fontsize=4.5)
         else:
            #verifica le litologie non esistenti e mette valori dummy per plot legenda
            if len(self.Strati1B)==0:
                self.Strati1B=np.append(self.Strati1B,-1)
                self.HS1B=np.append(self.HS1B,-1)
            if len(self.Strati2B)==0:
                self.Strati2B=np.append(self.Strati2B,-1)
                self.HS2B=np.append(self.HS2B,-1)
            if len(self.Strati3B)==0:
                self.Strati3B=np.append(self.Strati3B,-1)
                self.HS3B=np.append(self.HS3B,-1)
            if len(self.Strati4B)==0:
                self.Strati4B=np.append(self.Strati4B,-1)
                self.HS4B=np.append(self.HS4B,-1)
            if len(self.Strati5B)==0:
                self.Strati5B=np.append(self.Strati5B,-1)
                self.HS5B=np.append(self.HS5B,-1)
            if len(self.Strati6B)==0:
                self.Strati6B=np.append(self.Strati6B,-1)
                self.HS6B=np.append(self.HS6B,-1)
     
            # crea grafico
            L1=LT.barh(self.HS1B,self.Strati1B,scalebar,align='center',color='darkgrey')
            L2=LT.barh(self.HS2B,self.Strati2B,scalebar,align='center',color='darkgoldenrod')
            L3=LT.barh(self.HS3B,self.Strati3B,scalebar,align='center',color='forestgreen')
            L4=LT.barh(self.HS4B,self.Strati4B,scalebar,align='center',color='darkolivegreen')
            L5=LT.barh(self.HS5B,self.Strati5B,scalebar,align='center',color='chocolate')
            L6=LT.barh(self.HS6B,self.Strati6B,scalebar,align='center',color='saddlebrown')    

            LT.legend([L1,L2,L3,L4,L5,L6],['sabbia con ghiaia','sabbia limosa','limo sabbioso argilloso','miscela di argilla e limo','argilla',
                                                                 'terreno organico'],loc=1,fontsize=7)

    if self.ElabStrat==0:
        self.F2_path=self.Folder+"/"+self.nomeP+"_Litologia.png"
        self.figLito.set_size_inches((6.6, 10.6), forward=False)
        self.figLito.savefig(self.F2_path,dpi=250)
        
        self.scene3 = QtWidgets.QGraphicsScene()
        canvas = FigureCanvas(self.figLito)
        
        canvas.setGeometry(0, 0, 680, 620)
        self.scene3.addWidget(canvas)
        self.dlg8.LitoGraph.setScene(self.scene3)
        
    if self.ElabStrat==1:
       self.KsceneLito=1 
       self.sceneLito = QtWidgets.QGraphicsScene()
       canvas = FigureCanvas(self.figSoloStrat)
       
       canvas.setGeometry(0, 0, 320, 410)
       self.sceneLito.addWidget(canvas)
       self.dlg14.Lito.setScene(self.sceneLito)

       self.F2_path=self.Folder+"/"+self.nomeP+"_Litologia-mod.png"
       self.figLito.set_size_inches((6.6, 10.6), forward=False)
       self.figLito.savefig(self.F2_path,dpi=250)
