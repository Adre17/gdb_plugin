#-*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'setup.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

#* Released under the GNU General Public License

##CPT_Office-V1.1_ evaluating liquefaction potential from CPTE and CPTU 
##Copyright(C) 2017 Umberto Grechi

##_CPT_Office-V1.1_ is free software; you can redistribute it and/or
##modify it under the terms of the GNU General Public License
##as published by the Free Software Foundation; either version 3
##of the License, or (at your option) any later version.

##_CPT_Office-V1.1_ is distributed in the hope that it will be useful,
##but WITHOUT ANY WARRANTY; without even the implied warranty of
##MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##GNU General Public License for more details.

##You should have received a copy of the GNU General Public License
##along with this program.  If not, see <http://www.gnu.org/licenses/>

import os, os.path
import fnmatch
import codecs, json
import numpy as np
import matplotlib.pyplot as plt
import shapely.geometry as sg
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Frame,Table, TableStyle, NextPageTemplate, PageTemplate, BaseDocTemplate
#from reportlab.platypus import NextPageTemplate, PageTemplate
from reportlab.platypus.flowables import PageBreak, Spacer
from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4,landscape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.platypus import Image as rpImage
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
import time

from .Elab_data import*


#carica il file risultati
def CPT_sovrapposte(self):
   self.comp_Path=self.Folder+'\CPT_results.json'
   self.logo_path = os.path.dirname(os.path.realpath(__file__))
   #verifica sia presente il file risultati
   if os.path.exists(self.comp_Path)==False:
       msg = QMessageBox()
       msg.setWindowIcon(QtGui.QIcon('avviso.ico'))
       msg.setIcon(QMessageBox.Information)
       msg.setText("Output non presente, elaborare i dati prova, o verificare la directory caricata!")
       msg.setWindowTitle("Attenzione!")
       msg.exec_()
       return
   #cerca i nomi prove esistenti e crea una lista 
   self.ListaP=[]
   self.Hr=[]
   self.ListaPM=[]
   self.HrM=[]
   for dr in range(100):
        lst='R'+str(dr+1)
        try:
            if self.dict[lst].isChecked():
               for file in os.listdir(self.Folder):
                    if fnmatch.fnmatch(file, 'input'+'*'+'.json'):
                       with open(self.Folder+'/'+file) as leggi:
                          data = json.load(leggi)
                          if data['Tipo']=='CPTmec':
                             self.ListaPM=np.append(self.ListaPM,data['name'])
                             self.HrM=np.append(self.HrM,np.float_(data['H']).max()) 
                          if data['Tipo']=='CPTE/U':
                             self.ListaP=np.append(self.ListaP,data['name'])
                             self.Hr=np.append(self.Hr,np.float_(data['H']).max())           
        except KeyError:
            pass   
        except RuntimeError:
            pass

   if len(self.ListaPM)!=0:
      #liimti aree indici
      self.Hmax=self.HrM.max()
      #plotta pagina 1
      self.figBase, (aQC,aFS,aRf) = plt.subplots(1,3)#,sharey=True)
      #plot qc e fs u
      #Qc
      aQC.set_title('qc',fontsize=11)
      aQC.set_xlabel('qc (MPa)',fontsize=9.5)
      aQC.set_ylabel('Prof (m)',fontsize=9.5)
      aQC.invert_yaxis()
      aQC.grid(linestyle='--')
      #fs
      aFS.set_title('fs',fontsize=11)
      aFS.invert_yaxis()
      aFS.grid(linestyle='--')
      #u
      aRf.set_title('Rf',fontsize=11)
      aRf.invert_yaxis()
      aRf.grid(linestyle='--')
      #plotta pagina 2
      self.fig2, (kcu,kM,kphi) = plt.subplots(1,3)#,sharey=True)
      #cu
      kcu.set_title('Resistenza al taglio',fontsize=11)
      kcu.set_xlabel('cu (kPa)',fontsize=9.5)
      kcu.set_ylabel('Prof (m)',fontsize=9.5)
      kcu.invert_yaxis()
      kcu.grid(linestyle='--')
      #M
      kM.set_title('M',fontsize=11)
      kM.set_xlabel('M (MPa)',fontsize=9.5)
      kM.invert_yaxis()
      kM.grid(linestyle='--')
      #u
     #phi
      kphi.set_title('Angolo attrito',fontsize=11)
      kphi.set_xlabel('phi (°)',fontsize=9.5)
      kphi.invert_yaxis()
      kphi.grid(linestyle='--')
      #lista colori
      color=['k','r','b','g','c','m','xkcd:forest green','xkcd:mustard','xkcd:lilac','xkcd:navy','xkcd:lime','xkcd:maroon','xkcd:gold','xkcd:salmon',
             'xkcd:grey','xkcd:tan','xkcd:mauve','xkcd:ochre','xkcd:steel blue','xkcd:brick']
      #apre file risultati    
      with open(self.comp_Path) as loadRes:
           dtRes = json.load(loadRes)
           if type(dtRes) is dict:
                   for cpt in range(len(self.ListaPM)):
                       labLeg=str(self.ListaPM[cpt])
                       #get data
                       self.H=np.float_(dtRes[self.ListaPM[cpt]][0]['H'])
                       self.Qc=np.float_(dtRes[self.ListaPM[cpt]][0]['QC'])
                       self.fs=np.float_(dtRes[self.ListaPM[cpt]][0]['FS'])
                       self.Rf=np.float_(dtRes[self.ListaPM[cpt]][0]['Rf'])
                       self.cu=np.float_(dtRes[self.ListaPM[cpt]][0]['cu'])
                       self.M=np.float_(dtRes[self.ListaPM[cpt]][0]['M'])
                       self.effPhi=np.float_(dtRes[self.ListaPM[cpt]][0]['phip'])

                       #plot pag 1
                       aQC.set_ylim([self.Hmax,0])
                       aQC.set_yticks(np.arange(0, self.Hmax, 1))
                       
                       aFS.set_ylim([self.Hmax,0])
                       aFS.set_yticks(np.arange(0, self.Hmax, 1))
                       
                       aRf.set_ylim([self.Hmax,0])
                       aRf.set_yticks(np.arange(0, self.Hmax, 1))
                       #info
                       aQC.plot(self.Qc,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       aFS.plot(self.fs,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       aRf.plot(self.Rf,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       #plot pag 2
                       self.cuPLT1=np.ma.masked_where(self.cu==0,self.cu)
                       self.cuPLT=np.ma.masked_where(self.cuPLT1>950,self.cuPLT1)
                       if self.cu.max()>600:
                          self.cuscala=600
                          self.passo=100
                       else:
                          self.cuscala=self.cu.max()
                          self.passo=50
                       #idx8 = (np.abs(scaleX-self.cuscala/5)).argmin()
                       #kcu.set_xticks(np.arange(0,self.cuscala,scaleX[idx8]))
                       kcu.set_xlim([0,self.cuscala])    
                       kcu.set_xticks(np.arange(0,self.cuscala,self.passo))
                       kcu.set_ylim([self.Hmax,0])
                       kcu.set_yticks(np.arange(0, self.Hmax, 1))
                       cu1=kcu.plot(self.cuPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)

                       self.MPLT=np.ma.masked_where(self.M==0,self.M)
                       kM.set_ylim([self.Hmax,0])
                       kM.set_yticks(np.arange(0, self.Hmax, 1))
                       kM.plot(self.MPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)

                       self.phiPLT=np.ma.masked_where(self.effPhi==0,self.effPhi)
                       kphi.set_ylim([self.Hmax,0])
                       kphi.set_yticks(np.arange(0, self.Hmax, 1))
                       kphi.plot(self.phiPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
      #legende e savefig                 
      aQC.legend(fontsize=7,bbox_to_anchor=(-0.22, 0.5),loc='best')
      kcu.legend(fontsize=7,bbox_to_anchor=(-0.22, 0.5),loc='best')
      self.figBase.set_size_inches((11.5, 6.5), forward=False)
      self.fig2.set_size_inches((11.5, 6.5), forward=False)
      new=self.Folder+'/multiplot_1m.png'
      new2=self.Folder+'/multiplot_2m.png'
      self.figBase.savefig(new,dpi=200)
      self.fig2.savefig(new2,dpi=200)
      

      #save pdf
      #plot report pdf con grafico
      #crea percorso salvataggio pdf
      reportPath=self.Folder+"/report-multiplot-CPTm.pdf"
      #inizializzazione proprietà documento
      doc = BaseDocTemplate(reportPath, pagesize=A4, rightMargin=25, leftMargin=25, topMargin=25, bottomMargin=25)
      portrait_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='portrait_frame ')
      landscape_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.height, doc.width, id='landscape_frame ')
      
      doc = SimpleDocTemplate(reportPath,pagesize=A4,
                           rightMargin=72,leftMargin=10,
                           topMargin=30,bottomMargin=10)
      #variabile contenitore
      report=[]
         #logo CPT Office 
      logo=self.logo_path+"\Logo_CPT.png"
      im = rpImage(logo, 0.4*inch, 0.4*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,5))
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,5))
      #verifica se è presente il logo personalizzzato e lo usa
      try:
         logoC=self.logo_path+"\logo-custom.jpg"
         imC = rpImage(logoC, 0.35*inch, 0.35*inch)
         imC.hAlign ='RIGHT'
         report.append(imC)
      except OSError:
         print('salva senza logo personalizzato')
      pass
   
      #titolo
      style = ParagraphStyle(
               name='Normal',
               fontName='Helvetica-Bold',
               fontSize=16,
                )
      style2 = ParagraphStyle(
               name='Centrato',
               fontName='Helvetica',
               fontSize=9,
               alignment = TA_CENTER )
      report.append(Paragraph("Geo Utilities V. 2.0", style))
      report.append(Spacer(1,20))
      style = ParagraphStyle(
               name='Normal',
               fontName='Helvetica',
               fontSize=12,
               )
      
      report.append(Paragraph("Elaborato grafico confronto prove penetrometriche", style))
      report.append(Spacer(1,10))
      style4 = ParagraphStyle(
               name='orario',
               fontName='Helvetica',
               fontSize=8,
                )

      #orario
      ora=time.strftime("%H:%M:%S")
      #data
      data=time.strftime("%d/%m/%Y")
      report.append(Paragraph(str(data), style4))
      report.append(Paragraph(str(ora), style4))
      report.append(Spacer(1,20))
      #intestazione
      # dati relativi commitenza
      Dcomm=[['Committente',self.dlg8.committente.text()],
           ['Località',self.dlg8.luogo.text()],
            ['Via', self.dlg8.indirizzo.text()],
             ['Tipo Prove','CPTm']]
      # crea celle tabella commitenza
      Comm=Table(Dcomm,2*[2*inch], 4*[0.2*inch],hAlign='LEFT')
      #stile tabella
      Comm.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                                     ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                                     ('FONTSIZE',(0,0), (-1,-1), 7.5),
                                     ('ALIGN',(0,0),(-1,-1),'LEFT'),
                                     ('VALIGN',        (0,0), (-1,-1), 'TOP'),
                                       ]))
      #appende tabella commitenza
      report.append(Comm)
      

      report.append(Spacer(1,5))
       

      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      #vado su nuova pagina e ruoto per il grafico
      #grafico dati
      report.append(NextPageTemplate('landscape'))
      report.append(PageBreak())

      report.append(Paragraph("1 - Parametri prove", style))
      report.append(Spacer(1,5))
      fig1= new
      Dati = rpImage(fig1,10.6*inch, 6*inch)
      report.append(Dati)
      report.append(Spacer(1,10))
      report.append(Paragraph("Fig 1 - Plot profondità-variabile delle prove penetrometriche elaborate", style2))
      report.append(Spacer(1,5)) 
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,20))

      report.append(NextPageTemplate('landscape'))
      report.append(PageBreak())

      report.append(Paragraph("2 - Parametri prove e confronto IC-Litologia", style))
      report.append(Spacer(1,5))
      fig3= new2
      Par_A = rpImage(fig3,10.6*inch, 6*inch)
      report.append(Par_A)
      report.append(Spacer(1,10))
      report.append(Paragraph("Fig 2 - Parametri di output delle prove penetrometriche elaborate", style2))
      report.append(Spacer(1,5)) 
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,10))
      
      doc.addPageTemplates([PageTemplate(id='portrait',frames=portrait_frame),
                         PageTemplate(id='landscape',frames=landscape_frame, pagesize=landscape(A4))])
      
      doc.build(report)



      
   if len(self.ListaP)!=0:
      #crea grafico SBT
      #liimti aree indici
      self.Hmax=self.Hr.max()
      #lito 1,8 e 9 non rappresentabili
      self.A7=sg.Polygon([(1,0),(1,self.Hmax.max()),(1.31,self.Hmax.max()),(1.31,0)])
      self.A6=sg.Polygon([(1.31,0),(1.31,self.Hmax.max()),(2.05,self.Hmax.max()),(2.05,0)])
      self.A5=sg.Polygon([(2.05,0),(2.05,self.Hmax.max()),(2.6,self.Hmax.max()),(2.6,0)])
      self.A4=sg.Polygon([(2.6,0),(2.6,self.Hmax.max()),(2.95,self.Hmax.max()),(2.95,0)])
      self.A3=sg.Polygon([(2.95,0),(2.95,self.Hmax.max()),(3.6,self.Hmax.max()),(3.6,0)])
      self.A2=sg.Polygon([(3.6,0),(3.6,self.Hmax.max()),(4,self.Hmax.max()),(4,0)])
      #converte in coord
      xA2, yA2 = self.A2.exterior.xy
      xA3, yA3 = self.A3.exterior.xy
      xA4, yA4 = self.A4.exterior.xy
      xA5, yA5 = self.A5.exterior.xy
      xA6, yA6 = self.A6.exterior.xy
      xA7, yA7 = self.A7.exterior.xy
      
      #plotta pagina 1
      self.figBase, (aQC,aFS,aU) = plt.subplots(1,3)#,sharey=True)
      #plot qc e fs u
      #Qc
      aQC.set_title('qc',fontsize=11)
      aQC.set_xlabel('qc (MPa)',fontsize=9.5)
      aQC.set_ylabel('Prof (m)',fontsize=9.5)
      aQC.invert_yaxis()
      aQC.grid(linestyle='--')
      #fs
      aFS.set_title('fs',fontsize=11)
      aFS.set_xlabel('fs (kPa)',fontsize=9.5)
      aFS.invert_yaxis()
      aFS.grid(linestyle='--')
      #u
      aU.set_title('u',fontsize=11)
      aU.set_xlabel('Pressione (kPa)',fontsize=9.5)
      aU.invert_yaxis()
      #aU.set_yticks(np.arange(0, self.H.max(), 1))
      #aU.set_xticks(np.arange(0, self.u2.max(), 100))
      aU.grid(linestyle='--')
      
      #plotta pagina 2
      self.fig2, (bQt,bRf,bU,bINDX) = plt.subplots(1,4)#,sharey=True)
      #Qt
      bQt.set_title('Qt',fontsize=11)
      bQt.set_xlabel('Qt (MPa)',fontsize=9.5)
      bQt.set_ylabel('Prof (m)',fontsize=9.5)
      bQt.invert_yaxis()
      bQt.grid(linestyle='--')
      #Rf
      bRf.set_title('Rf',fontsize=11)
      bRf.set_xlabel('Rf(%)',fontsize=9.5)
      bRf.invert_yaxis()
      bRf.grid(linestyle='--')
      #u
      bU.set_title('u',fontsize=11)
      bU.set_xlabel('Pressione (kPa)',fontsize=9.5)
      bU.invert_yaxis()
      #aU.set_yticks(np.arange(0, self.H.max(), 1))
      #aU.set_xticks(np.arange(0, self.u2.max(), 100))
      bU.grid(linestyle='--')
      #IC_SBT
      bINDX.fill_between(xA2, yA2,facecolor='saddlebrown')
      bINDX.fill_between(xA3, yA3,facecolor='darkolivegreen')
      bINDX.fill_between(xA4, yA4,facecolor='forestgreen')
      bINDX.fill_between(xA5, yA5,facecolor='goldenrod')
      bINDX.fill_between(xA6, yA6,facecolor='darkgoldenrod')
      bINDX.fill_between(xA7, yA7,facecolor='gold')
      bINDX.set_title('SBT index',fontsize=12)
      bINDX.set_xlabel('IC',fontsize=11)
      #plotta pagina 2
      self.fig3, (cQtn,cFr,cBq,cINDX) = plt.subplots(1,4)#,sharey=True)
      #Qtn
      cQtn.set_title('Qtn',fontsize=11)
      cQtn.set_xlabel('Qtn (MPa)',fontsize=9.5)
      cQtn.set_ylabel('Prof (m)',fontsize=9.5)
      cQtn.invert_yaxis()
      cQtn.grid(linestyle='--')
      #Fr
      cFr.set_title('Fr',fontsize=11)
      cFr.set_xlabel('Fr(%)',fontsize=9.5)
      cFr.invert_yaxis()
      cFr.grid(linestyle='--')
      #Bq
      cBq.set_title('Pressione u norm.',fontsize=11)
      cBq.set_xlabel('Bq',fontsize=9.5)
      cBq.invert_yaxis()
      cBq.grid(linestyle='--')
      #ICn SBT
      #grafico SBTn Index
      cINDX.fill_between(xA2, yA2,facecolor='saddlebrown')
      cINDX.fill_between(xA3, yA3,facecolor='darkolivegreen')
      cINDX.fill_between(xA4, yA4,facecolor='forestgreen')
      cINDX.fill_between(xA5, yA5,facecolor='goldenrod')
      cINDX.fill_between(xA6, yA6,facecolor='darkgoldenrod')
      cINDX.fill_between(xA7, yA7,facecolor='gold')
      cINDX.set_title('SBTn index',fontsize=12)
      cINDX.set_xlabel('ICn',fontsize=11)
      #plot pag 4
      self.fig4, (kPer,kOCR,kDR,kES,kGo) = plt.subplots(1,5)#,sharey=True)
      #Permeabilità
      kPer.set_title('Permeabilità',fontsize=11)
      layX='K (m/s)'
      kPer.set_xlabel(layX,fontsize=9.5)
      kPer.set_ylabel('Prof (m)',fontsize=9.5)
      kPer.invert_yaxis()
      kPer.grid(linestyle='--')
      #OCR
      kOCR.set_title('OCR',fontsize=11)
      kOCR.set_xlabel('OCR',fontsize=9.5)
      kOCR.invert_yaxis()
      kOCR.grid(linestyle='--')
      #DR
      kDR.set_title('Densità relativa',fontsize=11)
      kDR.set_xlabel('DR (%)',fontsize=9.5)
      kDR.invert_yaxis()      
      kDR.grid(linestyle='--')
      #modulo young
      kES.set_title('Modulo di Young',fontsize=11)
      kES.set_xlabel('Es (MPa)',fontsize=9.5)
      kES.invert_yaxis()
      kES.grid(linestyle='--')
      #G0
      kGo.set_title('G0',fontsize=11)
      kGo.set_xlabel('G0 (MPa)',fontsize=9.5)
      kGo.invert_yaxis()
      kGo.grid(linestyle='--')
      #plot pag 5
      self.fig5, (kKo,kcu,kM,kphi,kphieff) = plt.subplots(1,5)#,sharey=True)
      #K0
      kKo.set_title('K0',fontsize=11)
      kKo.set_xlabel('K0',fontsize=9.5)
      kKo.set_ylabel('Prof (m)',fontsize=9.5)
      kKo.invert_yaxis()
      kKo.grid(linestyle='--')
      #cu
      kcu.set_title('Resistenza al taglio',fontsize=11)
      kcu.set_xlabel('cu (kPa)',fontsize=9.5)
      kcu.invert_yaxis()
      kcu.grid(linestyle='--')
      #M
      kM.set_title('M',fontsize=11)
      kM.set_xlabel('M (MPa)',fontsize=9.5)
      kM.invert_yaxis()
      kM.grid(linestyle='--')
      #phi
      kphi.set_title('Angolo attrito',fontsize=11)
      kphi.set_xlabel('phi (°)',fontsize=9.5)
      kphi.invert_yaxis()
      kphi.grid(linestyle='--')
      #phieff
      kphieff.set_title('Angolo attrito picco',fontsize=11)
      kphieff.set_xlabel('phi (°)',fontsize=9.5)
      kphieff.invert_yaxis()
      kphieff.grid(linestyle='--')
      

      #lista colori
      color=['k','r','b','g','c','m','xkcd:forest green','xkcd:mustard','xkcd:lilac','xkcd:navy','xkcd:lime','xkcd:maroon','xkcd:gold','xkcd:salmon',
             'xkcd:grey','xkcd:tan','xkcd:mauve','xkcd:ochre','xkcd:steel blue','xkcd:brick']
      #apre file risultati
      self.pa=0.1013252
      self.scaleX = np.array([5, 10, 20, 50, 100, 200, 250])
      with open(self.comp_Path) as loadRes:
           dtRes = json.load(loadRes)
           if type(dtRes) is dict:
               #try:
                   for cpt in range(len(self.ListaP)):
                       labLeg=str(self.ListaP[cpt])
                       #get data
                       self.H=np.float_(dtRes[self.ListaP[cpt]][0]['H'])
                       self.Qc=np.float_(dtRes[self.ListaP[cpt]][0]['QC'])
                       self.fs=np.float_(dtRes[self.ListaP[cpt]][0]['FS'])
                       self.u2=np.float_(dtRes[self.ListaP[cpt]][0]['UU'])
                       self.Qt=np.float_(dtRes[self.ListaP[cpt]][0]['Qt'])
                       self.Rf=np.float_(dtRes[self.ListaP[cpt]][0]['Rf'])
                       self.Fr=np.float_(dtRes[self.ListaP[cpt]][0]['Fr'])
                       self.QtnT=np.float_(dtRes[self.ListaP[cpt]][0]['Qtn'])
                       self.Bq=np.float_(dtRes[self.ListaP[cpt]][0]['Bq'])
                       self.IC_SBT=np.float_(dtRes[self.ListaP[cpt]][0]['IC_SBT'])
                       self.IC=np.float_(dtRes[self.ListaP[cpt]][0]['IC'])
                       self.Ksbt=np.float_(dtRes[self.ListaP[cpt]][0]['K'])
                       self.OCR=np.float_(dtRes[self.ListaP[cpt]][0]['OCR'])
                       self.DR=np.float_(dtRes[self.ListaP[cpt]][0]['DR'])
                       self.Es=np.float_(dtRes[self.ListaP[cpt]][0]['Es'])
                       self.G0=np.float_(dtRes[self.ListaP[cpt]][0]['G0'])
                       self.KO=np.float_(dtRes[self.ListaP[cpt]][0]['k0'])
                       self.cu=np.float_(dtRes[self.ListaP[cpt]][0]['cu'])
                       self.M=np.float_(dtRes[self.ListaP[cpt]][0]['M'])
                       self.phi=np.float_(dtRes[self.ListaP[cpt]][0]['phi'])
                       self.effPhi=np.float_(dtRes[self.ListaP[cpt]][0]['phip'])
                       #plot pag 1
                       aQC.set_ylim([self.Hmax,0])
                       aQC.set_yticks(np.arange(0, self.Hmax, 1))
                       #aQC.set_xticks(np.arange(0, self.Qc.max(), 5))
                       aFS.set_ylim([self.Hmax,0])
                       aFS.set_yticks(np.arange(0, self.Hmax, 1))
                       #aFS.set_xticks(np.arange(0, self.fs.max(), 50))
                       aU.set_ylim([self.Hmax,0])
                       aU.set_yticks(np.arange(0, self.Hmax, 1))
                       #aU.set_xticks(np.arange(0, self.fs.max(), 100))
                       aQC.plot(self.Qc,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       aFS.plot(self.fs,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       aU.plot(self.u2,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       #plot pag 2
                       bQt.set_ylim([self.Hmax,0])
                       bQt.set_yticks(np.arange(0, self.Hmax, 1))
                       #bQt.set_xticks(np.arange(0, self.Qt.max(), 5))
                       bRf.set_ylim([self.Hmax,0])
                       bRf.set_yticks(np.arange(0, self.Hmax, 1))
                       #bRf.set_xticks(np.arange(0, 10, 1))
                       bU.set_ylim([self.Hmax,0])
                       bU.set_yticks(np.arange(0, self.Hmax, 1))
                       #bU.set_xticks(np.arange(0, self.fs.max(), 100))
                       bINDX.set_ylim([self.Hmax,-0.5])
                       bINDX.set_yticks(np.arange(0, self.Hmax, 1))
                       bINDX.set_xlim([1,4])
                       bINDX.set_xticks(np.arange(1, 4, 1))
                       bINDX.set_aspect(0.5)
                       bQt.plot(self.Qt,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       bRf.plot(self.Rf,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       bU.plot(self.u2,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       bINDX.plot(self.IC_SBT,self.H,str(color[cpt]), xA2, yA2,'k',
                                    xA3,yA3,'k',xA4, yA4,'k',xA5, yA5,'k',
                                                   xA6,yA6,'k',xA7, yA7,'k')
                       #plot pag 3
                       cQtn.set_ylim([self.Hmax,0])
                       cQtn.set_yticks(np.arange(0, self.Hmax, 1))
                       #cQtn.set_xticks(np.arange(0, self.Qt.max(), 50))
                       cFr.set_ylim([self.Hmax,0])
                       cFr.set_yticks(np.arange(0, self.Hmax, 1))
                       #cFr.set_xticks(np.arange(0, 10, 1))
                       cBq.set_ylim([self.Hmax,0])
                       cBq.set_yticks(np.arange(0, self.Hmax, 1))
                       #cBq.set_xticks(np.arange(0, self.Bq.max(), 0.2))
                       cINDX.set_xlim([1,4])
                       cINDX.set_ylim([self.Hmax,-0.5])
                       cINDX.set_yticks(np.arange(0, self.Hmax, 1))
                       cINDX.set_xticks(np.arange(1, 4, 1))
                       cINDX.set_aspect(0.5)
                       cQtn.plot(self.QtnT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       cFr.plot(self.Fr,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       cBq.plot(self.Bq,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       cINDX.plot(self.IC,self.H,str(color[cpt]), xA2, yA2,'k',
                                    xA3,yA3,'k',xA4, yA4,'k',xA5, yA5,'k',
                                                   xA6,yA6,'k',xA7, yA7,'k')
                       #plot pag 4
                       self.KsbtPLT=np.ma.masked_where(self.Ksbt==0,self.Ksbt)   
                       kPer.set_ylim([self.Hmax,0])
                       kPer.set_yticks(np.arange(0, self.Hmax, 1))
                       kPer.set_xticks(np.arange(1*10**-9,1*10**-2,1*10**-3))
                       kPer.semilogx(self.KsbtPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       self.OCRPLT=np.ma.masked_where(self.OCR==0,self.OCR)
                       kOCR.set_ylim([self.Hmax,0])
                       kOCR.set_yticks(np.arange(0,self.Hmax, 1))
                       if self.OCR.max() > 5:
                           for sclOC in range(0, len(self.scaleX)):
                               if np.abs(self.OCR.max() / self.scaleX[sclOC]) <= 5:
                                   idxoc = sclOC
                                   break
                           kOCR.set_xticks(np.arange(0, self.OCR.max(), self.scaleX[idxoc]))
                       else:
                           kOCR.set_xticks(np.arange(0, self.OCR.max(), 1))
                       #kOCR.set_xticks(np.arange(0,self.OCR.max(),20))
                       kOCR.plot(self.OCRPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       kDR.set_ylim([self.Hmax,0])
                       kDR.set_yticks(np.arange(0, self.Hmax, 1))
                       if self.DR.max() > 5:
                           for sclD in range(0, len(self.scaleX)):
                               if np.abs(self.DR.max() / self.scaleX[sclD]) <= 5:
                                   idxd = sclD
                                   break
                           kDR.set_xticks(np.arange(0, self.DR.max(), self.scaleX[idxd]))
                       else:
                           kDR.set_xticks(np.arange(0, self.DR.max(), 1))
                       #kDR.set_xticks(np.arange(0,self.DR.max(),10))
                       self.DRPLT=np.ma.masked_where(self.DR==0,self.DR)
                       kDR.plot(self.DRPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       self.EsPLT=np.ma.masked_where(self.Es==0,self.Es)
                       kES.set_ylim([self.Hmax,0])
                       kES.set_yticks(np.arange(0, self.Hmax, 1))
                       #kES.set_xticks(np.arange(0,self.Es.max(),20))
                       kES.plot(self.EsPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       self.GOPLT=np.ma.masked_where(self.G0==0,self.G0)
                       kGo.set_ylim([self.Hmax,0])
                       kGo.set_yticks(np.arange(0, self.Hmax, 1))
                       #kGo.set_xticks(np.arange(0,self.G0.max(),25))
                       kGo.plot(self.GOPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       #plot pag 5
                       self.KOPLT=np.ma.masked_where(self.KO==0,self.KO)
                       kKo.set_ylim([self.Hmax,0])
                       kKo.set_yticks(np.arange(0, self.Hmax, 1))
                       #kKo.set_xticks(np.arange(0,self.KO.max(),0.5))
                       kKo.plot(self.KOPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       self.cuPLT=np.ma.masked_where(self.cu==0,self.cu)
                       kcu.set_ylim([self.Hmax,0])
                       kcu.set_yticks(np.arange(0, self.Hmax, 1))
                       #kcu.set_xticks(np.arange(0,self.cu.max(),10))
                       cu1=kcu.plot(self.cuPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       self.MPLT=np.ma.masked_where(self.M==0,self.M)
                       kM.set_ylim([self.Hmax,0])
                       kM.set_yticks(np.arange(0, self.Hmax, 1))
                       #kKo.set_xticks(np.arange(0,self.KO.max(),0.5))
                       kM.plot(self.MPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       self.phiPLT=np.ma.masked_where(self.phi==0,self.phi)
                       kphi.set_ylim([self.Hmax,0])
                       kphi.set_yticks(np.arange(0, self.Hmax, 1))
                       kphi.set_xticks(np.arange(0,self.phi.max(),5))
                       kphi.plot(self.phiPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                       self.phieffPLT=np.ma.masked_where(self.effPhi==0,self.effPhi)
                       kphieff.set_ylim([self.Hmax,0])
                       kphieff.set_yticks(np.arange(0, self.Hmax, 1))
                       #kphieff.set_xticks(np.arange(0,self.effPhi.max(),10))
                       kphieff.plot(self.phieffPLT,self.H,str(color[cpt]), markersize=7,label=labLeg)
                                      
      
                       
      aQC.legend(fontsize=7,bbox_to_anchor=(-0.22, 1),loc='best')
      bQt.legend(fontsize=7,bbox_to_anchor=(-0.27, 1),loc='best')
      cQtn.legend(fontsize=7,bbox_to_anchor=(-0.27, 1),loc='best')
      kPer.legend(fontsize=7,bbox_to_anchor=(-0.30, 1),loc='best')
      kKo.legend(fontsize=7,bbox_to_anchor=(-0.30, 1),loc='best')
      self.figBase.set_size_inches((11.5, 6.5), forward=False)
      self.fig2.set_size_inches((11.5, 6.5), forward=False)
      self.fig3.set_size_inches((11.5, 6.5), forward=False)
      self.fig4.set_size_inches((11.5, 6.5), forward=False)
      self.fig5.set_size_inches((11.5, 6.5), forward=False)
      new=self.Folder+'/multiplot_1.png'
      new2=self.Folder+'/multiplot_2.png'
      new3=self.Folder+'/multiplot_3.png'
      new4=self.Folder+'/multiplot_4.png'
      new5=self.Folder+'/multiplot_5.png'
      self.figBase.savefig(new,dpi=200)
      self.fig2.savefig(new2,dpi=200)
      self.fig3.savefig(new3,dpi=200)
      self.fig4.savefig(new4,dpi=200)
      self.fig5.savefig(new5,dpi=200)

      #save pdf
      #plot report pdf con grafico
      #crea percorso salvataggio pdf
      reportPath=self.Folder+"/report-multiplot-CPT.pdf"
      #inizializzazione proprietà documento
      doc = BaseDocTemplate(reportPath, pagesize=A4, rightMargin=25, leftMargin=25, topMargin=25, bottomMargin=25)
      portrait_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='portrait_frame ')
      landscape_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.height, doc.width, id='landscape_frame ')
      
      doc = SimpleDocTemplate(reportPath,pagesize=A4,
                           rightMargin=72,leftMargin=10,
                           topMargin=30,bottomMargin=10)
      #variabile contenitore
      report=[]
         #logo CPT Office 
      logo=self.logo_path+"\Logo_CPT.png"
      im = rpImage(logo, 0.4*inch, 0.4*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,5))
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,5))
      #verifica se è presente il logo personalizzzato e lo usa
      try:
         logoC=self.logo_path+"\logo-custom.jpg"
         imC = rpImage(logoC, 0.35*inch, 0.35*inch)
         imC.hAlign ='RIGHT'
         report.append(imC)
      except OSError:
         print('salva senza logo personalizzato')
      pass
   
      #titolo
      style = ParagraphStyle(
               name='Normal',
               fontName='Helvetica-Bold',
               fontSize=16,
                )
      style2 = ParagraphStyle(
               name='Centrato',
               fontName='Helvetica',
               fontSize=9,
               alignment = TA_CENTER )
      report.append(Paragraph("Geo Utilities V. 2.0", style))
      report.append(Spacer(1,20))
      style = ParagraphStyle(
               name='Normal',
               fontName='Helvetica',
               fontSize=12,
               )
      
      report.append(Paragraph("Elaborato grafico confronto prove penetrometriche", style))
      report.append(Spacer(1,10))
      style4 = ParagraphStyle(
               name='orario',
               fontName='Helvetica',
               fontSize=8,
                )

      #orario
      ora=time.strftime("%H:%M:%S")
      #data
      data=time.strftime("%d/%m/%Y")
      report.append(Paragraph(str(data), style4))
      report.append(Paragraph(str(ora), style4))
      report.append(Spacer(1,20))
      #intestazione
      # dati relativi commitenza
      Dcomm=[['Committente',self.dlg8.committente.text()],
           ['Località',self.dlg8.luogo.text()],
            ['Via', self.dlg8.indirizzo.text()],
             ['Tipo Prove','CPTE/U']]
      # crea celle tabella commitenza
      Comm=Table(Dcomm,2*[2*inch], 4*[0.2*inch],hAlign='LEFT')
      #stile tabella
      Comm.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                                     ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                                     ('FONTSIZE',(0,0), (-1,-1), 7.5),
                                     ('ALIGN',(0,0),(-1,-1),'LEFT'),
                                     ('VALIGN',        (0,0), (-1,-1), 'TOP'),
                                       ]))
      #appende tabella commitenza
      report.append(Comm)
      
      #vado su nuova pagina e ruoto per il grafico
      #grafico dati
      report.append(NextPageTemplate('landscape'))
      report.append(PageBreak())

      report.append(Paragraph("1 - Parametri prove", style))
      report.append(Spacer(1,5))
      fig1= new
      Dati = rpImage(fig1,10.6*inch, 6*inch)
      report.append(Dati)
      report.append(Spacer(1,10))
      report.append(Paragraph("Fig 1 - Plot profondità-variabile delle prove penetrometriche elaborate", style2))
      report.append(Spacer(1,5)) 
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,20))

      report.append(NextPageTemplate('landscape'))
      report.append(PageBreak())

      report.append(Paragraph("2 - Parametri prove e confronto IC-Litologia", style))
      report.append(Spacer(1,5))
      fig3= new2
      Par_A = rpImage(fig3,10.6*inch, 6*inch)
      report.append(Par_A)
      report.append(Spacer(1,10))
      report.append(Paragraph("Fig 2 - Plot profondità-variabile delle prove penetrometriche elaborate", style2))
      report.append(Spacer(1,5)) 
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,10))
      
      report.append(NextPageTemplate('landscape'))
      report.append(PageBreak())

      report.append(Paragraph("2 - Parametri prove e confronto ICn-Litologia", style))
      report.append(Spacer(1,5))
      fig4= new3
      Par_B = rpImage(fig4,10.6*inch, 6*inch)
      report.append(Par_B)
      report.append(Spacer(1,10))
      report.append(Paragraph("Fig 3 - Plot profondità-variabile delle prove penetrometriche elaborate", style2))
      report.append(Spacer(1,5)) 
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,10))

      report.append(NextPageTemplate('landscape'))
      report.append(PageBreak())

      report.append(Paragraph("3 - Parametri di output delle prove penetrometriche elaborate ", style))
      report.append(Spacer(1,10))
      fig5= new4
      SBT = rpImage(fig5,10.6*inch, 6*inch)
      report.append(SBT)
      report.append(Spacer(1,10))
      report.append(Paragraph("Fig 4 - Plot profondità-variabile delle prove penetrometriche elaborate", style2))
      report.append(Spacer(1,5)) 
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,10))

      report.append(NextPageTemplate('landscape'))
      report.append(PageBreak())

      report.append(Paragraph("3 - Parametri di output delle prove penetrometriche elaborate", style))
      report.append(Spacer(1,10))
      fig6= new5
      Lito = rpImage(fig6,10.6*inch, 6*inch)
      report.append(Lito)
      report.append(Spacer(1,10))
      report.append(Paragraph("Fig 5 - Plot profondità-variabile delle prove penetrometriche elaborate", style2))
      report.append(Spacer(1,5)) 
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,10))
      
      doc.addPageTemplates([PageTemplate(id='portrait',frames=portrait_frame),
                         PageTemplate(id='landscape',frames=landscape_frame, pagesize=landscape(A4))])
      
      doc.build(report)


    

