#-*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'setup.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

#* Released under the GNU General Public License

##CPT_Office-V1.1_ evaluating liquefaction potential from CPTE and CPTU 
##Copyright(C) 2017 Umberto Grechi

##_CPT_Office-V1.1_ is free software; you can redistribute it and/or
##modify it under the terms of the GNU General Public License
##as published by the Free Software Foundation; either version 3
##of the License, or (at your option) any later version.

##_CPT_Office-V1.1_ is distributed in the hope that it will be useful,
##but WITHOUT ANY WARRANTY; without even the implied warranty of
##MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##GNU General Public License for more details.

##You should have received a copy of the GNU General Public License
##along with this program.  If not, see <http://www.gnu.org/licenses/>

from .GDB_plugin import*
import csv
import xlrd
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Frame,Table, TableStyle, NextPageTemplate, PageTemplate, BaseDocTemplate
from reportlab.platypus.flowables import PageBreak, Spacer
from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4,landscape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.platypus import Image as rpImage
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
import time

def print_dati_dmt(self):
   self.logo_path = os.path.dirname(os.path.realpath(__file__))
   idtp = self.dlg16.tipo_DMT.currentIndex()
   if idtp == 0:
      self.type = 'DMT'
      if self.dlg16.NOFalda.isChecked():
         self.HfaldaDMT='non presente'
      reportPath_CSV=self.FolderDMT+"/"+self.nomeDMT+"_report-calcoli.csv"
      #crea file csv per plot dati
      outDati=open(reportPath_CSV,'w',newline='')
      data=csv.writer(outDati)
      data.writerow(['Committente',self.dlg16.committente.text()])
      data.writerow(['Località',self.dlg16.luogo.text()])
      data.writerow(['Via',self.dlg16.indirizzo.text()])
      data.writerow(['Prova',self.dlg16.NP_DMT.text()])
      data.writerow(['Tipo Prova',self.type])
      data.writerow(['Tipo di Prova','Prof. max','Falda'])
      data.writerow(['DMT',round(self.varZ.max(),2),self.HfaldaDMT])
      data.writerow(['Prof. (m)','A (kPa)','B (kPa)','C (kPa)','P0 (kPa)','P1 (kPa)','P2 (kPa)','gamma (KN/m3)','Sigmavp(kPa)',
               'U (kPa)','Id','Kd','Ed (kPa)','Ud', 'Ko','OCR','M (MPa)','Cu (kPa)','phi (°)','Litologia'])

      for i in range(0,len(self.varZ)):
            data.writerow([round(self.varZ[i],1),round(self.varA[i],0),round(self.varB[i],0),round(self.varC[i],0),round(self.varPo[i],1),
                            round(self.varP1[i], 1),round(self.varP2[i],1),round(self.varGamma[i],1),round(self.varSigma[i],2),
                             round(self.varU[i], 1),round(self.varId[i], 2),round(self.varKd[i], 1),round(self.varEd[i], 2),
                              round(self.varUd[i], 1),round(self.varKo[i], 2),round(self.varOCR[i], 2),round(self.varM[i], 1),
                                round(self.varCu[i], 1),round(self.varPhi[i], 1),(self.varLT[i])])
      outDati.close()


   if idtp == 1:
      self.type = 'SDMT'
      #csv per prove CPTE/U
      if self.dlg16.NOFalda.isChecked():
          self.HfaldaDMT = 'non presente'
      reportPath_CSV = self.FolderDMT + "/" + self.nomeDMT + "_report-calcoli.csv"
      # crea file csv per plot dati
      outDati = open(reportPath_CSV, 'w', newline='')
      data = csv.writer(outDati)
      data.writerow(['Committente', self.dlg16.committente.text()])
      data.writerow(['Località', self.dlg16.luogo.text()])
      data.writerow(['Via', self.dlg16.indirizzo.text()])
      data.writerow(['Prova', self.dlg16.NP_DMT.text()])
      data.writerow(['Tipo Prova', self.type])
      data.writerow(['Tipo di Prova', 'Prof. max', 'Falda'])
      data.writerow(['SDMT', round(self.varZ.max(), 2), self.HfaldaDMT])
      data.writerow(['Prof. (m)', 'A (kPa)', 'B (kPa)', 'C (kPa)', 'P0 (kPa)', 'P1 (kPa)', 'P2 (kPa)', 'gamma (KN/m3)',
                      'Sigmavp(kPa)','U (kPa)', 'Id', 'Kd', 'Ed (kPa)','Ko' ,'Ud', 'OCR', 'M (MPa)', 'Cu (kPa)',
                       'phi (°)', 'Litologia','Prof.Vs (m)', 'Vs (m/s)','G0 (Mpa)','Rho (kg/mc)'])

      for i in range(0, len(self.varZ)):
          data.writerow([round(self.varZ[i], 1), round(self.varA[i], 0), round(self.varB[i], 0), round(self.varC[i], 0),
                         round(self.varPo[i], 1), round(self.varP1[i], 1), round(self.varP2[i], 1), round(self.varGamma[i], 1),
                         round(self.varSigma[i], 2), round(self.varU[i], 1), round(self.varId[i], 2), round(self.varKd[i], 1),
                         round(self.varEd[i], 2), round(self.varUd[i], 1), round(self.varKo[i], 2), round(self.varOCR[i], 2),
                         round(self.varM[i], 1),round(self.varCu[i], 1), round(self.varPhi[i], 1), (self.varLT[i]), round(self.varZvs[i], 1),
                         round(self.varVs[i], 2), round(self.varG0[i], 2),round(self.varRho[i], 2),])
      outDati.close()
 
   #plot report pdf dati ###############finire di compilare da quaaaa
   #crea percorso salvataggio pdf
   reportPath=self.FolderDMT+"/"+self.nomeDMT+"_report.pdf"

   doc = SimpleDocTemplate(reportPath,pagesize=A4,
                        rightMargin=72,leftMargin=10,
                        topMargin=30,bottomMargin=10)

   doc = BaseDocTemplate(reportPath, pagesize=A4, rightMargin=25, leftMargin=25, topMargin=25, bottomMargin=25)
   portrait_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='portrait_frame ')
   landscape_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.height, doc.width, id='landscape_frame ')


   doc = SimpleDocTemplate(reportPath, pagesize=A4,
                           rightMargin=72, leftMargin=10,
                           topMargin=30, bottomMargin=10)

   #variabile contenitore
   report=[]
   report.append(NextPageTemplate('landscape'))
   logo=self.logo_path+"\Logo_CPT.png"
   im = rpImage(logo, 0.4*inch, 0.4*inch)
   im.hAlign ='RIGHT'
   report.append(im)
   #titolo
   style = ParagraphStyle(
         name='Normal',
          fontName='Helvetica-Bold',
           fontSize=16,
            )
   
   report.append(Paragraph("Geo Utilities V. 2.0", style))

   style = ParagraphStyle(
         name='Normal',
          fontName='Helvetica',
           fontSize=12,
            )
   logo=self.logo_path+"\logo-report.png"
   im = rpImage(logo, 0.33*inch, 0.3*inch)
   im.hAlign ='RIGHT'
   report.append(im)
   report.append(Spacer(1,5))
   #verifica se è presente il logo personalizzzato e lo usa
   try:
      logoC=self.logo_path+"\logo-custom.jpg"
      imC = rpImage(logoC, 0.35*inch, 0.35*inch)
      imC.hAlign ='RIGHT'
      report.append(imC)
   except OSError:
      print('salva senza logo personalizzato')
      pass

   report.append(Paragraph("Report calcolo prova dilatometrica", style))
   report.append(Spacer(1,10))

   style4 = ParagraphStyle(
          name='orario',
           fontName='Helvetica',
            fontSize=8,
             )
   #orario
   ora=time.strftime("%H:%M:%S")
   #data
   data=time.strftime("%d/%m/%Y")
   report.append(Paragraph(str(data), style4))
   report.append(Paragraph(str(ora), style4))
   report.append(Spacer(1,5))

   # inizializzazione proprietà documento

   #intestazione
   # dati relativi commitenza
   Dcomm=[['Committente',self.dlg16.committente.text()],
        ['Località',self.dlg16.luogo.text()],
         ['Via', self.dlg16.indirizzo.text()],
          ['Prova',self.dlg16.NP_DMT.text()],
          ['Tipo prova',self.type]]
   # crea celle tabella commitenza
   Comm=Table(Dcomm,2*[2*inch], 5*[0.2*inch],hAlign='LEFT')
   #stile tabella
   Comm.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                                ('FONTSIZE',(0,0), (-1,-1), 7.5),
                                  ('ALIGN',(0,0),(-1,-1),'LEFT'),
                                    ('VALIGN',        (0,0), (-1,-1), 'TOP'),
                                      ]))
   #appende tabella commitenza
   report.append(Comm)
   report.append(Spacer(1,5))
   report.append(Paragraph("Tabella 1 - Dati input", style))
   report.append(Spacer(1,5))
   # dati relativi
   output=[['Tipo di Prova','Profondità max (m)','Falda (m da p.c.)'],
           [self.type,round(self.varZ.max(), 2), self.HfaldaDMT]]
   #intestazione dataset
   Par1=Table(output,3*[2.4*inch], 2*[0.2*inch],hAlign='LEFT')
   #stile tabella
   Par1.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                              ('FONTSIZE',(0,0), (-1,-1), 7),
                                ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                 ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                    ]))
   report.append(Par1)
   report.append(Spacer(1,10))
   #tabella parametri

   report.append(PageBreak())
   report.append(NextPageTemplate('landscape'))

   report.append(Paragraph("1 - Tabella parametri prova dilatometrica" + ' ' + str(self.dlg16.NP_DMT.text()), style))
   report.append(Spacer(1, 20))
   # dati relativi pt 1
   Elval=[['Prof.\n(m)', 'A\n(kPa)', 'B\n(kPa)', 'C\n(kPa)', 'P0\n(kPa)', 'P1\n(kPa)', 'P2\n(kPa)', 'gamma\n(KN/m3)',
                'Sigmavp\n(kPa)', 'U\n(kPa)', 'Id', 'Kd', 'Ed\n(kPa)', 'Ko', 'Ud', 'OCR', 'M\n(MPa)', 'Cu\n(kPa)',
                    'phi\n(°)', 'Litologia']]
   Val=Table(Elval,20*[0.55*inch], 1*[0.4*inch],hAlign='LEFT')

   #stile tabella
   Val.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                          ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                            ('FONTSIZE',(0,0), (-1,-1), 7),
                             ('ALIGN',(0,0),(-1,-1),'CENTER'),
                              ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                ]))
   report.append(Val)    
   #appendi dati

   for i in range(0,len(self.varZ)):
        if self.varLT[i]=='FANGO E/O TORBA':
            varlito='FG/TRB'
        else:
            varlito= self.varLT[i]

        dati=[[round(self.varZ[i],1),round(self.varA[i],0),round(self.varB[i],0),round(self.varC[i],0),round(self.varPo[i],1),
                        round(self.varP1[i], 1),round(self.varP2[i],1),round(self.varGamma[i],1),round(self.varSigma[i],2),
                         round(self.varU[i], 1),round(self.varId[i], 2),round(self.varKd[i], 1),round(self.varEd[i], 2),
                          round(self.varUd[i], 1),round(self.varKo[i], 2),round(self.varOCR[i], 2),round(self.varM[i], 1),
                            round(self.varCu[i], 1),round(self.varPhi[i], 1),(varlito)]]
        DT = Table(dati, 20 * [0.55 * inch], 1 * [0.2 * inch], hAlign='LEFT')
        report.append(DT)
        report.append(NextPageTemplate('landscape'))

        #stile tabella
        DT.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),
                                ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                                 ('FONTSIZE',(0,0), (-1,-1), 6),
                                   ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                    ('VALIGN',        (0,0), (-1,-1), 'TOP'),
                                      ]))


   report.append(PageBreak())

   style2 = ParagraphStyle(
       name='Centrato',
       fontName='Helvetica',
       fontSize=9,
       alignment=TA_CENTER)



   report.append(Paragraph("1 - Parametri prova dilatometrica"+' '+str(self.dlg16.NP_DMT.text()), style))
   report.append(Spacer(1,40))

   #####################################
   fig1= self.F1_path
   #####################################

   Dati = rpImage(fig1,11.7*inch, 5*inch)
   report.append(Dati)
   report.append(Spacer(1,10))
   report.append(Paragraph("Fig 1 - Plot profondità-variabile della prova dilatometrica elaborata", style2))
   report.append(Spacer(1,5)) 
   logo=self.logo_path+"\logo-report.png"
   im = rpImage(logo, 0.33*inch, 0.3*inch)
   im.hAlign ='RIGHT'
   report.append(im)
   report.append(Spacer(1,20))

   report.append(NextPageTemplate('landscape'))
   report.append(PageBreak())

   report.append(Paragraph("1 - Parametri prova dilatometrica"+' '+str(self.dlg16.NP_DMT.text()), style))
   report.append(Spacer(1,40))

   #####################################
   fig2= self.F2_path
   #####################################

   Par_A = rpImage(fig2,11.7*inch, 5*inch)
   report.append(Par_A)
   report.append(Spacer(1,10))
   report.append(Paragraph("Fig 2 - Plot profondità-variabile della prova dilatometrica elaborata", style2))
   report.append(Spacer(1,5)) 
   logo=self.logo_path+"\logo-report.png"
   im = rpImage(logo, 0.33*inch, 0.3*inch)
   im.hAlign ='RIGHT'
   report.append(im)
   report.append(Spacer(1,10))

   txtlt= "Fig 3 - Classificazione lotologica Id-Ed  "
   #solo per SDMT


   if self.type=='SDMT':
        report.append(PageBreak())
        report.append(Paragraph("2 - Tabella parametri sismici" + ' ' + str(self.dlg16.NP_DMT.text()), style))
        report.append(Spacer(1, 20))
        Elval = [['Prof.Vs (m)', 'Vs (m/s)', 'G0 (Mpa)', 'Rho (kg/mc)']]
        Val = Table(Elval, 4 * [1.5 * inch], 1 * [0.4 * inch], hAlign='RIGHT')
        Val.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.2, colors.black),
                                 ('BOX', (0, 0), (-1, -1), 0.2, colors.black),
                                 ('FONTSIZE', (0, 0), (-1, -1), 7),
                                 ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                 ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                                 ]))
        report.append(Val)

        for i in range(0, len(self.varZvs)):
               if self.varZvs[i]==0:
                   pass
               else:
                   dati = [[round(self.varZvs[i], 1),round(self.varVs[i], 2), round(self.varG0[i], 2), round(self.varRho[i], 2), ]]
                   # intestazione dataset
                   DT = Table(dati, 4 * [1.5 * inch], 1 * [0.2 * inch], hAlign='RIGHT')
                   report.append(DT)
                    # stile tabella
                   DT.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.2, colors.black),
                                            ('BOX', (0, 0), (-1, -1), 0.2, colors.black),
                                            ('FONTSIZE', (0, 0), (-1, -1), 7),
                                            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                                            ]))
        report.append(NextPageTemplate('landscape'))
        report.append(PageBreak())


        report.append(Paragraph("2 - Parametri sismici prova dilatometrica"+' '+str(self.dlg16.NP_DMT.text()), style))
        report.append(Spacer(1,40))

        #####################################
        fig3= self.F3_path
        #####################################

        Par_B = rpImage(fig3,5.85*inch, 5*inch)
        report.append(Par_B)
        report.append(Spacer(1,10))
        report.append(Paragraph("Fig 3 - Plot profondità-variabile della prova dilatometrica elaborata", style2))
        report.append(Spacer(1,5))
        logo=self.logo_path+"\logo-report.png"
        im = rpImage(logo, 0.33*inch, 0.3*inch)
        im.hAlign ='RIGHT'
        report.append(im)
        report.append(Spacer(1,10))

        report.append(NextPageTemplate('landscape'))
        report.append(PageBreak())
        txtlt = "Fig 4 - Classificazione lotologica Id-Ed  "

   else:
       report.append(NextPageTemplate('landscape'))
       report.append(PageBreak())

   report.append(Paragraph("3 - Stratigrafia"+' '+str(self.dlg8.NP_CPT.text()), style))
   report.append(Spacer(1,10))

   #####################################
   fig4= self.F0_path
   #####################################

   Lito = rpImage(fig4,6*inch, 6*inch)
   report.append(Lito)
   report.append(Spacer(1,10))
   report.append(Paragraph(txtlt, style2))
   report.append(Spacer(1, 5))
   logo = self.logo_path + "\logo-report.png"
   im = rpImage(logo, 0.33 * inch, 0.3 * inch)
   im.hAlign = 'RIGHT'
   report.append(im)
   report.append(Spacer(1, 10))


   doc.addPageTemplates([PageTemplate(id='portrait',frames=portrait_frame),
                            PageTemplate(id='landscape',frames=landscape_frame, pagesize=landscape(A4))])
      
   doc.build(report)

def print_datiALL_dmt(self):
    self.comp_Path = self.FolderDMT + '\DMT_results.json'
    self.logo_path = os.path.dirname(os.path.realpath(__file__))
    # verifica sia presente il file risultati
    if os.path.exists(self.comp_Path) == False:
        msg = QMessageBox()
        msg.setWindowIcon(QtGui.QIcon('avviso.ico'))
        msg.setIcon(QMessageBox.Information)
        msg.setText("Output non presente, elaborare i dati prova, o verificare la directory caricata!")
        msg.setWindowTitle("Attenzione!")
        msg.exec_()
        return
    # cerca i nomi prove esistenti e crea una lista
    self.ListaP = []
    self.Hr = []
    self.ListaPM = []
    self.HrM = []
    for dr in range(100):
        lst = 'D' + str(dr + 1)
        try:
            if self.dict[lst].isChecked():
                for file in os.listdir(self.FolderDMT):
                    if fnmatch.fnmatch(file, 'input' + '*' + '.json'):
                        with open(self.FolderDMT + '/' + file) as leggi:
                            data = json.load(leggi)
                            if data['Tipo'] == 'SDMT':
                                self.ListaPM = np.append(self.ListaPM, data['name'])
                                self.HrM = np.append(self.HrM, np.float_(data['H']).max())
                            if data['Tipo'] == 'DMT':
                                self.ListaP = np.append(self.ListaP, data['name'])
                                self.Hr = np.append(self.Hr, np.float_(data['H']).max())
        except KeyError:
            pass
        except RuntimeError:
            pass

    # liimti aree indici
    self.HrM=np.array(self.HrM)
    self.Hr = np.array(self.Hr)
    try:
        m1=self.HrM.max()
    except ValueError:
        m1=0
    try:
        m2=self.Hr.max()
    except ValueError:
        m2=0
    self.Hmax = max(m1,m2)
    self.figBaseDMTM, (aID, aED, aOCR, aK0) = plt.subplots(1, 4)
    self.figBaseDMTM.tight_layout()
    # # array assex
    # # Id
    aID.set_title('Indice di Materiale', fontsize=11)
    aID.set_xlabel('Id', fontsize=9.5)
    aID.set_ylabel('Prof (m)', fontsize=9.5)
    aID.invert_yaxis()
    aID.set_xscale('log')
    # Set the x-axis limit
    aID.set_xlim([0.1, 10])
    aID.grid(which='both', linestyle='--')
    # # ED
    aED.set_title('Modulo dilatometrico', fontsize=11)
    aED.set_xlabel('Ed (MPa)', fontsize=9.5)
    aED.set_ylabel('Prof (m)', fontsize=9.5)
    aED.invert_yaxis()
    aED.grid(linestyle='--')
    # # OCR
    aOCR.set_title('OCR', fontsize=11)
    aOCR.set_xlabel('OCR', fontsize=9.5)
    aOCR.set_ylabel('Prof (m)', fontsize=9.5)
    aOCR.invert_yaxis()
    aOCR.grid(linestyle='--')
    # # Ko
    aK0.set_title('Spinta orr. in sito', fontsize=11)
    aK0.set_xlabel('K0', fontsize=9.5)
    aK0.set_ylabel('Prof (m)', fontsize=9.5)
    aK0.invert_yaxis()
    aK0.grid(linestyle='--')

    self.figBase2DMTM, (aKD, aM, aCU, aPHI) = plt.subplots(1, 4)
    self.figBase2DMTM.tight_layout()
    ##kd
    aKD.set_title('Indice di spinta orizzontale', fontsize=11)
    aKD.set_xlabel('Kd', fontsize=9.5)
    aKD.set_ylabel('Prof (m)', fontsize=9.5)
    aKD.invert_yaxis()
    aKD.grid(linestyle='--')
    # # M
    aM.set_title('Modulo Edometrico', fontsize=11)
    aM.set_xlabel('M (MPa)', fontsize=9.5)
    aM.set_ylabel('Prof (m)', fontsize=9.5)
    aM.invert_yaxis()
    aM.grid(linestyle='--')
    # # CU
    aCU.set_title('Resistenza al taglio non drenata', fontsize=11)
    aCU.set_xlabel('Cu (kPa)', fontsize=9.5)
    aCU.set_ylabel('Prof (m)', fontsize=9.5)
    aCU.invert_yaxis()
    aCU.grid(linestyle='--')
    # # PHI
    aPHI.set_title('Angolo di attrito', fontsize=11)
    aPHI.set_xlabel('φ (°)', fontsize=9.5)
    aPHI.set_ylabel('Prof (m)', fontsize=9.5)
    aPHI.invert_yaxis()
    aPHI.grid(linestyle='--')

    #SDMT
    self.figBase3DMTM, (aVS, aG0) = plt.subplots(1, 2)
    self.figBase3DMTM.tight_layout()
    ## Vs
    aVS.set_title('Velocità onde di taglio', fontsize=11)
    aVS.set_xlabel('Vs', fontsize=9.5)
    aVS.set_ylabel('Prof (m/s)', fontsize=9.5)
    aVS.invert_yaxis()
    aVS.grid(linestyle='--')
    ## G0
    aG0.set_title('Modulo di taglio massimo', fontsize=11)
    aG0.set_xlabel('G0 (MPa)', fontsize=9.5)
    aG0.set_ylabel('Prof (m)', fontsize=9.5)
    aG0.invert_yaxis()
    aG0.grid(linestyle='--')

    # lista colori
    color = ['k', 'r', 'b', 'g', 'c', 'm', 'xkcd:forest green', 'xkcd:mustard', 'xkcd:lilac', 'xkcd:navy',
             'xkcd:lime', 'xkcd:maroon', 'xkcd:gold', 'xkcd:salmon',
             'xkcd:grey', 'xkcd:tan', 'xkcd:mauve', 'xkcd:ochre', 'xkcd:steel blue', 'xkcd:brick']
    # apre file risultati
    with open(self.comp_Path) as loadRes:
        dtRes = json.load(loadRes)
        if type(dtRes) is dict:
            self.listZmax=[]
            self.listEdmax = []
            self.listOCRmax = []
            self.listKomax = []
            self.listKdmax = []
            self.listMmax = []
            self.listCumax = []
            self.listPhimax = []
            self.listZvsmax = []
            self.listVsmax = []
            self.listG0max = []
            self.listtype=[]
            for dmt in range(len(self.ListaP)):
                labLeg = str(self.ListaP[dmt])
                # get data
                self.varZ = np.float_(dtRes[self.ListaP[dmt]][0]['H'])
                self.varId = np.float_(dtRes[self.ListaP[dmt]][0]['Id'])
                self.varEd= np.float_(dtRes[self.ListaP[dmt]][0]['Ed'])
                self.varOCR = np.float_(dtRes[self.ListaP[dmt]][0]['OCR'])
                self.varKo = np.float_(dtRes[self.ListaP[dmt]][0]['Ko'])
                self.varKd = np.float_(dtRes[self.ListaP[dmt]][0]['Kd'])
                self.varM = np.float_(dtRes[self.ListaP[dmt]][0]['M'])
                self.varCu = np.float_(dtRes[self.ListaP[dmt]][0]['Cu'])
                self.varPhi = np.float_(dtRes[self.ListaP[dmt]][0]['Phi'])
                self.type = dtRes[self.ListaP[dmt]][0]['Tipo']

                #creo lista dei massimi e delle tipologie
                self.listZmax = np.append(self.listZmax,self.varZ.max())
                self.listEdmax = np.append(self.listEdmax,self.varEd.max())
                self.listOCRmax = np.append(self.listOCRmax,self.varOCR.max())
                self.listKomax = np.append(self.listKomax,self.varKo.max())
                self.listKdmax = np.append(self.listKdmax,self.varKd.max())
                self.listMmax = np.append(self.listMmax,self.varM.max())
                self.listCumax = np.append(self.listCumax,self.varCu.max())
                self.listPhimax = np.append(self.listPhimax,self.varPhi.max())
                self.listtype.append(self.type)

                #plot delle variabili
                self.fspulID = np.ma.masked_where(self.varId == 0, self.varId)
                aID.plot(self.fspulID, self.varZ,  str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspul = np.ma.masked_where(self.varEd == 0, self.varEd)
                aED.plot(self.fspul, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulOCR = np.ma.masked_where(self.varOCR == 0, self.varOCR)
                aOCR.plot(self.fspulOCR, self.varZ,str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulko = np.ma.masked_where(self.varKo == 0, self.varKo)
                aK0.plot(self.fspulko, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulkd = np.ma.masked_where(self.varKd == 0, self.varKd)
                aKD.plot(self.fspulkd, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulM = np.ma.masked_where(self.varM == 0, self.varM)
                aM.plot(self.fspulM, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulCu = np.ma.masked_where(self.varCu == 0, self.varCu)
                aCU.plot(self.fspulCu, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulPHI = np.ma.masked_where(self.varPhi == 0, self.varPhi)
                aPHI.plot(self.fspulPHI, self.varZ, str(color[dmt]), markersize=7, label=labLeg)

            for dmt in range(len(self.ListaPM)):
                labLeg = str(self.ListaPM[dmt])
                # get data
                self.varZ = np.float_(dtRes[self.ListaPM[dmt]][0]['H'])
                self.varId = np.float_(dtRes[self.ListaPM[dmt]][0]['Id'])
                self.varEd= np.float_(dtRes[self.ListaPM[dmt]][0]['Ed'])
                self.varOCR = np.float_(dtRes[self.ListaPM[dmt]][0]['OCR'])
                self.varKo = np.float_(dtRes[self.ListaPM[dmt]][0]['Ko'])
                self.varKd = np.float_(dtRes[self.ListaPM[dmt]][0]['Kd'])
                self.varM = np.float_(dtRes[self.ListaPM[dmt]][0]['M'])
                self.varCu = np.float_(dtRes[self.ListaPM[dmt]][0]['Cu'])
                self.varPhi = np.float_(dtRes[self.ListaPM[dmt]][0]['Phi'])
                self.varZvs = np.float_(dtRes[self.ListaPM[dmt]][0]['Zvs'])
                self.varVs = np.float_(dtRes[self.ListaPM[dmt]][0]['Vs'])
                self.varG0 = np.float_(dtRes[self.ListaPM[dmt]][0]['G0'])
                self.type = dtRes[self.ListaPM[dmt]][0]['Tipo']

                # creo lista dei massimi e delle tipologie
                self.listZmax = np.append(self.listZmax, self.varZ.max())
                self.listEdmax = np.append(self.listEdmax, self.varEd.max())
                self.listOCRmax = np.append(self.listOCRmax, self.varOCR.max())
                self.listKomax = np.append(self.listKomax, self.varKo.max())
                self.listKdmax = np.append(self.listKdmax, self.varKd.max())
                self.listMmax = np.append(self.listMmax, self.varM.max())
                self.listCumax = np.append(self.listCumax, self.varCu.max())
                self.listPhimax = np.append(self.listPhimax, self.varPhi.max())
                self.listZvsmax = np.append(self.listZvsmax, self.varZvs.max())
                self.listVsmax = np.append(self.listVsmax, self.varVs.max())
                self.listG0max = np.append(self.listG0max, self.varG0.max())
                self.listtype.append(self.type)

                newVs = []
                newZvs = []
                for v in range(0, len(self.varVs)):
                    if self.varVs[v] != 0:
                        if v == 0:
                            newVs = np.append(newVs, self.varVs[v])
                            newVs = np.append(newVs, self.varVs[v])
                            newZvs = np.append(newZvs, 0)
                            newZvs = np.append(newZvs, self.varZvs[v])
                        else:
                            newVs = np.append(newVs, self.varVs[v])
                            newVs = np.append(newVs, self.varVs[v])
                            newZvs = np.append(newZvs, self.varZvs[v - 1])
                            newZvs = np.append(newZvs, self.varZvs[v])

                newG0 = []
                newZvs2 = []
                for v in range(0, len(self.varVs)):
                    if self.varVs[v] != 0:
                        newG0 = np.append(newG0, self.varG0[v])
                        newZvs2 = np.append(newZvs2, self.varZvs[v])

                #plot delle variabili
                self.fspulID = np.ma.masked_where(self.varId == 0, self.varId)
                aID.plot(self.fspulID, self.varZ,  str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspul = np.ma.masked_where(self.varEd == 0, self.varEd)
                aED.plot(self.fspul, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulOCR = np.ma.masked_where(self.varOCR == 0, self.varOCR)
                aOCR.plot(self.fspulOCR, self.varZ,str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulko = np.ma.masked_where(self.varKo == 0, self.varKo)
                aK0.plot(self.fspulko, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulkd = np.ma.masked_where(self.varKd == 0, self.varKd)
                aKD.plot(self.fspulkd, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulM = np.ma.masked_where(self.varM == 0, self.varM)
                aM.plot(self.fspulM, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulCu = np.ma.masked_where(self.varCu == 0, self.varCu)
                aCU.plot(self.fspulCu, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulPHI = np.ma.masked_where(self.varPhi == 0, self.varPhi)
                aPHI.plot(self.fspulPHI, self.varZ, str(color[dmt]), markersize=7, label=labLeg)
                #
                aVS.plot(newVs, newZvs, str(color[dmt]), markersize=7, label=labLeg)
                #
                self.fspulG = np.ma.masked_where(newG0 == 0, newG0)
                aG0.plot(self.fspulG, newZvs2,str(color[dmt]), markersize=7, label=labLeg)


            # impostazionilimitiassi
            scaleX = np.array([5, 10, 20, 50, 100, 200, 250])
            aID.set_ylim([self.listZmax.max(), 0])
            aID.set_yticks(np.arange(0, self.listZmax.max(), 1))
            aED.set_ylim([self.listZmax.max(), 0])
            aED.set_yticks(np.arange(0, self.listZmax.max(), 1))
            idx1 = (np.abs(scaleX - self.listEdmax.max() / 5)).argmin()
            if self.listEdmax.max() / scaleX[idx1] < 2:
                fatt1 = scaleX[idx1 - 1]
            if self.listEdmax.max() / scaleX[idx1] > 8:
                fatt1 = scaleX[idx1 + 1]
            if self.listEdmax.max() / scaleX[idx1] < 8 or self.listEdmax.max() / scaleX[idx1] > 2:
                fatt1 = scaleX[idx1]
            aED.set_xticks(np.arange(0, self.listEdmax.max(), fatt1))
            aOCR.set_ylim([self.listZmax.max(), 0])
            aOCR.set_yticks(np.arange(0, self.listZmax.max(), 1))
            idx1 = (np.abs(scaleX - self.listOCRmax.max() / 5)).argmin()
            if self.listOCRmax.max() / scaleX[idx1] < 2:
                fatt1 = scaleX[idx1 - 1]
            if self.listOCRmax.max() / scaleX[idx1] > 8:
                fatt1 = scaleX[idx1 + 1]
            if self.listOCRmax.max() / scaleX[idx1] < 8 or self.listOCRmax.max() / scaleX[idx1] > 2:
                fatt1 = scaleX[idx1]
            aOCR.set_xticks(np.arange(0, self.listOCRmax.max(), fatt1))
            aK0.set_ylim([self.listZmax.max(), 0])
            aK0.set_yticks(np.arange(0, self.listZmax.max(), 1))
            idx1 = (np.abs(scaleX - self.listKomax.max() / 5)).argmin()
            if self.listKomax.max() < 5:
                fatt1 = 1
                aK0.set_xticks(np.arange(0, 5, fatt1))
                aK0.set_xlim([0, 5])
            else:
                if self.listKomax.max() / scaleX[idx1] < 2:
                    fatt1 = scaleX[idx1 - 1]
                if self.listKomax.max() / scaleX[idx1] > 8:
                    fatt1 = scaleX[idx1 + 1]
                if self.listKomax.max() / scaleX[idx1] < 8 or self.listKomax.max() / scaleX[idx1] > 2:
                    fatt1 = scaleX[idx1]
                aK0.set_xticks(np.arange(0, self.listKomax.max(), fatt1))
            aKD.set_ylim([self.listZmax.max(), 0])
            aKD.set_yticks(np.arange(0, self.listZmax.max(), 1))
            idx1 = (np.abs(scaleX - self.listKdmax.max() / 5)).argmin()
            if self.listKdmax.max() / scaleX[idx1] < 2:
                fatt1 = scaleX[idx1 - 1]
            if self.listKdmax.max() / scaleX[idx1] > 8:
                fatt1 = scaleX[idx1 + 1]
            if self.listKdmax.max() / scaleX[idx1] < 8 or self.listKdmax.max() / scaleX[idx1] > 2:
                fatt1 = scaleX[idx1]
            aKD.set_xticks(np.arange(0, self.listKdmax.max(), fatt1))
            aM.set_ylim([self.listZmax.max(), 0])
            aM.set_yticks(np.arange(0, self.listZmax.max(), 1))
            idx1 = (np.abs(scaleX -  self.listMmax.max() / 5)).argmin()
            if  self.listMmax.max() / scaleX[idx1] < 2:
                fatt1 = scaleX[idx1 - 1]
            if  self.listMmax.max() / scaleX[idx1] > 8:
                fatt1 = scaleX[idx1 + 1]
            if  self.listMmax.max() / scaleX[idx1] < 8 or  self.listMmax.max() / scaleX[idx1] > 2:
                fatt1 = scaleX[idx1]
            aM.set_xticks(np.arange(0,  self.listMmax.max(), fatt1))
            aCU.set_ylim([self.listZmax.max(), 0])
            aCU.set_yticks(np.arange(0, self.listZmax.max(), 1))
            idx1 = (np.abs(scaleX - self.listCumax.max() / 5)).argmin()
            if self.listCumax.max() / scaleX[idx1] < 2:
                fatt1 = scaleX[idx1 - 1]
            if self.listCumax.max() / scaleX[idx1] > 8:
                fatt1 = scaleX[idx1 + 1]
            if self.listCumax.max() / scaleX[idx1] < 8 or self.listCumax.max() / scaleX[idx1] > 2:
                fatt1 = scaleX[idx1]
            aCU.set_xticks(np.arange(0, self.listCumax.max(), fatt1))
            aPHI.set_ylim([self.listZmax.max(), 0])
            aPHI.set_yticks(np.arange(0, self.listZmax.max(), 1))
            idx1 = (np.abs(scaleX - self.listPhimax.max() / 5)).argmin()
            if self.listPhimax.max() / scaleX[idx1] < 2:
                fatt1 = scaleX[idx1 - 1]
            if self.listPhimax.max() / scaleX[idx1] > 8:
                fatt1 = scaleX[idx1 + 1]
            if self.listPhimax.max() / scaleX[idx1] < 8 or self.varCPhi.max() / scaleX[idx1] > 2:
                fatt1 = scaleX[idx1]
            aPHI.set_xticks(np.arange(0, self.listPhimax.max(), fatt1))

            checkSDMT='SMDT'
            if checkSDMT in self.listtype:
                aVS.set_ylim([self.listZvsmax.max(), 0])
                aVS.set_yticks(np.arange(0, self.listZvsmax.max(), 1))
                idx1 = (np.abs(scaleX - self.listVsmax.max() / 5)).argmin()
                if self.listVsmax.max() / scaleX[idx1] < 2:
                    fatt1 = scaleX[idx1 - 1]
                if self.listVsmax.max() / scaleX[idx1] > 8:
                    fatt1 = scaleX[idx1 + 1]
                if self.listVsmax.max() / scaleX[idx1] < 8 or self.listVsmax.max() / scaleX[idx1] > 2:
                    fatt1 = scaleX[idx1]
                aVS.set_xticks(np.arange(0, self.listVsmax.max(), fatt1))

                aG0.set_ylim([self.listZvsmax.max(), 0])
                aG0.set_yticks(np.arange(0, self.listZvsmax.max(), 1))
                idx1 = (np.abs(scaleX - self.listG0max.max() / 5)).argmin()
                if self.listG0max.max() / scaleX[idx1] < 2:
                    fatt1 = scaleX[idx1 - 1]
                if self.listG0max.max() / scaleX[idx1] > 8:
                    fatt1 = scaleX[idx1 + 1]
                if self.listG0max.max() / scaleX[idx1] < 8 or self.listG0max.max() / scaleX[idx1] > 2:
                    fatt1 = scaleX[idx1]
                aG0.set_xticks(np.arange(0, self.listG0max.max(), fatt1))
                #
    aID.legend(fontsize=7,  loc='best')
    aKD.legend(fontsize=7, loc='best')

    self.F1_pathM = self.FolderDMT + "/multireportgrafici_1.png"
    self.figBaseDMTM.set_size_inches((14.5, 6.2), forward=False)
    self.figBaseDMTM.savefig(self.F1_pathM, dpi=100)

    self.F2_pathM = self.FolderDMT +"/multireportgrafici_2.png"
    self.figBase2DMTM.set_size_inches((14.5, 6.2), forward=False)
    self.figBase2DMTM.savefig(self.F2_pathM, dpi=100)

    if len(self.ListaPM)>0:
        aVS.legend(fontsize=7, loc='best')
        self.F3_pathM = self.FolderDMT + "/multireportgrafici_3.png"
        self.figBase3DMTM.set_size_inches((7.25, 6.2), forward=False)
        self.figBase3DMTM.savefig(self.F3_pathM, dpi=100)

    # plot report pdf dati ###############finire di compilare da quaaaa
    # crea percorso salvataggio pdf
    reportPath = self.FolderDMT + "/DMT_multireport.pdf"

    doc = SimpleDocTemplate(reportPath, pagesize=A4,
                            rightMargin=72, leftMargin=10,
                            topMargin=30, bottomMargin=10)

    doc = BaseDocTemplate(reportPath, pagesize=A4, rightMargin=25, leftMargin=25, topMargin=25, bottomMargin=25)
    portrait_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='portrait_frame ')
    landscape_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.height, doc.width, id='landscape_frame ')

    doc = SimpleDocTemplate(reportPath, pagesize=A4,
                            rightMargin=72, leftMargin=10,
                            topMargin=30, bottomMargin=10)

    # variabile contenitore
    report = []
    report.append(NextPageTemplate('landscape'))
    logo = self.logo_path + "\Logo_CPT.png"
    im = rpImage(logo, 0.4 * inch, 0.4 * inch)
    im.hAlign = 'RIGHT'
    report.append(im)
    # titolo
    style = ParagraphStyle(
        name='Normal',
        fontName='Helvetica-Bold',
        fontSize=16,
    )

    report.append(Paragraph("Geo Utilities V. 2.0", style))

    style = ParagraphStyle(
        name='Normal',
        fontName='Helvetica',
        fontSize=12,
    )
    logo = self.logo_path + "\logo-report.png"
    im = rpImage(logo, 0.33 * inch, 0.3 * inch)
    im.hAlign = 'RIGHT'
    report.append(im)
    report.append(Spacer(1, 5))
    # verifica se è presente il logo personalizzzato e lo usa
    try:
        logoC = self.logo_path + "\logo-custom.jpg"
        imC = rpImage(logoC, 0.35 * inch, 0.35 * inch)
        imC.hAlign = 'RIGHT'
        report.append(imC)
    except OSError:
        print('salva senza logo personalizzato')
        pass

    report.append(Paragraph("Report prove dilatometriche", style))
    report.append(Spacer(1, 10))

    style4 = ParagraphStyle(
        name='orario',
        fontName='Helvetica',
        fontSize=8,
    )
    # orario
    ora = time.strftime("%H:%M:%S")
    # data
    data = time.strftime("%d/%m/%Y")
    report.append(Paragraph(str(data), style4))
    report.append(Paragraph(str(ora), style4))
    report.append(Spacer(1, 5))

    # inizializzazione proprietà documento

    # intestazione
    # dati relativi commitenza
    Dcomm = [['Committente', self.dlg16.committente.text()],
             ['Località', self.dlg16.luogo.text()],
             ['Via', self.dlg16.indirizzo.text()]]
    # crea celle tabella commitenza
    Comm = Table(Dcomm, 2 * [2 * inch], 3 * [0.2 * inch], hAlign='LEFT')
    # stile tabella
    Comm.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.2, colors.black),
                              ('BOX', (0, 0), (-1, -1), 0.2, colors.black),
                              ('FONTSIZE', (0, 0), (-1, -1), 7.5),
                              ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                              ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                              ]))
    # appende tabella commitenza
    report.append(Comm)
    report.append(Spacer(1, 30))
    report.append(Paragraph("Tabella 1 - Dati input", style))
    report.append(Spacer(1, 5))

    # dati relativi
    output = [['Pove DMT', 'Prove SDMT', 'Profondità max (m)'],
              [len(self.ListaP), len(self.ListaPM), self.Hmax]]
    # intestazione dataset
    Par1 = Table(output, 3 * [2.4 * inch], 2 * [0.2 * inch], hAlign='LEFT')
    # stile tabella
    Par1.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.2, colors.black),
                              ('BOX', (0, 0), (-1, -1), 0.2, colors.black),
                              ('FONTSIZE', (0, 0), (-1, -1), 7),
                              ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                              ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                              ]))
    report.append(Par1)
    report.append(Spacer(1, 10))
    # tabella parametri
    report.append(NextPageTemplate('landscape'))
    report.append(PageBreak())


    style2 = ParagraphStyle(
        name='Centrato',
        fontName='Helvetica',
        fontSize=9,
        alignment=TA_CENTER)

    report.append(Paragraph("1 - Parametri prove dilatometriche" , style))
    report.append(Spacer(1, 40))

    #####################################
    fig1 = self.F1_pathM
    #####################################

    Dati = rpImage(fig1, 11.7 * inch, 5 * inch)
    report.append(Dati)
    report.append(Spacer(1, 10))
    report.append(Paragraph("Fig 1 - Plot profondità-variabile delle prove dilatometriche elaborate", style2))
    report.append(Spacer(1, 5))
    logo = self.logo_path + "\logo-report.png"
    im = rpImage(logo, 0.33 * inch, 0.3 * inch)
    im.hAlign = 'RIGHT'
    report.append(im)
    report.append(Spacer(1, 20))

    report.append(NextPageTemplate('landscape'))
    report.append(PageBreak())

    report.append(Paragraph("1 - Parametri prove dilatometriche", style))
    report.append(Spacer(1, 40))

    #####################################
    fig2 = self.F2_pathM
    #####################################

    Par_A = rpImage(fig2, 11.7 * inch, 5 * inch)
    report.append(Par_A)
    report.append(Spacer(1, 10))
    report.append(Paragraph("Fig 2 - Plot profondità-variabile delle prove dilatometriche elaborate", style2))
    report.append(Spacer(1, 5))
    logo = self.logo_path + "\logo-report.png"
    im = rpImage(logo, 0.33 * inch, 0.3 * inch)
    im.hAlign = 'RIGHT'
    report.append(im)
    report.append(Spacer(1, 10))

    # solo per SDMT
    if self.type == 'SDMT':
        report.append(NextPageTemplate('landscape'))
        report.append(PageBreak())

        report.append(Paragraph("2 - Parametri sismici prove dilatometriche" , style))
        report.append(Spacer(1, 40))

        #####################################
        fig3 = self.F3_pathM
        #####################################
        Par_B = rpImage(fig3, 5.85 * inch, 5 * inch)
        report.append(Par_B)
        report.append(Spacer(1, 10))
        report.append(Paragraph("Fig 3 - Plot profondità-variabile delle prove dilatometriche elaborate", style2))
        report.append(Spacer(1, 5))
        logo = self.logo_path + "\logo-report.png"
        im = rpImage(logo, 0.33 * inch, 0.3 * inch)
        im.hAlign = 'RIGHT'
        report.append(im)
        report.append(Spacer(1, 10))

    doc.addPageTemplates([PageTemplate(id='portrait', frames=portrait_frame),
                          PageTemplate(id='landscape', frames=landscape_frame, pagesize=landscape(A4))])

    doc.build(report)