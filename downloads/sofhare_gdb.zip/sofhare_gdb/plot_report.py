#-*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'setup.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

#* Released under the GNU General Public License

##CPT_Office-V1.1_ evaluating liquefaction potential from CPTE and CPTU 
##Copyright(C) 2017 Umberto Grechi

##_CPT_Office-V1.1_ is free software; you can redistribute it and/or
##modify it under the terms of the GNU General Public License
##as published by the Free Software Foundation; either version 3
##of the License, or (at your option) any later version.

##_CPT_Office-V1.1_ is distributed in the hope that it will be useful,
##but WITHOUT ANY WARRANTY; without even the implied warranty of
##MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##GNU General Public License for more details.

##You should have received a copy of the GNU General Public License
##along with this program.  If not, see <http://www.gnu.org/licenses/>

from .GDB_plugin import*
import csv
import xlrd
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Frame,Table, TableStyle, NextPageTemplate, PageTemplate, BaseDocTemplate
from reportlab.platypus.flowables import PageBreak, Spacer
from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4,landscape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.platypus import Image as rpImage
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
import time

def print_dati(self):
   self.logo_path = os.path.dirname(os.path.realpath(__file__))
   if self.dlg8.CalCPTM.isChecked() or self.dlg8.CalCPT.isChecked():
      #csv per CPTm
      if self.dlg8.NOFalda.isChecked():
         self.Hfalda='non presente'
      reportPath_CSV=self.Folder+"/"+self.nomeP+"_report-calcoli.csv"
      #crea file csv per plot dati
      outDati=open(reportPath_CSV,'w',newline='')
      data=csv.writer(outDati)
      data.writerow(['Committente',self.dlg8.committente.text()])
      data.writerow(['Località',self.dlg8.luogo.text()])
      data.writerow(['Via',self.dlg8.indirizzo.text()])
      data.writerow(['Prova',self.dlg8.NP_CPT.text()])
      data.writerow(['Tipo Prova',self.dlg8.tipo_CPT.text()])
      data.writerow(['Tipo di Prova','Prof. max','Falda'])     
      data.writerow(['CPTU',round(self.H.max(),2),self.Hfalda])
      data.writerow(['Prof. (m)','qc (MPa)','fs (kPa)','qc/fs','Rf (%)','Tipo','gamma (KN/m3)','gammaS (KN/m3)','Sigmav (kPa)','Sigmavp(kPa)',
               'Eu (MPa)','Ey (MPa)','M (MPa)','G0 (MPa)','Dr (%)','OCR','k','cu (kPa)','phi (°)','tipoN'])

      for i in range(0,len(self.H)):
            data.writerow([round(self.H[i],2),round(self.Qc[i],2),round(self.fs[i],2),round(self.Qcfs[i],2),round(self.Rf[i],2),self.TipoT[i],
                        round(self.Gamma[i],2),round(self.Gamma[i]+1,2),round(self.sigma[i],2),round(self.sigmaP[i],2),str(self.Eu[i]),round(self.Ey[i],2),round(self.M[i],2),
                        round(self.G0[i],2),round(self.DR[i],2),str(self.OCR[i]),format(self.K[i],'10.2E'),round(self.cu[i],2),round(self.effPhi[i],2),(self.TipoN[i])])

      outDati.close()

   else:
      #csv per prove CPTE/U
      if self.dlg8.NOFalda.isChecked():
         self.Hfalda='non presente'
      reportPath_CSV=self.Folder+"/"+self.nomeP+"_report-calcoli.csv"
      #crea file csv per plot dati
      outDati=open(reportPath_CSV,'w',newline='')
      data=csv.writer(outDati)

      data.writerow(['Committente',self.dlg8.committente.text()])
      data.writerow(['Località',self.dlg8.luogo.text()])
      data.writerow(['Via',self.dlg8.indirizzo.text()])
      data.writerow(['Prova',self.dlg8.NP_CPT.text()])
      data.writerow(['Tipo Prova',self.dlg8.tipo_CPT.text()])
      data.writerow(['Tipo di Prova','Prof. max','Falda'])     
      data.writerow(['CPTU',round(self.H.max(),2),self.Hfalda])
      data.writerow(['Prof. (m)','qc (MPa)','fs (kPa)','u2 (kPa)','u0 (kPa)','Qt (MPa)','gamma (KN/m3)','Sigmav (kPa)','Sigmavp(kPa)',
                     'cu (kPa)','phi(°)','phi eff(°)','Rf (%)','FR (%)','Qt1','Qtn','IC','Dr (%)','Es (MPa)','M (MPa)','G0 (MPa)','OCR','K0','KSBT'])

      
      for i in range(0,len(self.H)):
               data.writerow([round(self.H[i],2),round(self.Qc[i],2),round(self.fs[i],2),round(self.u2[i],2),round(self.u0[i],2),round(self.Qt[i],2),
                               round(self.Gamma[i],2),round(self.sigma[i],2),round(self.sigmaP[i],2),round(self.cu[i],2),round(self.phi[i],2),round(self.effPhi[i],2),
                                 round(self.Rf[i],2),round(self.Fr[i],2),round(self.Qt1[i],2),round(self.QtnT[i],2),round(self.IC[i],2),round(self.DR[i],2),
                                   round(self.Es[i],2),round(self.M[i],2),round(self.G0[i],2),round(self.OCR[i],2),round(self.KO[i],2),round(self.Ksbt[i],2)])

      outDati.close()
 
   #plot report pdf dati
   #crea percorso salvataggio pdf
   reportPath=self.Folder+"/"+self.nomeP+"_report-calcoli.pdf"

   doc = SimpleDocTemplate(reportPath,pagesize=A4,
                        rightMargin=72,leftMargin=10,
                        topMargin=30,bottomMargin=10)
   #variabile contenitore
   report=[]
   logo=self.logo_path+"\Logo_CPT.png"
   im = rpImage(logo, 0.4*inch, 0.4*inch)
   im.hAlign ='RIGHT'
   report.append(im)
   #titolo
   style = ParagraphStyle(
         name='Normal',
          fontName='Helvetica-Bold',
           fontSize=16,
            )
   
   report.append(Paragraph("Geo Utilities V. 2.0", style))

   style = ParagraphStyle(
         name='Normal',
          fontName='Helvetica',
           fontSize=12,
            )
   logo=self.logo_path+"\logo-report.png"
   im = rpImage(logo, 0.33*inch, 0.3*inch)
   im.hAlign ='RIGHT'
   report.append(im)
   report.append(Spacer(1,5))
   #verifica se è presente il logo personalizzzato e lo usa
   try:
      logoC=self.logo_path+"\logo-custom.jpg"
      imC = rpImage(logoC, 0.35*inch, 0.35*inch)
      imC.hAlign ='RIGHT'
      report.append(imC)
   except OSError:
      print('salva senza logo personalizzato')
      pass

   report.append(Paragraph("Report calcolo prova penetrometrica", style))
   report.append(Spacer(1,10))

   style4 = ParagraphStyle(
          name='orario',
           fontName='Helvetica',
            fontSize=8,
             )
   #orario
   ora=time.strftime("%H:%M:%S")
   #data
   data=time.strftime("%d/%m/%Y")
   report.append(Paragraph(str(data), style4))
   report.append(Paragraph(str(ora), style4))
   report.append(Spacer(1,5))

   #intestazione
   # dati relativi commitenza
   Dcomm=[['Committente',self.dlg8.committente.text()],
        ['Località',self.dlg8.luogo.text()],
         ['Via', self.dlg8.indirizzo.text()],
          ['Prova',self.dlg8.NP_CPT.text()],
          ['Tipo prova',self.dlg8.tipo_CPT.text()]]
   # crea celle tabella commitenza
   Comm=Table(Dcomm,2*[2*inch], 5*[0.2*inch],hAlign='LEFT')
   #stile tabella
   Comm.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                                ('FONTSIZE',(0,0), (-1,-1), 7.5),
                                  ('ALIGN',(0,0),(-1,-1),'LEFT'),
                                    ('VALIGN',        (0,0), (-1,-1), 'TOP'),
                                      ]))
   #appende tabella commitenza
   report.append(Comm)
   report.append(Spacer(1,5))
   report.append(Paragraph("Tabella 1 - Dati input", style))
   report.append(Spacer(1,5))
   # dati relativi
   output=[['Tipo di Prova','Profondità max (m)','Falda (m da p.c.)'],
           [self.dlg8.tipo_CPT.text(),round(self.H.max(),2),self.Hfalda]]
   #intestazione dataset
   Par1=Table(output,3*[2.6*inch], 2*[0.2*inch],hAlign='LEFT')
   #stile tabella
   Par1.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                              ('FONTSIZE',(0,0), (-1,-1), 7),
                                ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                 ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                    ]))
   report.append(Par1)
   report.append(Spacer(1,10))
   #tabella parametri
   # dati relativi pt 1
   if self.dlg8.CalCPTM.isChecked() or self.dlg8.CalCPT.isChecked():
      Elval=[['Profondità (m)','qc (MPa)','fs (kPa)','Rf(%)','γ(KN/m3)','γs(KN/m3)','σv (kPa)','σvp(kPa)','Dr (%)','cu (kPa)','φ(°)']]
      Val=Table(Elval,11*[0.70*inch], 1*[0.2*inch],hAlign='LEFT')
   else:
      Elval=[['Prof.(m)','qc (MPa)','fs (kPa)','u2 (kPa)','u0 (kPa)','Qt (MPa)','γ (KN/m3)','σv (kPa)','σvp(kPa)','cu (kPa)','φ(°)','φ picco(°)','Dr (%)']]
      #intestazione dataset
      Val=Table(Elval,13*[0.60*inch], 1*[0.2*inch],hAlign='LEFT')
   #stile tabella
   Val.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                          ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                            ('FONTSIZE',(0,0), (-1,-1), 7),
                             ('ALIGN',(0,0),(-1,-1),'CENTER'),
                              ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                ]))
   report.append(Val)    
   #appendi dati
   if self.dlg8.CalCPTM.isChecked() or self.dlg8.CalCPT.isChecked():
      try:
           self.fd= float(self.Hfalda)
      except ValueError:
           self.fd=max(self.H)+1
      for i in range(0,len(self.H)):
           if self.fd>self.H[i]:
              dati=[[round(self.H[i],2),round(self.Qc[i],2),round(self.fs[i],2),round(self.Rf[i],2),
                     round(self.Gamma[i],2),round((self.Gamma[i]),2),round(self.sigma[i],2),round(self.sigmaP[i],2),
                     round(self.DR[i],2),round(self.cu[i],2),round(self.effPhi[i],2)]]
           else:
              dati = [[round(self.H[i], 2), round(self.Qc[i], 2), round(self.fs[i], 2), round(self.Rf[i], 2),
                        round(self.Gamma[i], 2), round((self.Gamma[i] + 1), 2), round(self.sigma[i], 2),
                        round(self.sigmaP[i], 2), round(self.DR[i], 2), round(self.cu[i], 2), round(self.effPhi[i], 2)]]

           #intestazione dataset
           DT=Table(dati,11*[0.7*inch], 1*[0.15*inch],hAlign='LEFT')
           #stile tabella
           DT.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                             ('FONTSIZE',(0,0), (-1,-1), 7),
                               ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                  ]))
           report.append(DT)
   else:
      for i in range(0,len(self.H)):
           dati=[[round(self.H[i],2),round(self.Qc[i],2),round(self.fs[i],2),round(self.u2[i],2),round(self.u0[i],2),round(self.Qt[i],2),round(self.Gamma[i],2),round(self.sigma[i],2),round(self.sigmaP[i],2),round(self.cu[i],2),round(self.phi[i],2),round(self.effPhi[i],2),round(self.DR[i],2)]]
           #intestazione dataset
           DT=Table(dati,13*[0.60*inch], 1*[0.15*inch],hAlign='LEFT')
           #stile tabella
           DT.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                             ('FONTSIZE',(0,0), (-1,-1), 7),
                               ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                  ]))
           report.append(DT)
   report.append(PageBreak())
   report.append(Paragraph("Tabella 2 - Dati output", style))
   report.append(Spacer(1,5))

   if self.dlg8.CalCPTM.isChecked() or self.dlg8.CalCPT.isChecked():
      Elval3=[['Profondità (m)','Tipo','OCR','K (cm/s)','Mo (MPa)','G (MPa)','Ey (MPa)','Eu (MPa)']]
      Val3 = Table(Elval3, 8 * [0.975 * inch], 1 * [0.2 * inch], hAlign='LEFT')
   else:   
      Elval3=[['Prof.(m)','Rf (%)','FR (%)','Qt1','Qtn','IC','Es (MPa)','M (MPa)','G0 (MPa)','OCR','K0','KSBT']]
      Val3 = Table(Elval3, 12* [0.65 * inch], 1 * [0.2 * inch], hAlign='LEFT')

   #stile tabella
   Val3.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                          ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                            ('FONTSIZE',(0,0), (-1,-1), 7),
                             ('ALIGN',(0,0),(-1,-1),'CENTER'),
                              ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                ]))
   report.append(Val3)
   if self.dlg8.CalCPTM.isChecked() or self.dlg8.CalCPT.isChecked():
      for i in range(0,len(self.H)):
           dati3=[[round(self.H[i],2),self.TipoT[i],self.OCR[i],str(format(self.K[i],'10.2E')),round(self.M[i],2),round(self.G0[i],2),round(self.Ey[i],2),round(self.Eu[i],2)]]
           #intestazione dataset
           DT3=Table(dati3,8*[0.975*inch], 1*[0.15*inch],hAlign='LEFT')
           #stile tabella
           DT3.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                             ('FONTSIZE',(0,0), (-1,-1), 7),
                               ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                  ]))
           report.append(DT3)

   else:
   #appendi dati
      for i in range(0,len(self.H)):
           dati3=[[round(self.H[i],2),round(self.Rf[i],2),round(self.Fr[i],2),round(self.Qt1[i],2),round(self.QtnT[i],2),round(self.IC[i],2),round(self.Es[i],2),round(self.M[i],2),round(self.G0[i],2),round(self.OCR[i],2),round(self.KO[i],2),str(format(self.Ksbt[i],'10.2E'))]]
           #intestazione dataset
           DT3=Table(dati3,12*[0.65*inch], 1*[0.15*inch],hAlign='LEFT')
           #stile tabella
           DT3.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                             ('FONTSIZE',(0,0), (-1,-1), 7),
                               ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                  ]))
           report.append(DT3)
   doc.build(report)

def print_grafici(self):
   self.logo_path = os.path.dirname(os.path.realpath(__file__))
   #plot report pdf con grafico
   #crea percorso salvataggio pdf
   if self.banchi==0:
       reportPath=self.Folder+"/"+self.nomeP+"_report-grafici.pdf"
   else :
       reportPath = self.Folder + "/" + self.nomeP + "_report-grafici_LT.pdf"
   #inizializzazione proprietà documento
   doc = BaseDocTemplate(reportPath, pagesize=A4, rightMargin=25, leftMargin=25, topMargin=25, bottomMargin=25)
   portrait_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='portrait_frame ')
   landscape_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.height, doc.width, id='landscape_frame ')
   
   doc = SimpleDocTemplate(reportPath,pagesize=A4,
                        rightMargin=72,leftMargin=10,
                        topMargin=30,bottomMargin=10)
   #variabile contenitore
   report=[]
      #logo CPT Office

   logo=self.logo_path+"\Logo_CPT.png"
   im = rpImage(logo, 0.4*inch, 0.4*inch)
   im.hAlign ='RIGHT'
   report.append(im)
   report.append(Spacer(1,5))
   try:
      logoC=self.logo_path+"\logo-custom.jpg"
      imC = rpImage(logoC, 0.35*inch, 0.35*inch)
      imC.hAlign ='RIGHT'
      report.append(imC)
   except OSError:
      print('salva senza logo personalizzato')
      pass
   #titolo
   style = ParagraphStyle(
            name='Normal',
            fontName='Helvetica-Bold',
            fontSize=16,
             )
   report.append(Paragraph("Geo Utilities V. 2.0", style))
   report.append(Spacer(1,20))
   style = ParagraphStyle(
            name='Normal',
            fontName='Helvetica',
            fontSize=12,
            )
   
   report.append(Paragraph("Elaborato grafico prova penetrometrica", style))
   report.append(Spacer(1,10))
   style4 = ParagraphStyle(
            name='orario',
            fontName='Helvetica',
            fontSize=8,
             )

   #orario
   ora=time.strftime("%H:%M:%S")
   #data
   data=time.strftime("%d/%m/%Y")
   report.append(Paragraph(str(data), style4))
   report.append(Paragraph(str(ora), style4))
   report.append(Spacer(1,20))
   #intestazione
   # dati relativi commitenza
   Dcomm=[['Committente',self.dlg8.committente.text()],
        ['Località',self.dlg8.luogo.text()],
         ['Via', self.dlg8.indirizzo.text()],
          ['Prova',self.dlg8.NP_CPT.text()],
           ['Tipo prova',self.dlg8.tipo_CPT.text()]]
   # crea celle tabella commitenza
   Comm=Table(Dcomm,2*[2*inch], 5*[0.2*inch],hAlign='LEFT')
   #stile tabella
   Comm.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                                  ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                                  ('FONTSIZE',(0,0), (-1,-1), 7.5),
                                  ('ALIGN',(0,0),(-1,-1),'LEFT'),
                                  ('VALIGN',        (0,0), (-1,-1), 'TOP'),
                                    ]))
   #appende tabella commitenza
   report.append(Comm)
   # dati relativi
   if self.dlg8.NOFalda.isChecked():
      self.Hfalda='non presente'
   output=[['Tipo di Prova','Prof. max (m)','Preforo (m)','Falda (m da p.c.)'],
           [self.dlg8.tipo_CPT.text(),round(self.H.max(),2),self.H.min(),self.Hfalda]]
   #intestazione dataset
   Par1=Table(output,4*[1.8*inch], 2*[0.2*inch],hAlign='LEFT')
   #stile tabella
   Par1.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                              ('FONTSIZE',(0,0), (-1,-1), 7),
                                ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                 ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                    ]))
   report.append(Par1)

   style2 = ParagraphStyle(
            name='Centrato',
            fontName='Helvetica',
            fontSize=9,
            alignment = TA_CENTER )


   report.append(Spacer(1,10))
   report.append(Paragraph("Tabella 1 - Informazioni generali", style2))
   #se inserisci intestazione di chi fa la prova cambia vaore 480
   report.append(Spacer(1,470))

   logo=self.logo_path+"\logo-report.png"
   im = rpImage(logo, 0.33*inch, 0.3*inch)
   im.hAlign ='RIGHT'
   report.append(im)
   #vado su nuova pagina e ruoto per il grafico
   #grafico dati
   report.append(NextPageTemplate('landscape'))
   report.append(PageBreak())

   report.append(Paragraph("1 - Parametri prova penetrometrica"+' '+str(self.dlg8.NP_CPT.text()), style))
   report.append(Spacer(1,5))
   fig1= self.F1_path
   Dati = rpImage(fig1,9*inch, 6*inch)
   report.append(Dati)
   report.append(Spacer(1,10))
   report.append(Paragraph("Fig 1 - Plot profondità-variabile della prova penetrometrica elaborata", style2))
   report.append(Spacer(1,5)) 
   logo=self.logo_path+"\logo-report.png"
   im = rpImage(logo, 0.33*inch, 0.3*inch)
   im.hAlign ='RIGHT'
   report.append(im)
   report.append(Spacer(1,20))

   report.append(NextPageTemplate('landscape'))
   report.append(PageBreak())

   report.append(Paragraph("1 - Parametri prova penetrometrica"+' '+str(self.dlg8.NP_CPT.text()), style))
   report.append(Spacer(1,5))
   fig3= self.F3_path
   Par_A = rpImage(fig3,9.3*inch, 6.3*inch)
   report.append(Par_A)
   report.append(Spacer(1,10))
   report.append(Paragraph("Fig 2 - Plot profondità-variabile della prova penetrometrica elaborata", style2))
   report.append(Spacer(1,5)) 
   logo=self.logo_path+"\logo-report.png"
   im = rpImage(logo, 0.33*inch, 0.3*inch)
   im.hAlign ='RIGHT'
   report.append(im)
   report.append(Spacer(1,10))
   
   report.append(NextPageTemplate('landscape'))
   report.append(PageBreak())

   #solo per CPTE/U
   if self.dlg8.CalCPTM.isChecked()==False and self.dlg8.CalCPT.isChecked()==False:
      report.append(Paragraph("1 - Parametri prova penetrometrica"+' '+str(self.dlg8.NP_CPT.text()), style))
      report.append(Spacer(1,5))
      fig4= self.F4_path
      Par_B = rpImage(fig4,9.3*inch, 6.3*inch)
      report.append(Par_B)
      report.append(Spacer(1,10))
      report.append(Paragraph("Fig 3 - Plot profondità-variabile della prova penetrometrica elaborata", style2))
      report.append(Spacer(1,5))
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,10))

      report.append(NextPageTemplate('landscape'))
      report.append(PageBreak())

      report.append(Paragraph("2 - SBT & SBT(n)"+' '+str(self.dlg8.NP_CPT.text()), style))
      report.append(Spacer(1,10))
      fig5= self.F_path
      SBT = rpImage(fig5,11.5*inch, 5*inch)
      report.append(SBT)
      report.append(Spacer(1,10))
      report.append(Paragraph("Fig 4 - A sinistra plot valori qc/Pa-Rf su SBT chart, a destra plot valori Qtn-Fr su SBT(n) chart ", style2))
      report.append(Spacer(1,5)) 
      logo=self.logo_path+"\logo-report.png"
      im = rpImage(logo, 0.33*inch, 0.3*inch)
      im.hAlign ='RIGHT'
      report.append(im)
      report.append(Spacer(1,10))
      report.append(NextPageTemplate('landscape'))
      report.append(PageBreak())
         
   if self.dlg8.CalCPTM.isChecked()==False and self.dlg8.CalCPT.isChecked()==False:
      #CPTE/CPTU
      report.append(Paragraph("2 - Stratigrafia"+' '+str(self.dlg8.NP_CPT.text()), style))
      report.append(Spacer(1,10))
      fig6= self.F2_path
      if self.banchi==0:
         Lito = rpImage(fig6,6*inch, 6*inch)
         report.append(Lito)
         report.append(Spacer(1,10))
         report.append(Paragraph("Fig 3 - A sinistra Indice SBT, a destra classificazione stratigrafica da SBT chart ", style2))
         report.append(Spacer(1,5))
      if self.banchi==1:
         Lito = rpImage(fig6,6*inch, 6*inch)
         report.append(Lito)
         report.append(Spacer(1,10))
         report.append(Paragraph("Fig 3 - A sinistra Indice SBT, a destra classificazione stratigrafica da SBT chart ", style2))
         logo=self.logo_path+"\logo-report.png"
         im = rpImage(logo, 0.33*inch, 0.3*inch)
         im.hAlign ='RIGHT'
         report.append(im)
         report.append(Spacer(1,5))
         report.append(NextPageTemplate('landscape'))
         report.append(PageBreak())
         #tabella parametri
         report.append(Paragraph("3 - Parametri unità litotecniche"+' '+str(self.dlg8.NP_CPT.text()), style))
         report.append(Spacer(1,30))
         intestaz=[['Nome','Tetto (m da p.c.)','Letto (m da p.c.)','Tipo','γ(KN/m3)','Cu (kPa)','φ(°)','Dr (%)','M (MPa)']]
         #intestazione dataset
         Val4=Table(intestaz,9*[0.85*inch], 1*[0.2*inch],hAlign='CENTER')
         #stile tabella
         Val4.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                             ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                               ('FONTSIZE',(0,0), (-1,-1), 6),
                                ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                 ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                   ]))
         report.append(Val4)  
         #appendi dati
         if len(self.Ntipo)==0:
            self.Ntipo=self.NtipoFitt
         for i in range(len(self.NameS)):
             datiTB=[[self.NameS[i],self.tetto[i],self.letto[i],self.Ntipo[i],round(self.meanGamma[i],2),round(self.meanCu[i],3),
                 round(self.meanPhi[i],2),round(self.meanDR[i],2),round(self.meanM[i],2)]]
             #intestazione dataset
             DTPM=Table(datiTB,9*[0.85*inch], 1*[0.2*inch],hAlign='CENTER')
             #stile tabella
             DTPM.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                             ('FONTSIZE',(0,0), (-1,-1), 7),
                               ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                  ]))
             report.append(DTPM)
         report.append(Spacer(1,10))
         report.append(Paragraph("Tabella 2 - Parametri medi unità litotecniche", style2))
         
   else:
      #CPTmeccanica
      report.append(Paragraph("2 - Stratigrafia"+' '+str(self.dlg8.NP_CPT.text()), style))
      report.append(Spacer(1,10))
      fig6= self.F2_path
      if self.banchi==0:
         Lito = rpImage(fig6,3*inch, 6*inch)
         report.append(Lito)
         report.append(Spacer(1,5))
         if self.ChoseLTM==0:
            report.append(Paragraph("Fig 3 - Grafico stratigrafia profondità secondo Schmertmann (1978)", style2))
         if self.ChoseLTM==1:
            report.append(Paragraph("Fig 3 - Grafico stratigrafia profondità secondo Begemann", style2))
         report.append(Spacer(1,5))
      if self.banchi==1:
         Lito = rpImage(fig6,3*inch, 6*inch)
         report.append(Lito)
         report.append(Spacer(1,5))
         if self.ChoseLTM==0:
            report.append(Paragraph("Fig 3 - Grafico stratigrafia profondità secondo Schmertmann (1978)", style2))
         if self.ChoseLTM==1:
            report.append(Paragraph("Fig 3 - Grafico stratigrafia profondità secondo Begemann", style2))
         logo=self.logo_path+"\logo-report.png"
         im = rpImage(logo, 0.33*inch, 0.3*inch)
         im.hAlign ='RIGHT'
         report.append(im)
         report.append(Spacer(1,5))
         report.append(NextPageTemplate('landscape'))
         report.append(PageBreak())
         report.append(Paragraph("3 - Parametri unità litotecniche"+' '+str(self.dlg8.NP_CPT.text()), style))
         report.append(Spacer(1,30))
         #tabella parametri
         intestaz=[['Nome','Tetto (m da p.c.)','Letto (m da p.c.)','Tipo','γ(KN/m3)','γs(KN/m3)','Cu (kPa)','φ(°)','Dr (%)','M (MPa)']]
         #intestazione dataset
         Val4=Table(intestaz,10*[0.85*inch], 1*[0.2*inch],hAlign='CENTER')
         #stile tabella
         Val4.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                             ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                               ('FONTSIZE',(0,0), (-1,-1), 7),
                                ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                 ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                   ]))
         report.append(Val4)
         if len(self.Ntipo)==0:
            self.Ntipo=self.NtipoFitt
         #appendi dati
         for i in range(len(self.NameS)):
             datiTB=[[self.NameS[i],self.tetto[i],self.letto[i],self.Ntipo[i],round(self.meanGamma[i],2),round(self.meanGammaS[i],2),round(self.meanCu[i],3),
                      round(self.meaneffPhi[i],2),round(self.meanDR[i],2),round(self.meanM[i],2)]]
             #intestazione dataset
             DTPM=Table(datiTB,10*[0.85*inch], 1*[0.2*inch],hAlign='CENTER')
             #stile tabella
             DTPM.setStyle(TableStyle([('INNERGRID', (0,0), (-1,-1), 0.2, colors.black),    
                            ('BOX', (0,0), (-1,-1), 0.2, colors.black),
                             ('FONTSIZE',(0,0), (-1,-1), 7),
                               ('ALIGN',(0,0),(-1,-1),'CENTER'),
                                ('VALIGN',        (0,0), (-1,-1), 'TOP'),                          
                                  ]))
             report.append(DTPM)
         report.append(Spacer(1,10))
         report.append(Paragraph("Tabella 2 - Parametri medi unità litotecniche", style2))
         
   doc.addPageTemplates([PageTemplate(id='portrait',frames=portrait_frame),
                            PageTemplate(id='landscape',frames=landscape_frame, pagesize=landscape(A4))])
      
   doc.build(report)
   
def print_report_diss(self):
    self.logo_path = os.path.dirname(os.path.realpath(__file__))
    # plot report pdf con grafico
    # inizializzazione proprietà documento
    reportPath0=self.save_diss.split('.png')
    reportPath=reportPath0[0]+'.pdf'
    doc = BaseDocTemplate(reportPath, pagesize=A4, rightMargin=25, leftMargin=25, topMargin=25, bottomMargin=25)
    portrait_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='portrait_frame ')
    landscape_frame = Frame(doc.leftMargin, doc.bottomMargin, doc.height, doc.width, id='landscape_frame ')

    doc = SimpleDocTemplate(reportPath, pagesize=A4,
                            rightMargin=72, leftMargin=10,
                            topMargin=30, bottomMargin=10)
    # variabile contenitore
    report = []
    # logo CPT Office
    logo = self.logo_path + "\Logo_CPT.png"
    im = rpImage(logo, 0.4 * inch, 0.4 * inch)
    im.hAlign = 'RIGHT'
    report.append(im)
    report.append(Spacer(1, 5))
    try:
        logoC = self.logo_path + "\logo-custom.jpg"
        imC = rpImage(logoC, 0.35 * inch, 0.35 * inch)
        imC.hAlign = 'RIGHT'
        report.append(imC)
    except OSError:
        print('salva senza logo personalizzato')
        pass
    # titolo
    style = ParagraphStyle(
        name='Normal',
        fontName='Helvetica-Bold',
        fontSize=16,
    )
    report.append(Paragraph("Geo Utilities V. 2.0", style))
    report.append(Spacer(1, 20))
    style = ParagraphStyle(
        name='Normal',
        fontName='Helvetica',
        fontSize=12,
    )
    report.append(Paragraph("Elaborato prova dissipazione", style))
    report.append(Spacer(1, 10))
    style4 = ParagraphStyle(
        name='orario',
        fontName='Helvetica',
        fontSize=8,
    )
    # orario
    ora = time.strftime("%H:%M:%S")
    # data
    data = time.strftime("%d/%m/%Y")
    report.append(Paragraph(str(data), style4))
    report.append(Paragraph(str(ora), style4))
    report.append(Spacer(1, 20))
    # intestazione
    # dati relativi commitenza
    Dcomm = [['Committente', self.dlg8.committente.text()],
             ['Località', self.dlg8.luogo.text()],
             ['Via', self.dlg8.indirizzo.text()],
             ['Prova', self.dlg8.NP_CPT.text()],
             ['Tipo prova', 'Test a dissipazione']]
    # crea celle tabella commitenza
    Comm = Table(Dcomm, 2 * [2 * inch], 5 * [0.2 * inch], hAlign='LEFT')
    # stile tabella
    Comm.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.2, colors.black),
                              ('BOX', (0, 0), (-1, -1), 0.2, colors.black),
                              ('FONTSIZE', (0, 0), (-1, -1), 7.5),
                              ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                              ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                              ]))
    # appende tabella commitenza
    report.append(Comm)
    # dati relativi
    if self.Pfd >= self.hpr:
        self.esito='non elaborabile'
    else:
        self.esito='elaborata'

    output = [['Codice prova', 'Prof. prova (m)', 'Falda (m da p.c.)','Esito prova'],
              [self.nmds, self.hpr, self.Pfd,self.esito]]
    # intestazione dataset
    Par1 = Table(output, 4 * [1.8 * inch], 2 * [0.2 * inch], hAlign='LEFT')
    # stile tabella
    Par1.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.2, colors.black),
                              ('BOX', (0, 0), (-1, -1), 0.2, colors.black),
                              ('FONTSIZE', (0, 0), (-1, -1), 7),
                              ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                              ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                              ]))
    report.append(Par1)
    style2 = ParagraphStyle(
        name='Centrato',
        fontName='Helvetica',
        fontSize=9,
        alignment=TA_CENTER)
    report.append(Spacer(1, 10))
    report.append(Paragraph("Tabella 1 - Informazioni generali", style2))
    # se inserisci intestazione di chi fa la prova cambia vaore 480
    report.append(Spacer(1, 15))
    # grafico dati
    #report.append(NextPageTemplate('landscape'))
    #report.append(PageBreak())
    report.append(Spacer(1, 5))
    fig_diss = self.save_diss
    Dati = rpImage(fig_diss,  3.15* inch, 4.2 * inch)
    report.append(Dati)
    report.append(Spacer(1, 10))
    report.append(Paragraph("Fig 1 - In alto: Plot grafici curva test dissipazione.\n In basso: Plot grafici curva normalizzata test dissipazione", style2))
    report.append(Spacer(1, 20))
    intestaz = [['Codice prova', 'Ir','M (MPa)', 't50 (s)', 'Ch (m2/s)', 'Kh (m/s)']]
    # intestazione dataset
    Val4 = Table(intestaz, 6 * [1 * inch], 1 * [0.3 * inch], hAlign='CENTER')
    # stile tabella
    Val4.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.2, colors.black),
                                      ('BOX', (0, 0), (-1, -1), 0.2, colors.black),
                                      ('FONTSIZE', (0, 0), (-1, -1), 7),
                                      ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                      ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                                      ]))
    report.append(Val4)

    if self.Pfd >= self.hpr:
        datiTB = [[self.nmds, self.irr, self.Mdef,'-', self.ch, self.kh]]
    else:
        datiTB = [[self.nmds, self.irr, self.Mdef,round(self.T50t[0],2),format(self.ch, '10.2E'),format(self.kh, '10.2E')]]
    # intestazione dataset
    DTPM = Table(datiTB, 6 * [1 * inch], 1 * [0.2 * inch], hAlign='CENTER')
    # stile tabella
    DTPM.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.2, colors.black),
                                          ('BOX', (0, 0), (-1, -1), 0.2, colors.black),
                                          ('FONTSIZE', (0, 0), (-1, -1), 7),
                                          ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                          ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                                          ]))
    report.append(DTPM)
    report.append(Spacer(1, 10))
    report.append(Paragraph("Tabella 2 - Parametri prova dissipazione", style2))

    if self.ch==0:
        report.append(Spacer(1, 10))
        report.append(Paragraph("Prova non elaborabile, falda non presente alla profondità indagata", style2))
    style = ParagraphStyle(
        name='Normal',
        fontName='Helvetica',
        fontSize=6,
    )
    report.append(Paragraph("Ch Ottenuto mediante correlazione proposta da Houlsby e Teh (1988), Kh=Ch*γw/M ", style))
    logo = self.logo_path + "\logo-report.png"
    report.append(Spacer(1, 10))
    im = rpImage(logo, 0.33 * inch, 0.3 * inch)
    im.hAlign = 'RIGHT'
    report.append(im)
    doc.build(report)
    
