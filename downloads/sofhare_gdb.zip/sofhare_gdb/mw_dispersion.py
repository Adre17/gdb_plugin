# -*- coding: utf-8 -*-

from sys import platform as sys_pf

from obspy import read
import numpy   as np
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.pyplot as plt


from .GDB_plugin import*


# ------ Dispersion processing: Import seismic data ------
# Import data from a text file, general requirements:      
# - By default, it is assumed that the recorded data is stored in 
#   a whitespace/tab-delimited text file. If a different string is 
#   used to separate values, it should be provided as an additional 
#   keyword argument (e.g., delimiter=',' for a comma-separated textfile).
# - The number of header lines, including comments, is header_lines.
# - Each trace must be stored in a single column.
# - All traces must be of equal length and missing values are not 
#   allowed (each row in the text file must include the same number
#   of values).
#
# Seismic data can also be imported from any waveform file that can be read by 
# the obspy.read() function from the ObsPy library using the from_waveform
# class method. See https://docs.obspy.org/packages/autogen/obspy.core.stream.read.html
# for a list of supported file formats.


def seismogramreplot(self):
    # Define the path to the .sg2 file
    file_path = r'C:\Users\umber\Desktop\maswavespy-main\examples\2_10da1_1.sg2'

    # Step 1: Read the SG2 file
    try:
        st = read(file_path)  # Read the .sg2 file
    except Exception as e:
        exit()
    # Step 2: Check the sampling frequency
    if len(st) > 0:
        sampling_frequency = st[0].stats.sampling_rate
    else:
        print("No traces found in the SG2 file.")

    # Step 2: Remove the last 12 traces if there are more than 12 traces
    num_traces = len(st)
    if num_traces > 12:
        traces = st[:-12]  # Keep all traces except the last 12
    else:
        traces = st  # If there are less than or equal to 12 traces, keep all of them

    valid_trace_count = len(traces)

    # Step 3: Check if there are valid traces to plot and save
    if valid_trace_count == 0:
        print("No valid traces to plot.")
    else:
        plt.figure(figsize=(12, 8))

        # Prepare a list to store the trace data for saving
        trace_data = []

        # Step 4: Loop through each trace to plot it
        for i, trace in enumerate(traces):
            # Create a time vector based on the sampling rate in milliseconds
            time_vector = np.arange(trace.stats.npts) / trace.stats.sampling_rate * 1000  # Convert to milliseconds

            # Plot each trace with an offset for clarity (4 meters apart)
            plt.plot(trace.data + (i * 4), time_vector, label=f'Trace {i + 1}',color='#000000', linewidth=0.5)  # Offset each trace by 4 meters

            # Append the trace data to the list
            trace_data.append(trace.data)

        # Convert the list to a 2D numpy array and transpose to get shape (n_samples, n_traces)
        trace_array = np.array(trace_data).T

        # Step 5: Write the data to a tab-separated text file
        output_file_path = r'C:\Users\umber\Desktop\maswavespy-main\examples\trace_data.txt'
        np.savetxt(output_file_path, trace_array, delimiter='\t', fmt='%.6f')


        # Step 6: Add plot details
        plt.title('Seismograms')
        plt.xlabel('Trace Offset (m)')
        plt.ylabel('Time (ms)')


        # Set x-axis limits and invert y-axis
        plt.xlim(-4, valid_trace_count * 4)  # Start x-axis from 0
        plt.ylim(1000, 0)  # Invert y-axis: 0 at the bottom, max time at the top

        # Adjust x-ticks to show from 0 up to the maximum offset
        x_ticks = np.arange(0, valid_trace_count * 4 + 1, 4)  # Creating tick positions
        plt.xticks(x_ticks)  # Setting tick labels to match trace offsets

        plt.show()





