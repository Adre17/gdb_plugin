#-*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'setup.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

#* Released under the GNU General Public License

##CPT_Office-V1.1_ evaluating liquefaction potential from CPTE and CPTU 
##Copyright(C) 2017 Umberto Grechi

##_CPT_Office-V1.1_ is free software; you can redistribute it and/or
##modify it under the terms of the GNU General Public License
##as published by the Free Software Foundation; either version 3
##of the License, or (at your option) any later version.

##_CPT_Office-V1.1_ is distributed in the hope that it will be useful,
##but WITHOUT ANY WARRANTY; without even the implied warranty of
##MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##GNU General Public License for more details.

##You should have received a copy of the GNU General Public License
##along with this program.  If not, see <http://www.gnu.org/licenses/>

from .GDB_plugin import*
from .SBT import*


def con_Letture(self):
    # blocco comune per CPT e CPTE/U
    #pressione atmosferica in Mpa
    self.pa=0.1013252
    self.pa2=0.1013252*1000
    try:
        self.CosCT
    except AttributeError:
        msg = QMessageBox()
        msg.setWindowIcon(QtGui.QIcon('avviso.ico'))
        msg.setIcon(QMessageBox.Information)
        msg.setText("Scegli il tipo di punta! poi ricalcola")
        msg.setWindowTitle("Attenzione!")
        msg.exec_()

    #se non presenti L1, L2 Qc e fs errore
    if len(self.Qc) == 0 and len(self.fs)==0 and len(self.L1)==0 and len(self.L2)==0:
        msg = QMessageBox()
        msg.setWindowIcon(QtGui.QIcon('avviso.ico'))
        msg.setIcon(QMessageBox.Information)
        msg.setText("Mancano i dati della prova, inseriscili prima di procedere")
        msg.setWindowTitle("Attenzione!")
        msg.exec_()

    #calcola Qc se inserite letture L1 e non Qc
    if len(self.Qc)==0:
       self.Qc=((self.L1*float(self.CosCT))/float(self.ArPT))*0.0980665 #li converto in Mpa
    else:
       self.Qc=self.Qc

    #calcola fs se inserite letture L2 e non fs
    if len(self.fs)==0:
       self.fs=(((self.L2-self.L1)*float(self.CosCT))/float(self.SM))*98.0665  #li converto in Kpa
       self.fs=np.delete(self.fs,0,axis=0)
       self.fs=np.append(self.fs,0)
       if self.dlg8.CalCPT.isChecked():
          self.fsCorr=[]
          for i in range(0,len(self.fs)):
              if self.fs[i]<65:
                self.fsCorr= np.append(self.fsCorr,((0.0797*self.fs[i])**2.504))
              else:
                 self.fsCorr=np.append(self.fsCorr,self.fs[i])
          self.fs=self.fsCorr
    else:
       self.fs=self.fs
       if self.dlg8.CalCPT.isChecked():
          self.fsCorr=[]
          for i in range(0,len(self.fs)):
              if self.fs[i]<65:
                 self.fsCorr=np.append(self.fsCorr,((0.0797*self.fs[i])**2.504))
              else:
                 self.fsCorr=np.append(self.fsCorr,self.fs[i])
          self.fs=self.fsCorr

def calcola(self):
    #agire qui per calcolo CPTm##############################################################

    if hasattr(np, 'asscalar'):
        self.np_scalar = lambda x: np.asscalar(x)  # Will use np.asscalar if available
    else:
        self.np_scalar = lambda x: x.item()



    # se flaggo CPTm calcolo parametri con correlazioni CPTm
    if self.dlg8.CalCPTM.isChecked()==True or self.dlg8.CalCPT.isChecked()==True:
        #peso unitario terreno
        if self.ChoseGammaM==0:
           #gamma robertson
           self.Gamma=[]
           for r in range(0,len(self.Rf)):
               if self.Rf[r]<=0 or self.Qc[r]<=0:
                   self.Gamma=np.append(self.Gamma,17.0)
               else:
                   # essendo una correlazione indiretta considerà già l'eventuale presenza di acqua
                   self.Gamma=np.append(self.Gamma,((0.27*(np.log10(self.Rf[r])))+(0.36*(np.log10(self.Qc[r]/self.pa)))+1.236)*9.81)
           #gamma mayne 2010
        if self.ChoseGammaM==1:
           self.Gamma=[]
           for m in range(0,len(self.fs)):
               if self.fs[m]<=0 or self.Qc[m]<=0:
                   self.Gamma=np.append(self.Gamma,1.70)
               else:
                   #essendo una correlazione indiretta considerà già l'eventuale presenza di acqua
                   self.Gamma=np.append(self.Gamma,11.46+(0.33*np.log10(self.H[m]))+(3.10*np.log10(self.fs[m]))+(0.7*np.log10(self.Qc[m]*1000)))
        #differenzio il gamma secco da quello saturo
        #calcolo tensioni totali ed efficaci
        self.sigma=[]
        sigT=0
        for jj in range(0,len(self.H)):
            #tensione efficace singolo strato
            if jj==0:
                sigH=(self.H[jj])*self.Gamma[jj]
            else:
                sigH=(self.H[jj]-self.H[jj-1])*self.Gamma[jj]
            #tensione efficace fino alla profondità raggiunta
            sigT += sigH
            self.sigma=np.append(self.sigma,sigT)
        #sigma efficace
        self.sigmaP = []
        self.GammaseccTab = []
        for kk in range(0, len(self.H)):
            if self.H[kk] < float(self.Hfalda):
                self.sigmaP = np.append(self.sigmaP, self.sigma[kk])
                self.GammaseccTab = np.append(self.GammaseccTab, self.Gamma[kk])
            else:
                self.sigmaP = np.append(self.sigmaP, self.sigma[kk] - ((self.H[kk] - float(self.Hfalda)) * 9.81))
                self.GammaseccTab = np.append(self.GammaseccTab, self.Gamma[kk]-1)
        #aggiungere if per terreni incoerenti coesivi ecc
        #considero parametro per la verticale e compilo in funzione IC o I o C
        #densità relativa
        self.DR=[]
        for d in range(0,len(self.H)):
            if self.TipoT[d]=='I' or self.TipoT[d]=='CI':
                #lancellotta 1983 (terreni incoerenti)
                if self.ChoseDRI==0:
                     if self.Qc[d]<=0 or self.sigmaP[d]<=0:
                        self.DR=np.append(self.DR,0)
                     else:
                        DRR=-98+(66*(np.log10((self.Qc[d]*100.3611356566794)/((self.sigmaP[d]*0.10036113565668)**0.5))))
                        if DRR>100:
                            DRR=100
                        if DRR<0:
                            DRR=0
                        self.DR=np.append(self.DR,DRR)
                #Schmertmann (terreni incoerenti)
                if self.ChoseDRI==1:
                   if self.Qc[d]<=0 or self.sigmaP[d]<=0:
                     self.DR=np.append(self.DR,0)
                   else:
                     DRR=-97.8+(36.6*np.log(self.Qc[d]*10.1971621))-(26.9*np.log(self.sigmaP[d]*0.0101972))
                     if DRR>100:
                            DRR=100
                     if DRR<0:
                            DRR=0
                     self.DR=np.append(self.DR,DRR)
            else:
                self.DR=np.append(self.DR,0)
        #modulo edometrico
        self.M=[]
        for EDO in range(0,len(self.H)):
            #terreno incoerente
            if self.TipoT[EDO]=='I':
                if self.ChoseEDO==0:
                   #mitchell & Gardner (1975)
                   b=1.5  #costante può variare tra 1.5 e 3
                   mod=b*self.Qc[EDO]
                   self.M=np.append(self.M,mod)
                if self.ChoseEDO==1:
                   #robertson & campanella
                   mod=(0.33*self.Qc[EDO])+(11.7*(self.sigmaP[EDO]*0.001))+(0.79*self.DR[EDO])
                   self.M=np.append(self.M,mod)
            #terreni coesivi o misti
            if self.TipoT[EDO]=='C' or self.TipoT[EDO]=='CI':
                if self.ChoseEDOC==0:
                   #mitchell & Gardner (1975)
                   #distinzione limi argille
                   if self.ChoseLTM ==0:
                       #argille
                       if self.TipoN[EDO]==9 or self.TipoN[EDO]==3 or self.TipoN[EDO]==2 or self.TipoN[EDO]==1:
                           if self.Qc[EDO]>0.7 and self.Qc[EDO]<2:
                               a=5
                           if self.Qc[EDO]>=2:
                               a=2.5
                           if self.Qc[EDO]<=0.7:
                               a=8
                       #limi
                       if self.TipoN[EDO]==6 or self.TipoN[EDO]==5 or self.TipoN[EDO]==4 or self.TipoN[EDO]==0:
                           if self.Qc[EDO]>=2:
                               a=6
                           if self.Qc[EDO]<2:
                               a=3
                       mod=a*self.Qc[EDO]
                       self.M=np.append(self.M,mod)
                   if self.ChoseLTM ==1:
                       #argille
                       if self.TipoNB[EDO]==1 or self.TipoNB[EDO]==2 or self.TipoNB[EDO]==3 or self.TipoNB[EDO]==0:
                           if self.Qc[EDO]>0.7 and self.Qc[EDO]<2:
                               a=5
                           if self.Qc[EDO]>=2:
                               a=2.5
                           if self.Qc[EDO]<=0.7:
                               a=8
                       #limi
                       if self.TipoNB[EDO]==4 or self.TipoNB[EDO]==5:
                           if self.Qc[EDO]>=2:
                               a=6
                           if self.Qc[EDO]<2:
                               a=3
                       mod=a*self.Qc[EDO]
                       self.M=np.append(self.M,mod)
                if self.ChoseEDOC==1:
                   #Kuhlawy & Mayne
                   mod=8.25*((self.Qc[EDO])-(self.sigmaP[EDO]*0.001))
                   self.M=np.append(self.M,mod)
        #modulo di deformazione di taglio G0 (per tutti i tipi
        self.G0=[]
        for Def in range(0,len(self.H)):
            #imai & Tonouchi
            deft=(28*((self.Qc[Def]*10.1971621)**0.611))*0.0980665   #devo prima convertire Qc in Kgcmq se no sballa e poi riconverto in Mpa
            self.G0=np.append(self.G0,deft)
        #angolo attrito solo per terreni incoerenti
        self.effPhi=[]
        for ang in range(0,len(self.H)):
            if self.TipoT[ang]=='I' or self.TipoT[ang]=='CI':
                if self.ChosePHI==0:
                    #De Beer (1965-1967)
                    if self.Qc[ang]<=0:
                        self.effPhi=np.append(self.effPhi,0)
                    else:
                        phi=5.9+4.76*(np.log(self.Qc[ang]/(self.sigmaP[ang]*0.001)))
                        self.effPhi=np.append(self.effPhi,phi)
                if self.ChosePHI==1:
                    #Durgunoglu & Mitchell (1975)
                    if self.Qc[ang]<=0:
                        self.effPhi=np.append(self.effPhi,0)
                    else:
                        phi=14.4+4.8*(np.log(self.Qc[ang])-4.5*np.log(self.sigmaP[ang]*0.001))
                        self.effPhi=np.append(self.effPhi,phi)
                if self.ChosePHI==2:
                    #Meyerhof (1951)
                    phi=17+4.49*self.Qc[ang]
                    self.effPhi=np.append(self.effPhi,phi)
                if self.ChosePHI==3:
                    #Caquot
                    if self.Qc[ang]<=0:
                        self.effPhi=np.append(self.effPhi,0)
                    else:
                        phi=9.8+(4.96*np.log(self.Qc[ang]/(self.sigmaP[ang]*0.001)))
                        self.effPhi=np.append(self.effPhi,phi)
                if self.ChosePHI==4:
                    #Robertson & campanella
                    if self.Qc[ang]<=0:
                        self.effPhi=np.append(self.effPhi,0)
                    else:
                        phi=np.arctan(0.1+(0.38*np.log(self.Qc[ang]/(self.sigmaP[ang]*0.001))))
                        self.effPhi=np.append(self.effPhi,phi)
            else:
                self.effPhi=np.append(self.effPhi,0)
        #coesione non drenata solo per terreni coerenti
        self.cu=[]
        for coe in range(0,len(self.H)):
            if self.TipoT[coe]=='C' or self.TipoT[coe]=='CI':
                if self.ChoseCU==0:
                    #Mayne-kemper 1988
                    if self.Qc[coe]<=0:
                        self.cu=np.append(self.cu,0)
                    else:
                        cuu=((self.Qc[coe]*1000)-self.sigmaP[coe])/20
                        self.cu=np.append(self.cu,cuu)
                if self.ChoseCU==1:
                    #Lunne robertson powell 1977
                    if self.Qc[coe]<=0:
                        self.cu=np.append(self.cu,0)
                    else:
                        cuu=((self.Qc[coe]*1000)-self.sigmaP[coe])/19
                        self.cu=np.append(self.cu,cuu)
                if self.ChoseCU==2:
                    #Lunne kleven 1981
                    if self.Qc[coe]<=0:
                        self.cu=np.append(self.cu,0)
                    else:
                        cuu=((self.Qc[coe]*1000)-self.sigmaP[coe])/15
                        self.cu=np.append(self.cu,cuu)
                if self.ChoseCU==3:
                    #kjestad 1978
                    if self.Qc[coe]<=0:
                        self.cu=np.append(self.cu,0)
                    else:
                        cuu=((self.Qc[coe]*1000)-self.sigmaP[coe])/17
                        self.cu=np.append(self.cu,cuu)
                if self.ChoseCU==4:
                    #begemann
                    if self.Qc[coe]<=0:
                        self.cu=np.append(self.cu,0)
                    else:
                        cuu=((self.Qc[coe]*1000)-self.sigmaP[coe])/14
                        self.cu=np.append(self.cu,cuu)
            else:
                self.cu=np.append(self.cu,0)
        #permeabilità
        self.K=[]
        for kk in range(0,len(self.H)):
            if self.Qcfs[kk]<=0 or self.Qc[kk]<=0:
                self.K=np.append(self.K,0)
            else:
                per=10**(-((165/self.Qcfs[kk])+((160*(self.Qc[kk]*10.1971621))/(self.Qcfs[kk]**3.5))))
                if per<0.00000000001:
                    self.K=np.append(self.K,0.00000000001)
                else:
                    self.K=np.append(self.K,per)
                #everifica blocco 1E-11 di geostru
         #OCR terreni coesivi
        self.OCR=[]
        for OC in range(0,len(self.H)):
            if self.TipoT[OC]=='C' or self.TipoT[OC]=='CI':
                if self.ChoseOCR==0:
                    #mayne 1991
                    SC=round((10**(-0.7+((np.log10(self.Qc[OC]*10.1971621)+0.22)/1.13)))/(self.sigma[OC]*0.0101972 ),2)
                    if SC<0:
                          SC=0
                    if SC>9:
                        SC='>9'
                    self.OCR=np.append(self.OCR,SC)
                if self.ChoseOCR==1:
                      #chen e mayne 1996
                      SC=round(0.33*((((self.Qc[OC]*1000)-self.sigma[OC])/self.sigmaP[OC])),2)
                      if SC<0:
                          SC=0
                      if SC>9:
                          SC='>9'
                      self.OCR=np.append(self.OCR,SC)
                if self.ChoseOCR==2:
                    #ladd e foot
                    if self.H[OC]<=1:
                        kp=0.2*(self.H[OC]/0.2)
                    if self.H[OC]>1 and self.H[OC]<4:
                        kp=(0.2/0.2)+((0.35*(self.H[OC]-1))/0.2)
                    if self.H[OC]>=4:
                        kp=(0.2/0.2)+(0.35*(3/0.2))+((0.5*(self.H[OC]-4))/0.2)
                    if kp<0.25:
                        kp=0.25
                    SC=round((self.cu[OC]/(self.sigmaP[OC]*kp))**1.25,2)
                    if SC<0:
                          SC=0
                    if SC>9:
                          SC='>9'
                    self.OCR=np.append(self.OCR,SC)
            #terreni incoerenti NO OCR
            if self.TipoT[OC]=='I':
                self.OCR=np.append(self.OCR,0)

        #modulo di young (solo per terreni incoerenti e misti)
        self.Ey=[]
        for Ee in range(0,len(self.H)):
            if self.ChoseYOUNG==0:
                #Schmertmann
                you=self.Qc[Ee]*2
                self.Ey=np.append(self.Ey,you)
            if self.ChoseYOUNG==1:
                #relazione tra moduli elastici
                if self.TipoT[Ee]=='I':
                    if self.M[Ee]<=0:
                        self.Ey=np.append(self.Ey,0)
                    else:
                        lada=0.27
                        you=(self.M[Ee]*(1-lada)*(1-(2*lada)))/(1-lada)
                        self.Ey=np.append(self.Ey,you)
                if self.TipoT[Ee]=='CI':
                    if self.M[Ee]<=0:
                        self.Ey=np.append(self.Ey,0)
                    else:
                        self.Ey=np.append(self.Ey,self.M[Ee]*1.33)
                if self.TipoT[Ee]=='C':
                    self.Ey=np.append(self.Ey,0)
        #modulo di Eu
        self.Eu=[]
        for gg in range(0,len(self.H)):
            if self.TipoT[gg]=='C' or self.TipoT[gg]=='CI':
                if self.ChoseEU==0:
                    #viggiani
                    try:
                       cd=np.float32(self.OCR[gg])
                    except ValueError:
                       cd=10
                    if cd<=3:
                        ni=800
                    if cd>3 and cd<=5:
                        ni=500
                    if cd>5:
                        ni=300
                    undrdef=((self.cu[gg]*0.0101972)*ni)*0.0980665
                    self.Eu=np.append(self.Eu,round(undrdef,2))
                if self.ChoseEU==1:
                    undrdef=self.G0[gg]*3
                    self.Eu=np.append(self.Eu,round(undrdef,2))
            if self.TipoT[gg]=='I':
                self.Eu=np.append(self.Eu,0)
    # qua calcolo CPTE/CPTU
    else:
        self.pa=0.1013252
        self.pa2=0.1013252*1000
        #calcola Qt
        if len(self.u2)==0:
           self.Qt=self.Qc
        else:
           try:
             self.Qt=self.Qc+((self.u2*0.001)*(1-0.8)) #eventualmente cella per cambiare vaalore di 0.8
             for i in range(0, len(self.Qc)):
                 if self.Qt[i] <= 0:
                     msg = QMessageBox()
                     msg.setWindowIcon(QtGui.QIcon('avviso.ico'))
                     msg.setIcon(QMessageBox.Information)
                     msg.setText("I valori di u2 alla prof. " + str(self.H[
                         i]) + "m da p.c. sono negativi e maggiori rispetto le resistenze Qc, eliminare riga o mettere pressione a 0")
                     msg.setWindowTitle("Attenzione!")
                     msg.exec_()

           except ValueError:
             self.Qt=self.Qc

        #controllo u2 se presente
        if len(self.u2)==0:
           self.u2=np.zeros(len(self.H))
        else:
           try:
             self.u2*1
           except ValueError:
             self.u2=np.zeros(len(self.H))

        #calcola pressione H20
        self.Huu=[]
        self.PresU=[]
        for ui in range(0,len(self.H)):
            if self.H[ui]>=float(self.Hfalda):
               self.Huu=np.append(self.Huu,self.H[ui])
               self.PresU=np.append(self.PresU,(9.81*(self.H[ui]-float(self.Hfalda))))

        #calcola u0
        self.u0=[]
        for uk in range(0,len(self.u2)):
            if self.H[uk]>=float(self.Hfalda):
                self.u0=np.append(self.u0,9.81*(self.H[uk]-float(self.Hfalda)))
            else:
                self.u0=np.append(self.u0,0)

        #calcola Rf
        self.Rf=[]
        for k in range(0,len(self.fs)):
           if self.fs[k]==0 or self.Qt[k]==0:
             self.Rf=np.append(self.Rf,0)
           else:
             self.Rf=np.append(self.Rf,(self.fs[k]/(self.Qt[k]*1000))*100)

        #definisco punti plot grafico SBT
        #serve per il plot grafico normale
        self.YSBT=self.Qt/self.pa
        self.XSBT=self.Rf
        self.pointSBT=np.column_stack((self.XSBT,self.YSBT))

        #calcolo gamma in funzione degli autori
        #calcolo gamma secco SBT Robertson 1986
        if self.ChoseGa==0:
           #crea punti Qc/pa e Rf
           value_SBT_1986(self)
           SBTgamma(self)
        #calcolo gamma secco Robertson 2010
        if self.ChoseGa==1:
           self.Gamma=[]
           n=0
           for r in range(0,len(self.Rf)):
               if self.Rf[r]<=0 or self.Qt[r]<=0:
                   self.Gamma=np.append(self.Gamma,17.0)
               else:
                   self.Gamma=np.append(self.Gamma,((0.27*(np.log10(self.Rf[r])))+(0.36*(np.log10(self.Qt[r]/self.pa)))+1.236)*9.81)
        #calcolo gamma secco Mayne 2010
        if self.ChoseGa==2:
           self.Gamma=[]
           for m in range(0,len(self.fs)):
               if self.fs[m]<=0 or self.Qt[m]<=0:
                   self.Gamma=np.append(self.Gamma,1.70)
               else:
                   self.Gamma=11.46+(0.33*np.log10(self.H[m]))+(3.10*np.log10(self.fs[m]))+(0.7*np.log10(self.Qt[m]*1000))
        #calcolo tensioni totali ed efficaci
        self.sigma=[]
        sigT=0
        for jj in range(0,len(self.H)):
            #tensione efficace singolo strato
            if jj==0:
                sigH=(self.H[jj])*self.Gamma[jj]
            else:
                sigH = (self.H[jj] - self.H[jj - 1]) * self.Gamma[jj]
            #tensione efficace fino alla profondità raggiunta
            sigT += sigH
            self.sigma=np.append(self.sigma,sigT)
        #sigma efficace
        self.sigmaP=[]
        self.GammaseccTab =[]
        for kk in range(0,len(self.H)):
            if self.H[kk]<float(self.Hfalda):
                self.sigmaP=np.append(self.sigmaP,self.sigma[kk])
                self.GammaseccTab=np.append(self.GammaseccTab,self.Gamma[kk])
            else:
                self.sigmaP=np.append(self.sigmaP,self.sigma[kk]-((self.H[kk]-float(self.Hfalda))*9.81))
                self.GammaseccTab = np.append(self.GammaseccTab, self.Gamma[kk]-1)
        #inserisci l'iterazione per il calcolo Qtn
        #Friction Ratio
        self.Fr=(self.fs/((self.Qt*1000)-self.sigma))*100
        self.Qt1=((self.Qt*1000)-self.sigma)/self.sigmaP
        self.QtnT=[]
        self.IC=[]
        for h in range(0,len(self.Qt1)):
            kont=0
            Ic=((3.47-np.log10(self.Qt1[h]))**2+(np.log10(self.Fr[h])+1.22)**2)**0.5
            n=(0.381*Ic)+(0.05*(self.sigmaP[h]/self.pa2))-0.15
            Qtn=(((self.Qt[h]*1000)-self.sigma[h])/self.pa2)*(self.pa2/self.sigmaP[h])**n
            IcNEW=((3.47-np.log10(Qtn))**2+(np.log10(self.Fr[h])+1.22)**2)**0.5
            nNEW=(0.381*IcNEW)+(0.05*(self.sigmaP[h]/self.pa2))-0.15
            n2=self.np_scalar(n)
            nNEW2=self.np_scalar(nNEW)
            period=0
            while np.absolute(n2-nNEW2)>0.01:
                  period +=1
                  kont=1
                  n=nNEW
                  self.QtnN=((self.Qt[h]*1000-self.sigma[h])/self.pa2)*(self.pa2/self.sigmaP[h])**n
                  IcNEW2=((3.47-np.log10(self.QtnN))**2+(np.log10(self.Fr[h])+1.22)**2)**0.5
                  nNEW=(0.381*IcNEW2)+(0.05*(self.sigmaP[h]/self.pa2))-0.15
                  n2=self.np_scalar(n)
                  nNEW2=self.np_scalar(nNEW)
                  if period>100:
                      self.QtnN=0
                      IcNEW2=0
                      break
            if kont==1:
                  self.QtnT=np.append(self.QtnT,self.QtnN)
                  self.IC=np.append(self.IC,IcNEW2)
            if kont==0:
                  self.QtnT=np.append(self.QtnT,Qtn)
                  self.IC=np.append(self.IC,IcNEW)        #calcolo IC_SBT
        self.IC_SBT=[]
        for h in range(0,len(self.Qt)):
            Isbt=((3.47-np.log10((self.Qt[h]*1000)/self.pa2))**2+(np.log10(self.Rf[h])+1.22)**2)**0.5
            self.IC_SBT=np.append(self.IC_SBT,Isbt)

        #serve per il plot grafico normalizzato
        self.YSBTN=self.QtnT
        self.pointSBTn=np.column_stack((self.XSBT,self.YSBTN))

        #calcolo modulo young
        self.Es=[]
        for E in range(len(self.IC)):
            if self.IC[E]<2.6:
               alfaE=0.015*(10**((0.55*self.IC[E])+1.68))
               mEs=alfaE*(self.Qt[E]-(self.sigma[E]*0.001))
               self.Es=np.append(self.Es,mEs)
            else:
               self.Es=np.append(self.Es,0)
        #constrained module M
        self.M=[]
        for ck in range(len(self.IC)):
            if self.IC[ck]<2.2:
                am=0.0188*(10**((0.55*self.IC[ck])+1.68))
            if self.IC[ck]>2.2:
                if self.QtnT[ck]>14:
                   am=14
                if self.QtnT[ck]<14:
                   am=self.QtnT[ck]
            Mm=am*(self.Qt[ck]-(self.sigma[ck]*0.001))
            self.M=np.append(self.M,Mm)

        #G0
        alfaG=[]
        for sk in range(len(self.IC)):
            amG=0.0188*(10**((0.55*self.IC[sk])+1.68))
            if amG==float('inf'):
               alfaG=np.append(alfaG,0)
            else:
               alfaG=np.append(alfaG,amG)
        self.G0=alfaG*(self.Qt-(self.sigma*0.001))

        #Bq
        self.Bq=(self.u2-self.u0)/(self.Qt*1000-self.sigma)
    

                  
    




